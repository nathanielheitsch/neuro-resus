void mylib_function();
