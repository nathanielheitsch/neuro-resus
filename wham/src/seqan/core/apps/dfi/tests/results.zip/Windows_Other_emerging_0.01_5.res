		f
	X
	x
            ____
      Fax: 
     ...!
    ...!
    ...!u
    Fr
    Fro
    Vo
    Voice
    de
    ex
    | T
   ...!
   ...!u
   /*
   Vo
   Voice
   X
   app
   that
   that 
  ...!
  ...!u
  /*
  /* 
  Xt
  win
  } 
 ".
 "X
 "x
 (X
 *.
 */
 ++
 -O
 -f
 -l
 -o
 -o 
 ...!
 ...!u
 ...!uunet!
 .X
 /*
 /* 
 /u
 /us
 /usr
 /usr/
 /usr/l
 0)
 0,
 3.00 
 3.1
 3.1 
 3.1?
 3.2
 4.1
 4.1.
 4.1.1
 4.1.3
 : +
 : +4
 <1993Ma
 <1993May
 <1993May1
 <1t
 <9
 <93
 <930
 <9304
 <93041
 <93042
 <9305
 <C6
 = X
 Ath
 Athe
 Athen
 Athena
 Athena 
 BJ
 Bor
 Borland
 Chal
 Challenge
 Challenge 
 Conso
 Consort
 Default
 GX
 HP-UX
 I start
 I start 
 Imake
 MIT
 MIT 
 MS W
 MS Win
 MS Window
 MS Windows
 Makefile
 Microso
 Microsoft
 Microsoft 
 Microsoft s
 Microsoft supp
 Moti
 Motif
 Motif 
 Motif 1.
 Motif 1.2
 Motif a
 Motif w
 Motif,
 Motif, 
 NCD
 ND
 NULL
 OL
 OW
 Open
 OpenWin
 OpenWindows
 OpenWindows 
 OpenWindows 3
 OpenWindows 3.
 Pana
 R4
 R5
 R5 
 Re: X
 Richardson
 SS
 Solar
 Solari
 Solaris
 Solaris 
 Solaris 2
 SunO
 SunOS
 SunOS 
 SunOS 4
 SunOS 4.
 SunOS 4.1
 SunOS 4.1.
 TCP
 Tek
 UI
 Visual 
 W4
 W4W
 WIN
 WINDO
 WINDOW
 WINDOWS
 Wid
 Widg
 Widget
 Widget 
 Widgets
 Win 
 Win 3
 Win 3.1
 Win 3.1 
 Win3
 Win3.1
 Window 
 Window S
 Window System
 Windows 
 Windows 3.
 Windows 3.1
 Windows 3.1 
 Windows NT
 Windows NT 
 Windows a
 Windows and 
 Windows f
 Windows fo
 Windows for
 Windows s
 X
 X 
 X T
 X Win
 X Window
 X Window 
 X Window S
 X Window System
 X a
 X an
 X and
 X and 
 X app
 X applica
 X applicatio
 X application
 X c
 X client
 X p
 X pr
 X pro
 X s
 X se
 X server
 X server 
 X t
 X te
 X w
 X wi
 X window
 X windows
 X-
 X.
 X. 
 X/
 X1
 X11
 X11R
 X11R4
 X11R4 
 X11R5
 X11R5 
 X11R5 a
 XC
 XCo
 XCreate
 XD
 XF
 XG
 XI
 XP
 XPut
 XPutImage
 XPutImage()
 XS
 XSe
 XSet
 XV 3.
 XV 3.00 has
 XVi
 XView
 XView 
 XW
 Xa
 Xl
 Xli
 Xlib
 Xlib 
 Xm
 Xp
 Xs
 Xse
 Xserver
 Xsun
 Xt
 Xt 
 XtA
 Xter
 Xterm
 __/
 a Mo
 a Moti
 a Motif
 a Motif 
 a X
 a val
 a wi
 a widget
 a win
 a window
 a window 
 an X
 an X 
 an X s
 an Xt
 an x
 and Wi
 and Win
 and Wind
 and Windo
 and Window
 and Windows
 and Windows 
 and X
 app 
 application 
 application i
 application t
 application th
 application that
 application that 
 application w
 application,
 application, 
 apps
 apps 
 are running
 article <1993Ma
 article <1993May
 article <1993May1
 article <C6
 be consid
 be consider
 be considered
 bitmaps
 button 
 callback
 characters
 child
 cica
 cica 
 client
 client 
 clients
 clients 
 colorm
 colormap
 colormap 
 comp.windows.
 comp.windows.x
 compiling
 compiling 
 contex
 context
 curs
 cursor
 dialog
 dialog 
 dialog box
 drag
 emb
 enhanced
 enter
 enterp
 enterpoop
 enterpoop.
 esc
 escap
 escape
 escaped
 event 
 events
 events 
 execute
 exit
 exit 
 expo
 export.
 export.lcs.mi
 export.lcs.mit.edu
 export.lcs.mit.edu 
 expos
 expose
 expose 
 file (
 file d
 font 
 fonts.
 for Wi
 for Win
 for Windows 
 for Wor
 for wi
 for win
 for window
 for windows
 for windows 
 ftp.c
 ftp.ci
 ftp.cica
 ftp.cica.indiana
 ftp.cica.indiana.edu
 gc
 gcc
 gcc 
 handler
 ico
 icon
 icon 
 icons
 icons 
 if (
 in /
 in W
 in Wi
 in Win
 in Window
 in Windows
 in Windows 
 in Windows 3.
 in Windows 3.1
 in X
 in X11
 in the X
 invok
 invoke
 logo
 louray@seas.gwu.edu
 louray@seas.gwu.edu 
 macr
 macro
 man page
 manager
 manager 
 manager t
 manager,
 manager, 
 manager.
 manager. 
 managers
 managers 
 mit
 motif
 mw
 mwm
 my .
 my ap
 my app
 my application
 o |
 of Win
 of Window
 of Windows
 of X
 of X 
 of our 
 of the X
 of the wi
 of the win
 of the window
 of wi
 of win
 of x
 olwm
 on X
 on ex
 on expo
 on export
 or X
 parent
 pars
 patche
 patches 
 pixmap
 pixmap 
 pointer 
 popup
 redraw
 resiz
 resour
 resource
 resource 
 resources
 resources 
 running X
 server 
 server i
 server t
 server w
 server.
 server. 
 server.  
 session 
 shared
 shared 
 shel
 shell
 shell 
 status
 supporter
 supporters
 supporters.
 swap f
 swap file
 symbol
 that X
 the MI
 the MIT
 the MIT 
 the MS
 the Motif
 the Wi
 the Win
 the Wind
 the Window
 the X
 the X 
 the X s
 the X se
 the X server
 the X11
 the Xt
 the appl
 the applic
 the application
 the application 
 the cal
 the call
 the client
 the command
 the curs
 the cursor
 the exa
 the exi
 the font
 the font 
 the icon
 the mouse 
 the text 
 the title
 the title 
 the user 
 the val
 the wi
 the win
 the window
 the window 
 the window manager
 the window manager 
 the windows
 the windows 
 the x
 to M
 to Mi
 to Microsoft
 to Microsoft 
 to Wi
 to Win
 to Window
 to Windows
 to X
 to X 
 to compile
 to compile 
 to the X
 to wi
 toolkits
 tv
 tvt
 tvtwm
 unnecessar
 use X
 use x
 using X
 what is i
 widget
 widget 
 widgets
 widgets 
 win
 win 
 wind
 windo
 window
 window 
 window a
 window i
 window is
 window m
 window ma
 window man
 window manage
 window manager
 window manager 
 window managers
 window o
 window s
 window t
 window to
 window to 
 window w
 window,
 window, 
 window.
 window. 
 window.  
 window?
 windows
 windows 
 windows a
 windows i
 windows o
 windows on
 windows on 
 windows,
 windows, 
 with W
 with Win
 with Windows
 with X
 with X 
 with X11
 with x
 xa
 xc
 xd
 xdm
 xdm 
 xm
 xp
 xpert
 xpert@expo
 xpert@expo.lcs.mit.
 xpert@expo.lcs.mit.edu
 xr
 xs
 xt
 xte
 xterm
 xterm 
 xterm.
 xw
 your wi
 your win
 your window
 | Te
 | Tel
 | th
!,
!/
!3
!;
!E
!X
!Y
"!
""
"#
"$
"%
"&
"'
"(
"*
"+
"0
":
";
"<
"@
"Q
"X
"Z
"\
"x
"z
#!
##
#$
#&
#'
#7
#@
#F
#I
#M
#N
#P
#T
#X
#define
#define 
#if
$"
$(
$*
$,
$@
$A
$D
$E
$H
$I
$L
$M
$O
$P
$Q
$R
$W
%!
%%
%-
%/
%0
%1
%A
%E
%L
%M
%N
%Q
%T
&"
&$
&&
&'
&0
&1
&5
&:
&;
&A
&E
&M
&X
' B
'"
'#
'$
'(
'*
'/
'1
'2
':
';
'<
'=
'A
'B
'I
'M
'N
'P
'Q
'U
'V
'W
'X
'_
's X
("
(#
(&
('
((
()
() 
() a
();
()?
(-
(@
(X
(X1
(]
) X
)'
)0
);
);	
);  
);   
)Q
)X
)[
)]
* d
*"
*'
*-
*/
*/ 
*5
*9
*?
*B
*E
*G
*J
*K
*V
*X
*\
+ w
+!
+"
+'
+.
+/
+2
+8
+9
+;
+B
+I
+M
+Q
+R
+X
+[
+\
, X
, X1
, X11
, X11R
, Xt
, but I've 
, win
, x
,#
,&
,8
,<
,X
,]
-#
-Posting-Host: e
-Posting-Host: en
-UX
-Z
-_
-he
-o 
-wind
-window
-windows
-|| 
.%
...!u
...!uunet
...!uunet!
../
.00 h
.1 i
.1.3
.2,
.2, 
.737
.930
.@
.AA
.AA0
.AA1
.AA2
.\
.bm
.bmp
.bmp 
.clark
.edu a
.edu!
.eduM
.eduMessage-ID: <
.eduMessage-ID: <930
.eduMessage-ID: <9304
.eduMessage-ID: <93042
.eduMessage-ID: <9305
.eduTo
.eduTo: 
.gw
.ini
.ini 
.lc
.lcs.mi
.lcs.mit.
.lcs.mit.edu
.lcs.mit.edu 
.lcs.mit.eduz
.mit.eduT
.sh
.uc.edu
.win
.window
.windows
/#
/$
/%
/'
/(
/*
/* 
/.
///      
///       
/=
/X
/X 
/X1
/X11
/X11/
/bi
/bin
/bin/
/contrib
/contrib/
/l
/li
/lib
/lib/
/lib/X
/lib/X11
/lib/X11/
/pc/
/u
/us
/usr
/usr/
/usr/l
/win3
/win3/
/x
0(
0);
00 ha
00 has
00 has 
0;
0L
0Q
1 7
1!
1%
1*
1.2.
11/
11R
11R5
11R5 
1993Ma
1;
1?
1K
1R
1R4
1R4 
1R5
1R5.
1S
1T
1V
1W
1Z
1[
1z
2!
2'
2(
2+
2.2 
23    
292
2<
2=
2T
2\
2z
3%
3'
3.00 
3.1 
3.1 a
3.1 and 
3.1?
3051
3?
3B
3H
3May
3Q
3X
3[
3z
4%
4(
4+
4.1.
4.1.1
4.1.3
421
466
4;
4=
4?
4C
4G
4H
4L
4Q
4U
4W
4[
5 on
5 on 
5'
5(
501
5C
5U
6%
6;
6E
6G
6L
6R
6T
7%
7K
7P
7S
7T
7U
8+
865
8<
8A
8E
8F
8G
8H
8O
8V
8z
9%
9&
9/
9304
93042
9305
93051
93May
93May1
9;
9<
9D
9F
9L
9M
9S
9T
9V
9_
: <1s
: <9
: <93
: <930
: <9304
: <93041
: <93042
: Ch
: Cha
: Challenge to Microsoft supporters.
: Challenge to Microsoft supporters.I
: Challenge to Microsoft supporters.In 
: Challenge to Microsoft supporters.In a
: How to 
: Re: X
: Wi
: Win
: Window
: Windows
: Windows 
: X
: X 
: X11
: XV 3.0
: XV 3.00 has escaped!
: en
: ex
: vi
: x
: xp
: xpert
: xpert@expo
: xpert@expo.lcs.mit.
: xpert@expo.lcs.mit.edu
:#
:$
:'
:/
:7
:J
:V
:X
:\
;	
;!
;"
;$
;'
;/
;6
;;
;<
;A
;B
;C
;F
;H
;I
;T
;W
;X
;}
<'
<(
</
<3
<4
<5
<6
<9
<93
<B
<C6
<G
<H
<K
<P
<Q
<R
<T
<W
<X
<Y
= X
=#
=$
=&
='
=)
=+
=.
=/
=0
=2
=5
=6
=9
=:
=@
=F
=G
=H
=J
=K
=M
=N
=R
=U
=X
=]
?#
?%
?*
?1
?5
?@
?U
?z
@$
@(
@.
@=
@E
@H
@K
@N
@S
@at
@athen
@athena
@athena.
@athena.mit.edu
@athena.mit.eduM
@ex
@expo
@expo.lcs.mit.
@expo.lcs.mit.edu
@expo.lcs.mit.eduI
@expo.lcs.mit.eduz
@pri
@prism.gatech.
@sea
@seas.
@seas.gwu.edu
@sunb
A8
A9
A;
A=
AA0
AA1
AA2
AME
ARY
ATH
ATH 
AZ
Administrator
Allo
Alloc
Area
Ath
Athe
Athen
Athena
Athena 
B8
B<
BF
BJ
BK
BQ
BX
B^
Butt
Button
C"
C7
C;
C=
CP/
C_
Chal
Challenge
Challenge 
Challenge to M
Client
Colormap
Conso
Consort
Consortium
Contex
Context
Crea
Creat
Create
CreateWi
Curs
Cursor
D#
D(
D6
D8
D9
D;
D<
D=
DISPL
DK
DOW
DRV
DW
D]
D_
Dave L
Default
E"
E(
E;
E=
E\
E_
Event
Event 
F"
F1
F9
F;
F=
FQ
FY
Font 
Fore
G#
G%
G3
G6
G9
G:
GC
GQ
GV
GX
GY
Guide
Gz
H*
H1
H8
H9
H:
H=
H@
HC
HF
HJ
HM
HP-U
HP-UX
HW
I start
I start 
I!
I$
I+
I0
I4
I=
IND
IT X
IT'
IZ
In article <1993Ma
In article <1993May
In article <1993May1
In article <C6
Inp
Input
Intri
Iz
J*
J-
J1
J7
J@
JL
JM
JS
JU
JZ
K"
K&
K'
K:
K?
KD
KF
KJ
KT
KZ
L!
L(
L);
L*
L+
L0
L6
L7
L;
L=
L?
LD_
LJ
LL)
LQ
LV
M"
M#
M%
M&
M(
M*
M+
M0
M7
M8
M9
M;
M<
M=
M@
MIT X
MMA
MOU
MOUS
MOUSE
MQ
MS W
MS Win
MS Window
MS Windows
MS Windows 
MSW
MW
MZ
M[
M\
M]
M_
Mah
Mail: 
Mask
Message-ID: <1s
Message-ID: <93
Message-ID: <930
Message-ID: <9304
Message-ID: <93042
Microso
Microsoft
Microsoft 
Moti
Motif
Motif 
Motif 1.
Motif 1.1
Motif 1.2
Motif a
Motif w
Motif,
Motif, 
N W
N(
N+
N;
NAM
NAME
NCD
NDO
NH
NNTP-Posting-Host: e
NNTP-Posting-Host: en
NNTP-Posting-Host: enterpoop.mit.edu
NNTP-Posting-Host: enterpoop.mit.eduTo: 
NNTP-Posting-Host: enterpoop.mit.eduTo: x
NNTP-Posting-Host: enterpoop.mit.eduTo: xpert
NNTP-Posting-Host: enterpoop.mit.eduTo: xpert@expo
NNTP-Posting-Host: enterpoop.mit.eduTo: xpert@expo.lcs.mit.edu
NT,
NUL
NULL
NW
NX
NZ
N_
Noti
O$
O'R
O'Reilly
O'Reilly 
O+
O0
O2
O;
O=
OPEN
OS 4
OS 4.
OS 4.1
OS 4.1.
OWS
OWS 
Open
OpenL
OpenWin
OpenWindow
OpenWindows
OpenWindows 
P&
P*
P-U
P/
P4
P<
P=
P@
PAT
PATH
PEN
PF
PK
P\
Pana
Perm
Program M
Program Ma
Program Man
Program Manager
Proper
PutImage
Q-
Q1
Q6
Q<
QD
QH
QL
QM
QQ
QV
R!
R&
R4
R4 
R4.
R5
R5 
R5 a
R5 and
R5 and 
R5 o
R5 s
R5,
R5.
R6
R8
R<
RH
RW
RX
R_
Re: X
Reilly
Reilly 
Runn
Running
Running 
Rz
S 4
S 4.
S 4.1
S Wi
S Win
S Window
S app
S&
S5
S<
S=
SDK
SMA
SW 
S\
Save
Sender: news@
Sender: news@a
Sender: news@athena.mit.eduMessage-ID: <
Sender: news@athena.mit.eduMessage-ID: <930
Sender: news@athena.mit.eduMessage-ID: <9304
Sender: news@athena.mit.eduMessage-ID: <93042
Server
Shel
Shell
Sola
Solar
Solari
Solaris
Solaris 
Solaris 2
String
Subject: Re: Ch
Subject: Re: Cha
Subject: Re: Challenge to Microsoft supporters.
Subject: Re: Challenge to Microsoft supporters.I
Subject: Re: Challenge to Microsoft supporters.In 
Subject: Re: Challenge to Microsoft supporters.In article 
Subject: Re: Challenge to Microsoft supporters.In article <
Subject: Re: Looking 
Subject: Re: Wi
Subject: Re: Win
Subject: Re: Window
Subject: Re: Windows 
Subject: Re: X
Subject: Re: XV 3.0
Subject: Re: XV 3.00 has escaped!
Subject: Wi
Subject: Win
Subject: Window
Subject: Windows
Subject: Windows 
Subject: X
Subject: X 
Subject: x
SunO
SunOS
SunOS 
SunOS 4
SunOS 4.
SunOS 4.1
SunOS 4.1.
T X
T"
T9
T=
T@
TCP
TM)
TZ
T_
Tel: +
Text 
The X
To: x
To: xpert
To: xpert@expo
To: xpert@expo.lcs.mit.edu
TrueType
U!
U/
U:
U=
UH
UMM
UZ
V 3
V 3.
V+
V1
V6
V9
V<
V=
VB
VT
VU
VY
Visual 
W3
W4
W4W
WF
WG
WIN
WINDO
WINDOW
WINDOWS
WINDOWS 
WL
WM
WT
WW
WX
W]
Warn
Wid
Widg
Widget
Widget 
WidgetClass
Widgets
Win
Win 
Win 3
Win 3.
Win 3.1
Win 3.1 
Win3
Win3.1
Wind
Windo
Window
Window 
Window S
Window System
Window(
Windows 
Windows (
Windows 3
Windows 3.
Windows 3.0
Windows 3.0 
Windows 3.1
Windows 3.1 
Windows NT
Windows NT 
Windows a
Windows and
Windows and 
Windows app
Windows f
Windows fo
Windows for
Windows for 
Windows p
Windows pr
Windows s
Windows w
Windows?
Word f
X T
X W
X Win
X Window
X Window 
X Window S
X Window System
X app
X applica
X applicatio
X application
X c
X cl
X client
X d
X p
X pr
X pro
X se
X ser
X server
X server 
X te
X term
X terminal
X wi
X window
X"
X#
X'
X-window
X1
X11
X11/
X11/X
X11R
X11R4
X11R4 
X11R5
X11R5 
X11R5 a
X11R5 and
X7
X8
X9
X;
X=
X?
XC
XCo
XCop
XCopy
XCreate
XG
XH
XI
XJ
XK
XN
XO
XP
XPut
XPutImage
XPutImage(
XPutImage()
XR
XS
XSe
XSet
XTe
XU
XVi
XView
XView 
XW
X_
Xa
Xaw
Xc
Xd
Xde
Xdefault
Xl
Xli
Xlib
Xlib 
Xm
Xmu
Xo
Xp
Xr
Xs
Xse
Xserver
Xsu
Xt
Xt 
Xt,
XtA
XtC
XtW
XtWi
Xte
Xter
Xterm
Xv
Xvi
Xw
Xz
Y'
Y?
YG
YI
YL
YP
Y_
Yz
Z*
Z+
Z0
Z4
Z7
Z@
ZM
ZN
ZZ
Z[
Zz
["
[*
[+
[-
[0
[5
[7
[8
[9
[L
[M
[R
[T
[z
\"
\0
\1
\2
\7
\:
\;
\<
\M
\S
\T
\W
\n
]"
]'
],
]/
]1
]2
];
]F
]O
]S
]W
]]
]_
^[
^_
_                    
_                     
_                       
_'
_*
_4
_?
_H
_L
_M
_R
_X
_\ 
_\  
__          
__            
__             
__               
__                 
__                  
__                    
__                     
___          
____          
_g
_i
_n
_p
_r
_s
a Moti
a Motif
a Motif 
a X
a wid
a widget
a widget 
a win
a window
a.m
a.mi
a.mit
a.mit.edu
a.mit.eduM
age(
age()
ager a
ager t
ager to 
ager,
ager, 
ager.
agers
agers 
ags 
ainer 
akefile
akefile 
al X
allb
allback
allen
alleng
alog b
alse
am M
am ma
an X
an X 
an page
an x
anager 
anager a
anager i
anager t
anager to 
anager,
anager, 
anager.
anager. 
anagers
anagers 
and Mot
and Motif
and Op
and Ope
and Win
and Wind
and Windo
and Window
and Windows
and Windows 
and X
andler
andler 
anon 
any X
ap f
ap fi
ap file
ap fo
apane
app 
application 
application a
application c
application t
application th
application that
application that 
application w
application,
application, 
apps
apps 
ardson
aries a
aris 
arku
as es
as escape
ask,
at X
ateW
ateWi
athen
athena
athena.
ation is s
ave L
ay1
b/X
b/X11
b/X11/
b/p
bX
bar.
be considered
bin/
bitmaps
bmp 
bout X
builder
button 
buttons
bw
c/win
ca.i
ca.in
ca.indiana
ca.indiana.edu
cal C
callback
cation c
cation is
cation is 
cation th
cation that
cation that 
cc 
ce|
characters
characters 
child
cic
cica
cica.
cica.indiana
cica.indiana.edu
cica.indiana.edu 
cim
cim.
client
client 
clients
clients 
colorm
colormap
colormap 
comp.os.
comp.windows.
comp.windows.x
compiling
compiling 
cons 
contains the
contains the 
contex
context
croso
crosoft
cs.com
cs.m
cs.mi
cters
cursor
d Mic
d Mot
d Motif
d Motif 
d Op
d Ope
d Wi
d Win
d Wind
d Windo
d Window
d Windows
d Windows 
d X
d X 
d X11
d X11R
d lib
d librar
d libraries
d size
d win
d wind
d window
d windows
d.de
dMessage-ID: <1t
dWi
def 
defaults
defaults 
dget
dget 
dget s
dget t
dget,
dget, 
dget.
dgets
dgets 
dialog
dler 
dministrator
do ma
dow 
dow a
dow an
dow and 
dow m
dow ma
dow t
dow th
dows 
dows a
dows an
dows and 
dows o
dows on
dows on 
dows, a
drag
draws
e HP 
e MI
e MIT
e MIT 
e Man
e Manag
e Manage
e Manager
e Mot
e Moti
e Motif
e Motif 
e R5
e Sun
e Windows 
e X
e X 
e X s
e X server 
e X-
e X11
e X11 
e X11R
e Xlib
e Xlib 
e Xm
e Xs
e Xt
e a wi
e a win
e a window
e an X
e build
e button
e button 
e considered
e curs
e cursor
e cursor 
e default 
e event
e event 
e events
e font
e font 
e fonts 
e for X
e icon
e manager
e of X
e pointer
e resou
e resource
e resources
e shel
e shell
e text 
e the X
e the cur
e the wi
e the win
e the window
e title 
e to M
e to Microsoft
e widget
e widget 
e widgets
e win
e window
e window 
e window m
e window manage
e window manager
e window manager 
e windows
e windows 
e xt
e xte
e xterm
e()
e() 
e);
e: Ch
e: Cha
e: Challenge to Microsoft supporters.
e: Challenge to Microsoft supporters.I
e: Challenge to Microsoft supporters.In 
e: Challenge to Microsoft supporters.In article 
e: Challenge to Microsoft supporters.In article <
e: Wi
e: Win
e: Window
e: Windows 
e: X
eType
eType 
eWi
eWin
eWindow
each a
eated a
eating a
echo 
ectangle
ecute
ed X
ed X 
ed lib
ed librar
ed win
edef
edir
edirect
edraw
efault
efaults 
efil
efile
efile 
egro
egrou
eilly
eilly 
el: +
en W
en Wi
en(
enD
enL
enW
enWin
enWindow
enWindows
enWindows 
ena 
ena.
enge
enge 
enhanced
enhanced 
ent h
ent ha
ent va
enterp
enwi
er *
er Windows
er Windows 
er X 
erm 
erm a
erm w
erm.
erminals
erpoo
error:
ers.I
ert@
erver and 
erver f
erver i
erver t
erver w
erver.
erver. 
es X
escap
escape
esources 
et -
et X
et(
et, t
etC
etCl
etV
etW
execute
exit 
expo
expo.lcs.mit.
expo.lcs.mit.edu
expor
export
export.
export.lcs.mi
export.lcs.mit.edu
export.lcs.mit.edu 
expos
expose
ext i
ext s
eyp
f 1.
f Win
f Window
f Windows
f X
f X 
f applica
f application
f cod
f the wi
f the win
f the window
f wi
f widget
f win
f window
f x
file (
file r
font 
font s
fonts.
for Wi
for Win
for Windows 
for wi
for win
for window
for windows
for windows 
from X
ft s
ft.c
ftp.ci
ftp.cica
ftp.cica.indiana
ftp.cica.indiana.edu
ftp.cica.indiana.edu 
fts
fue
g St
g X
g X 
g box
g win
g x
gcc
gcc 
ge n
ge to M
ger,
ger, 
ger. 
ger.  
gets, 
grp
gwu
h Win
h Window
h Windows
h Windows 
h X
h X 
h cha
h the w
h win
h windo
h window
h x
halle
halleng
hallenge
hallenge 
hallenge to M
hallenge to Microsoft 
handler
handler 
hared
hared 
hat X
he HP
he MI
he MIT
he MIT 
he Sun
he Wind
he Window
he X
he X 
he Xt
he applic
he application
he application 
he button
he cal
he call
he cursor 
he default 
he exa
he font
he pat
he server i
he title
he title 
he val
he value
he wi
he wid
he win
he window
he window 
he x
hell.
hena
hild
i fi
i file
ialo
ialog
ialog 
ian@
iase
ib 
ib,
ib/
ib/X
ib/X11
ica.in
ical C
ication c
ication i
ication is
ication is 
ication t
ication th
ication that
ication that 
ication w
icons
icons 
icroso
icrosoft
icrosoft 
icrosoft s
icrosoft.
ics.c
ics.co
ics.com
idget
idget 
idget i
idget s
idget t
idget,
idget, 
idgetC
idgets
idgets 
idth,
ients
ients 
if (
if 1
if wi
if, 
if.
ii.
il.a
ile M
ile n
in /
in 3.
in 3.1
in 3.1 
in W
in Wi
in Win
in Window
in Windows
in Windows 
in Windows 3.
in Windows 3.1
in X
in X 
in X11
in the X
in win
in window
in/
in3
in3.
in3.1
in3.1 
inals 
indo
indow
indow 
indow a
indow an
indow and 
indow i
indow is
indow is 
indow m
indow ma
indow man
indow manage
indow manager
indow managers
indow o
indow s
indow t
indow th
indow to
indow to 
indow w
indow wi
indow(
indow,
indow, 
indow.
indow. 
indow.  
indow?
indows 
indows (
indows 3
indows 3.
indows 3.0
indows 3.0 
indows 3.1
indows 3.1 
indows NT
indows NT 
indows a
indows an
indows and
indows and 
indows app
indows application
indows b
indows f
indows fo
indows for
indows in
indows is
indows is 
indows o
indows on
indows on 
indows p
indows pr
indows pro
indows s
indows t
indows w
indows, a
indows.  I
indows?
indowsI
ing Mo
ing Mot
ing Motif
ing Sun
ing X
ing X 
ing X11
ing X11R
ing X11R5
ing a w
ing for X
ing the X
ing win
ing wind
ing window
ing windows
ing x
inter d
inval
invalid
invok
invoke
ioc
ion file
ion of W
ion of X
is 2.
isual 
it(
it.eduM
ith W
ith X
ith wi
ith win
ith x
itmaps
ixm
ixma
ixmap
ixmap 
k |
k.com 
k.comz
kits 
ktr
l Pa
l Pan
l X
l win
l wind
l window
l windows
lX
lags
laris
laris 
lcs.mit.edu 
ld:
ld: 
le Man
le X
le na
le win
le window
lect a
lect a 
lib 
lib/
lib/X
lib/X11
lib/X11/
libX
lication i
lication w
lication,
lication, 
lien
lient
lient 
lients
lients 
lkits
ll X
ll win
ll wind
ll window
llba
llback
lloc
logo
loura
louray
louray@seas.gwu.edu
louray@seas.gwu.edu 
m Man
m Manager
m X
m.g
m.ga
m.i
mN
macr
macro
mage(
makefile
manager
manager 
manager t
manager to 
manager,
manager, 
manager.
manager. 
managers
managers 
mand line
map f
map fo
map,
map, 
map.
map. 
mask 
mbol
me X
ment va
microsoft
motif
motif 
mple i
ms-win
ms-windows
mu 
mwm
my ap
my app
my application
n /
n 3.1
n 3.1 
n Des
n Desk
n Desktop
n Loo
n Mot
n Op
n Ope
n Open
n Wi
n Win
n Windo
n Window
n Windows
n Windows 
n Windows 3.
n Windows 3.1
n X
n X 
n X s
n X server
n X server 
n X-
n X1
n X11
n X11R
n X11R5
n X11R5 
n Xt
n a wi
n a win
n a window
n expo
n export
n of W
n page
n start
n the X
n the app
n the wi
n the win
n the window
n under 
n win
n window
n windows 
n with X
n x
n xt
n xterm
n xterm 
n()
n.in
n3
n3.
n3.1
n3.1 
n3/
nL
nLoo
nO
nOS
nOS 
nW
nWi
nWin
nWindow
nWindows
nWindows 
nWindows 3
nWindows 3.
nX
na.m
nbi
nd Wi
nd Win
nd Wind
nd Windo
nd Window
nd Windows
nd Windows 
nd X
nd repl
ndef
ndefin
ndefined
ndefined 
ndler
ndler 
ndow
ndow 
ndows 3
ndows 3.
ndows 3.1
ndows 3.1 
ng St
ng X
ng for X
nge to 
nitialize
nked
nning X
nsic
nsort
nter d
nterpo
ntex
ntext
ntrin
ntrinsic
ntrinsics
nval
nvalid
nvok
nvoke
nwin
o Mi
o Micro
o Micros
o Wi
o Win
o Window
o Windows
o Windows 
o X
o X 
o compile
o the X
o the se
o the w
o win
o wind
o window
o.l
o: x
of Window
of Windows
of X
of cod
of the X
of the wi
of the win
of the window
of wi
of win
oft 
oft.
oft.c
oft.com
og b
ointer 
okes 
olari
olaris
olaris 
olaris 2
olorm
olormap
olormap 
olwm
olwm 
ommand line
ompiling
ompiling 
on Su
on Wi
on X
on ex
on exp
onsol
onsort
onsortium
ont s
ontains the 
ontex
ontext
ontext 
onts.
oolkits
oop.
oot w
oot wi
op.
opup
or Wi
or Win
or Windows 
or Wo
or Wor
or X1
or X11
or a fi
or win
or window
ord f
ord for
ord for 
oregr
oreground
orkgroup
orter
ose e
ose event
osoft
osoft 
osoft.
ot st
otif
otif 
otif 1.
otif 1.1
otif a
otif w
otif wi
otif,
otif, 
otif.
ould  
ould not be 
our X
our app
our wi
ources a
ouse b
out X
overr
override
ow ma
ow man
ow(
ows (
ows 3
ows ap
ows app
ows application
ows f
ows on
ows p
ows pr
ows pro
ows program
ows s
ows, a
ows?
p an 
p file 
p(
p.ci
p.m
p.mi
p.o
p.w
p.win
p.windows
pS
pars
patche
patches 
pe-
ped!
penwi
penwin
pert@
pital 
pixmap
pixmap 
plication a
plication t
plication th
plication w
po.
pointer 
pp 
pplication 
pplication i
pps 
printer d
prism
pub/pc/
pub/pc/win3
pub/pc/win3/
pup
r *
r Mot
r Motif
r Sun
r Wi
r Win
r Windo
r Window
r Windows
r Windows 
r Windows 3.
r Windows 3.1
r X 
r X windows
r X1
r X11
r X11R
r X11R5
r dra
r draw
r mou
r server
r win
r window
r window 
r windows
r windows 
r xt
r/l
r: news@
rWi
rX
r_
rce t
reating a
reating a 
red l
red li
redir
redr
redraw
regr
rek 
resiz
resize
resource 
resources 
rgs
ris 2
rism.
rku.
rm w
rmap
rmap 
rogram M
rogram m
roman
root 
roperties
rosoft 
rror:
rs.In
rt@
rters
rters.
running X
s 2.
s 3.
s 3.0
s 3.0 
s 3.1
s 3.1 
s = 
s NT
s NT 
s X
s X 
s application
s compil
s compile
s escap
s for W
s for Win
s for wi
s for window
s for windows
s of X
s the X
s the wi
s win
s window
s window 
s x
s-w
s-wi
s.In
s.In 
s.In a
s.In article 
s.In article <
s.mi
s.mit
s.mit.
s.mit.edu
s.mit.eduI
s.mit.eduz
s.x
s@a
s@at
sSender: n
scap
scape
se ev
se eve
se even
se event
se x
ser f
server 
server (
server and 
server f
server i
server t
server w
server.
server. 
server.  
set in
shared
shared 
shell 
shell.
sing X
sion in 
soft 
soft s
soft.
soft.c
soft.com
sorti
source i
sources a
string
sual,
sual.
swap f
swap file
symbol
t Su
t X
t X 
t compi
t compil
t font
t for W
t load
t specifi
t supporte
t the X
t the wi
t the win
t the window
t variable
t widget
t win
t window
t window 
t windows
t windows 
t()
t) m
t, X
t.l
t: e
t: ro
t: x
t@e
t@ex
t@expo
t@expo.lcs.mit.
t@expo.lcs.mit.edu
tA
tApp
tE
tFo
tH
tIm
tImage
tImage(
tImage()
tRe
tSe
tV
tVa
tW
tWi
tWin
tWindow
tWindow(
tX
teW
term 
term w
term.
terminal
terminal 
terminals
terminals 
ters.I
text.
th Win
th Windows
th X
th X 
th X11
th X11R
th x
the MI
the MIT
the MIT 
the Motif
the Sun
the Wind
the Window
the X
the X 
the X11
the Xt
the appl
the applic
the application
the application 
the cal
the client
the icon
the resource
the server
the val
the value
the wi
the win
the window
the window 
the window manager
the window manager 
the x
thena
thena 
thena.
thom
tialize
tif 
tif,
tif, 
tionS
to M
to Mi
to Micro
to Wi
to Win
to Window
to Windows
to Windows 
to X
to compile
to compile 
to the X
to the se
to the w
to wi
to win
toolkits
tring
ts fil
ts file
tton 
tvt
tvtwm
twm
twm 
uMessage-ID: <
ueT
ueType
ulder
ult f
un3
unO
unOS
unOS 
unOS 4
unOS 4.
unOS 4.1
unOS 4.1.
undef
unnecessar
unning X
upporter
upporters
ur app
uray
urso
ursor
ursor 
use X
use x
using X
usr
ut X
utton 
uttons
uttons 
vent t
ver us
ver?
verr
verrid
verride
vok
voke
vtwm
w System
w man
w(
w_
widget
widget 
widgets
widgets 
win 
win3
wind
windo
window
window 
window a
window an
window i
window is
window is 
window m
window ma
window man
window manage
window manager
window manager 
window o
window s
window t
window to
window to 
window w
window,
window, 
window.
window. 
window.  
windows
windows 
windows 3
windows 3.
windows a
windows an
windows o
windows on
windows on 
windows,
windows, 
windows.
windows.  
with W
with Win
with Windows
with X
with X 
with X11
wm
wm 
wm,
wm.
ws (
ws 3
ws 3.
ws 3.0
ws 3.1
ws N
ws ap
ws app
ws application
ws is
ws pr
ws pro
ws se
ws to
ws, a
ws?
ws@
wu.edu 
xcl
xd
xdm
xecute
xit 
xm
xma
xpert
xpert@
xpert@expo
xpert@expo.lcs.mit.
xpert@expo.lcs.mit.edu
xpo
xport.
xport.lcs.mi
xport.lcs.mit.edu
xpos
xpose
xpose 
xpose event
xr
xse
xt i
xterm
xterm 
xterm.
xwi
y Windows
y X
y X 
y appl
y appli
y applica
y application
y application 
y mou
y to ma
y win
y wind
y window
y x
yW
ymb
ymbol
ype-
z X
z#
z'
z*
z7
zE
zNNTP-Posting-Host: e
zNNTP-Posting-Host: en
zNNTP-Posting-Host: enterpoop.mit.edu
zNNTP-Posting-Host: enterpoop.mit.eduTo: 
zNNTP-Posting-Host: enterpoop.mit.eduTo: x
zNNTP-Posting-Host: enterpoop.mit.eduTo: xpert
zNNTP-Posting-Host: enterpoop.mit.eduTo: xpert@expo.lcs.mit.edu
zTo
zTo: 
zTo: x
zTo: xpert@expo.lcs.mit.edu
zU
zV
zY
z_
