							 
							  
				d
			d
			f
		"
		/*
		c
		f
		i
	 A
	#
	..
	...
	/*
	/* 
	19
	Ge
	Sun
	Whe
	X
	ch
	echo 
	ex
	exp
	if
	if 
	x
	{
	}
 	e
                                   .
                                   ...
                                || C
                              .
                              ..
                             ..
                            ..
                            ...
                           || C
                          i
                     ..
                     ____
                    ..
                    ____
                  ..
                  ____
                 ____
                 _____
                ..
                Pho
                | E
               UU
               UUCP:
               ____
               _____
               ______
               ________
               _________
               | E
              ____
              ________
              _________
              to
             ...!
             X
             || C
            From
            X
            ____
            | t
            || C
           UU
           UUCP:
           UUCP: 
           | E
           | t
          _______
          ________
          _________
          | E
          | t
          | th
         Fr
         Fro
        Fr
        Mai
        {
        | w
       A 
       Fr
       Fro
       Q
       Qu
       UUCP:
       UUCP: 
       ex
       | t
       | th
      +4
      ...!
      /*
      A 
      Fax: 
      Fr
      Fro
      From
      From the 
      Q
      Qu
      Su
      Voice
      Voice: 
      app
      ex
      x
      | "T
      | E
      | E-
      | E-mail
     ...!
     ...!u
     ...!uunet!
     /*
     Fr
     Mich
     Q
     Qu
     Voice
     Win
     Xt
     ____ 
     app
     application
     de
     ex
     that
     that 
     un
     | Tel
     | w
     || I
     || In
    &
    - A
    ...!
    ...!u
    ...!uunet!
    /*
    /* 
    Fax:   
    Fr
    Fro
    Internet 
    Je
    Q
    Qu
    UUCP
    UUCP:
    UUCP: 
    Vo
    Voice
    Voice: 
    West
    Win
    Wind
    Window
    Xm
    Xt
    _-
    __/
    app
    application
    are
    are 
    de
    def
    ex
    exp
    if (
    int 
    lo
    prin
    print
    ru
    that
    that 
    up
    { 
    {  
    | T
    | Tel
    | t
    | th
    || C
    } 
    }    
   &
   (_
   */
   ...!
   ...!u
   ...!uunet!
   /   /
   /*
   /* 
   /\/
   3)
   Fax:  
   Fax:   
   If you do
   Mail
   Some
   Vo
   Voice
   Voice: 
   Wind
   Window
   Windows
   X
   XF
   XS
   XSet
   Xm
   Xt
   XtA
   ____ 
   ____  
   ____   
   ____    
   ____     
   ____       
   app
   application
   applications
   applications 
   be 
   case
   def
   ins
   int 
   lo
   more
   ru
   sl
   start
   str
   that
   that 
   up
   win
   wor
   | "T
   | Te
   | t
   || C
   } 
  "If 
  "w
  &
  (_
  */
  *h
  ++
  +44
  +44 
  - L
  -o
  -or-
  -or- 
  ...!
  ...!u
  ....
  /   / 
  /*
  /* 
  /* d
  /--
  /---
  /-----------------
  /-----------------------
  /\/
  55
  : +
  : +4
  :-
  :-)
  ===========================================================
  =====================================================================
  ======================================================================
  ========================================================================
  E-Mail
  For a f
  From th
  From the
  From the 
  Greg
  Has anybody 
  It l
  Laz
  MIC
  Mot
  NT
  Otherwise
  Tel: +
  The N
  The Ne
  The Netherlands
  The X
  Wes
  XF
  XS
  XSet
  Xm
  Xt
  XtA
  You have
  You have 
  You have t
  You have to
  \--
  \----
  \-----------------------
  \---------------------------
  _-
  __/
  __/ 
  ____   
  ____    
  ____     
  ____       
  case
  cla
  default
  if (
  int 
  kn
  kno
  know
  out
  ret
  return
  return 
  serv
  sho
  should 
  start
  str
  win
  window
  | E-mail
  | E-mail: 
  | Mar
  | Te
  | Tel
  | t
  | th
  } 
 !=
 ""
 "$
 "-
 ".
 "Ca
 "K
 "Li
 "Mo
 "X
 "X 
 "we
 "wel
 "well 
 "x
 #  
 #0
 #define
 #define 
 #i
 #if
 #include 
 $H
 $HO
 $HOME
 &&
 && 
 &a
 ' 
 '-
 'A
 (+4
 (Christ
 (Don
 (Ger
 (Ku
 (Kurt 
 (MS
 (MS 
 (MS MOUSE)
 (Michael P
 (Some
 (Some 
 (X
 (X11
 (X11R
 (X11R4
 (dis
 (disp
 (form
 (inv
 ****** 
 *.
 */
 */ 
 */  
 */   
 */    
 *h
 ++
 - what is 
 -- so
 -L
 -O
 -O2
 -c
 -d
 -e
 -f
 -g
 -i
 -l
 -lX
 -lX11
 -lX11 
 -lX11 -
 -lXext
 -lXext 
 -lXext -
 -lXmu
 -lXmu -
 -lXt
 -lXt 
 -m
 -n
 -o
 -o 
 -p
 -t
 ...!
 ...!u
 ...!uunet!
 ...!uunet!s
 ./
 .X
 .Xdefault
 .Xdefaults
 .Xdefaults 
 .bmp
 .bmp 
 .gr
 .grp 
 .grp file
 .l
 .login
 .x
 /  \ 
 /  \  
 / m
 /*
 /* 
 /-----
 /-----------------
 /-----------------------
 /---------------------------------------------
 /X
 /b
 /co
 /contrib
 /contrib/
 /de
 /dev/
 /t
 /u
 /us
 /usr
 /usr/
 /usr/l
 /usr/lib
 /usr/lib/
 /usr/lib/X11
 /usr/lib/X11/
 0)
 0);
 0,
 0. 
 0;
 0; 
 0H
 1"
 1.1.
 1.2.
 1;
 201
 223
 231
 255
 277
 3.0 a
 3.0 and 
 3.0 o
 3.00 
 3.1
 3.1 
 3.1 and 
 3.1 i
 3.1?
 3.2
 3.2.
 4.1
 4.1.
 4.1.1
 4.1.2
 4.1.3
 4.1.3 
 4.3
 500.
 6 a
 6 an
 748
 891
 : +
 : +4
 : +49
 <14
 <1993Apr30.1
 <1993Ma
 <1993May
 <1993May1
 <1993May14.
 <1rl
 <1sr
 <1t
 <9
 <93
 <930
 <9304
 <93041
 <930419
 <9304191
 <93042
 <930421
 <9305
 <<
 << 
 <B
 <C6
 <C7
 <K
 <W
 <X
 <X11/
 <X11/X
 <x
 = 0;
 = 0; 
 = 0;  
 = X
 = XCreate
 = Xt
 A. D
 API 
 ATM
 ATM 
 Administrator
 Astr
 Astro
 Astron
 Astronom
 Astronomy
 Astronomy 
 Ath
 Athe
 Athen
 Athena
 Athena 
 Athena widget
 Avenue 
 B. L
 BJ
 BJ200 (
 BMP f
 BMP file
 BMP files
 BR
 BSD 
 Bett
 Better
 Boll
 Bollacker
 Bor
 Borland
 Button
 C. R
 C/
 CB
 COLO
 CU
 Cann
 Canno
 Canon
 Canon 
 Canon B
 Canon BJ
 Canon BJ200
 Canon BJ200 
 Canon BJ200 (BubbleJet) 
 Case
 Chal
 Challenge
 Challenge 
 Client
 Colormap
 Compiling 
 Conso
 Consort
 Consortium
 Consortium 
 Control 
 Cool 
 Curs
 Cursor
 Cursor 
 D-4
 DISP
 DISPLAY
 DISPLAY 
 DOS 6 
 DOS and W
 DOS and Windo
 DOS and Windows
 DOS and Windows 
 DOS app
 DOS b
 DOS box
 DOS program
 DOS window
 DOS window 
 DOS/
 Data i
 Dave L
 David B
 Default
 Der
 Derek
 Derek 
 DeskJet
 DeskJet 
 DeskJet 5
 DeskJet 500.
 Desktop f
 Desktop for 
 Desktop for Windows
 Diamond SS
 Diamond SS24
 Dortmund
 Dos 6 
 Drawing 
 Driver for 
 E-Mail: 
 E-mail: d
 EISA v
 Earl
 Eck
 Enc
 Engineering   
 Error co
 Events
 Expo
 Expos
 Expose
 Expose 
 FOR A
 Fals
 Fax : 
 Fax : +
 Fax: (02
 File Manager
 Font 
 Forc
 GX
 Geophysic
 German 
 Graphical
 Greg 
 Guide
 HD di
 HP 9
 HP 9000
 HP DeskJet
 HP DeskJet 
 HP DeskJet 500
 HP DeskJet 500.
 HP-UX
 HP-UX 
 HP-UX 8.
 Hold
 I ain't 
 I change 
 I create
 I create 
 I exit
 I have a p
 I move
 I start
 I start 
 I started 
 I try to r
 ICC
 ICS
 IN W
 IPC
 If you g
 Imake
 Imakefile
 Imakefile 
 In this
 In this 
 Intri
 Intrinsic
 Intrinsics
 It is th
 It look
 It looks 
 It n
 It no
 JU
 JUMP
 L. M
 LD
 LOOK
 Laz
 Lazarus 
 Lazarus Long
 Litt
 Lot
 MAC DISK
 MIC
 MICH
 MICHAEL 
 MIT
 MIT 
 MIT X
 MIT X11R
 MIT X11R5
 MOU
 MOUSE
 MS W
 MS Win
 MS Window
 MS Windows
 MS Windows 
 MSW
 Mah
 Maha
 Makefile
 Makefile.
 Managers
 Mark A
 Microso
 Microsoft
 Microsoft 
 Microsoft s
 Microsoft supp
 Mix
 Moore
 Moti
 Motif
 Motif 
 Motif 1.
 Motif 1.1
 Motif 1.2
 Motif 1.2 
 Motif W
 Motif a
 Motif and
 Motif and 
 Motif i
 Motif t
 Motif to
 Motif w
 Motif wi
 Motif widget
 Motif,
 Motif, 
 Motif.
 Motif. 
 NCD
 NCD 
 ND
 NDW
 NDW 
 NT -
 NT - 
 NT,
 NT.
 NULL
 NULL)
 NULL,
 Network S
 No o
 Norton D
 Norton Desktop
 Norton Desktop 
 Norton Desktop for 
 Norton Desktop for Windows
 Notebook
 Notebooks
 Notebooks 
 O'R
 O'Reilly
 O'Reilly 
 OD
 OI
 OL
 OLIT
 OPE
 OPEN
 OW
 OW 
 Oliver
 Open
 Open Look
 OpenL
 OpenLook
 OpenWin
 OpenWindows
 OpenWindows 
 OpenWindows 3
 OpenWindows 3.
 OpenWindows 3.0
 OpenWindows 3.0 
 Otherwise
 PAN
 PANA
 PK
 Packard
 Pana
 Perm
 Permission 
 Pixmap
 Pop
 PostScript an
 Poste
 Program M
 Program Manager
 Program Manager 
 Pseudo
 PseudoColor
 R3
 R4
 R4 
 R5
 R5 
 Raine
 Re: X
 Re: X 
 Release 
 Richardson
 Richardson 
 Rob 
 Running 
 SDK
 SDK 
 SHA
 SMA
 SPARC 
 SS
 SS 
 SS 24X
 SS2
 SS24
 SS24X
 SUMMARY
 SVR
 SVR4
 SVR4 
 Save
 Setup
 Shel
 Shell
 Solar
 Solari
 Solaris
 Solaris 
 Solaris 2
 Solaris 2.
 Solaris 2.1
 Startup
 Static
 Sun 3
 Sun O
 Sun Open
 Sun3
 SunO
 SunOS
 SunOS 
 SunOS 4
 SunOS 4.
 SunOS 4.1
 SunOS 4.1.
 SunOS 4.1.1
 Systems     
 Systems L
 TCP
 TCP/IP
 Tai
 Technical Co
 Technical Con
 Technical Conference
 Tek
 Tekt
 Tektroni
 Tektronix
 Tel: +
 Telecom 
 The X
 The X 
 This is a s
 Title
 Trou
 Trouble
 Trouble 
 TrueType
 TrueType 
 TrueType font
 U. 
 U.K. 
 U.K.  
 UI
 UIM
 UNIX)
 Ultrix 
 Unix s
 Unix system
 Utility
 Utility 
 Utility f
 V3
 VB
 Visual 
 W4
 W4W
 WIN
 WIN.
 WINDO
 WINDOW
 WINDOWS
 WINDOWS 
 WM
 WP
 WS
 When I t
 When I tr
 Why is
 Why is 
 Why is my 
 Wid
 Widg
 Widget
 Widget 
 Widgets
 Widgets 
 Wie
 Win 
 Win 3
 Win 3.1
 Win 3.1 
 Win 3.1, 
 Win NT 
 Win.
 Win3
 Win3.1
 Win3.1 
 WinQVT
 Window 
 Window M
 Window Manager
 Window S
 Window System
 Window System 
 Windows 
 Windows (
 Windows 3.
 Windows 3.0
 Windows 3.0 
 Windows 3.1
 Windows 3.1 
 Windows 3.1 a
 Windows 3.1?
 Windows NT
 Windows NT 
 Windows S
 Windows a
 Windows and 
 Windows app
 Windows f
 Windows fo
 Windows for
 Windows for W
 Windows for Work
 Windows h
 Windows p
 Windows pr
 Windows r
 Windows re
 Windows s
 Windows se
 Windows t
 Windows w
 Windows wi
 Windows.  I
 Windows?
 Word f
 Word for
 Word for 
 Word for Windows
 Word for Windows 
 Workgroup
 Workgroups
 X
 X 
 X (
 X C
 X Co
 X Con
 X D
 X R
 X Re
 X Res
 X Resource
 X S
 X Se
 X Server
 X T
 X Te
 X Toolkit
 X Win
 X Window
 X Window 
 X Window S
 X Window System
 X Window System 
 X a
 X an
 X and
 X and 
 X app
 X applica
 X applicatio
 X application
 X application 
 X b
 X c
 X client
 X clients
 X co
 X d
 X di
 X dis
 X display
 X f
 X fo
 X i
 X in
 X p
 X pr
 X pro
 X program
 X protocol
 X protocol 
 X r
 X re
 X s
 X se
 X server
 X server 
 X server.
 X server. 
 X servers
 X t
 X te
 X term
 X terminal
 X w
 X wi
 X window
 X window 
 X windows
 X windows 
 X-
 X-s
 X-server
 X-server 
 X-te
 X-terminal
 X.
 X. 
 X.  
 X/
 X/Motif
 X/Motif 
 X1
 X11
 X11 s
 X11 se
 X11R
 X11R3
 X11R4
 X11R4 
 X11R5
 X11R5 
 X11R5 a
 X11R5 and
 X11R5 and 
 X11R5 o
 X11R5 on 
 X11R5 s
 X11R5,
 X11R5, 
 X?
 X? 
 XA
 XC
 XCo
 XCopy
 XCopyArea
 XCopyArea()
 XCreate
 XCreateWindow
 XD
 XDM
 XDraw
 XE
 XF
 XFree
 XFree86
 XFree86 
 XG
 XGet
 XI
 XN
 XO
 XOpen
 XOpenDisplay
 XP
 XPut
 XPutImage
 XPutImage()
 XQ
 XR
 XRe
 XS
 XSe
 XSet
 XTe
 XTerm
 XU
 XV 3.
 XV 3.00 has
 XVi
 XView
 XView 
 XW
 XWi
 XWindow
 XWindows
 XWindows 
 Xa
 Xaw
 Xaw 
 Xc
 Xd
 Xl
 Xli
 Xlib
 Xlib 
 Xlib f
 Xlib.
 Xm
 XmN
 Xp
 Xperts
 Xs
 Xse
 Xserver
 Xserver 
 Xsun
 Xsun 
 Xt
 Xt 
 Xt i
 Xt in
 Xt,
 Xt, 
 XtA
 XtAdd
 XtApp
 XtC
 XtD
 XtDisp
 XtN
 XtP
 XtR
 XtRe
 XtS
 XtSet
 XtVa
 XtWi
 XtWindow
 XtWindow(
 Xter
 Xterm
 Xterm 
 Xv
 Xvi
 Xview
 [T
 [a
 [t
 \----
 \-------
 \n
 \n\
 _/_/_/  _/
 __/
 __/ 
 a "m
 a Ba
 a HD di
 a Mo
 a Moti
 a Motif
 a Motif 
 a SP
 a SPARC
 a X
 a bitm
 a bitmap
 a bitmap 
 a button 
 a cg
 a cli
 a client
 a confi
 a dial
 a dialog
 a dialog 
 a fir
 a first 
 a font
 a font 
 a function
 a function 
 a large number
 a large number of 
 a menu
 a pointe
 a pointer
 a pointer 
 a problem wh
 a problem whe
 a proper
 a rem
 a remo
 a remote
 a remote 
 a resou
 a resource
 a server
 a server 
 a shel
 a shell
 a stri
 a text 
 a tool
 a val
 a valu
 a value
 a virtual
 a virtual 
 a wi
 a widget
 a widget 
 a win
 a window
 a window 
 a window manager
 a window manager 
 a window manager t
 a window manager to 
 a window o
 a window t
 a windows
 a windows 
 about X
 about your
 accepted 
 ace
 actions 
 ain
 ain't 
 all wi
 all window
 allocate 
 allocati
 an X
 an X 
 an X s
 an X server
 an X server 
 an X window
 an X-
 an Xt
 an easy 
 an expos
 an expose
 an ftp site
 an ftp site 
 an x
 an xt
 an xterm
 an xterm 
 and /
 and DE
 and Mot
 and Motif
 and Motif 
 and Motif 1.
 and Op
 and Ope
 and Open
 and Wi
 and Win
 and Wind
 and Windo
 and Window
 and Windows
 and Windows 
 and X
 and X 
 and X11R5
 and Xt
 and conf
 and config
 and lib
 and pas
 and rest
 and then r
 and windows
 and x
 another ma
 another t
 any X
 any ne
 any wi
 app 
 app-
 appear in 
 appears th
 appen
 application 
 application a
 application an
 application and 
 application c
 application f
 application ha
 application i
 application is
 application is 
 application t
 application th
 application that
 application that 
 application to
 application to 
 application w
 application wh
 application,
 application, 
 application?
 applications an
 applications i
 apps
 apps 
 apps a
 apps, 
 are im
 are imp
 are pu
 are running
 are set
 args
 arguments
 arguments 
 article <1993Ma
 article <1993May
 article <1993May1
 article <C6
 as X
 as x
 as:
 asho
 asking for 
 assumes
 at ru
 attribute 
 avoid th
 bar 
 based on X
 be accept
 be awa
 be aware
 be aware 
 be called 
 be consid
 be consider
 be considered
 be considered 
 be dr
 been wr
 been wrong
 beta test
 binaries
 bitmaps
 bitmaps 
 brown@
 builder
 builder 
 but I'd
 button 
 button w
 button.
 by X
 by the u
 by the use
 call X
 callback
 can I use
 can do this
 can't find th
 capital
 capital 
 catch 
 cc 
 cca
 ccastco@prism.gatech.
 change it
 characters
 characters.
 child
 child 
 children
 cica
 cica 
 class.
 click on
 click on 
 client
 client 
 client a
 clients
 clients 
 clients t
 clients, 
 code 1
 code.  
 colorm
 colormap
 colormap 
 colormap, 
 colormap.
 colormaps
 comes up
 command line
 command line 
 command to
 command.
 communication is 
 communication is s
 comp.os.ms-windows.
 comp.sources.x
 comp.windows.
 comp.windows.x
 comp.windows.x 
 comp.windows.x.
 compilation
 compile a
 compiled i
 compiled with
 compiles 
 compiling
 compiling 
 compiling X
 configuration f
 configuration file
 connection t
 connection to 
 considered  
 consol
 console
 console 
 contex
 context
 context 
 contrib 
 convention
 coordinates for 
 core d
 created a
 creating a 
 crim
 crime
 csh
 curs
 cursor
 cursor i
 davi
 david
 db
 dbl
 dcr@mail.ast.cam.ac.uk
 dcr@mail.ast.cam.ac.uk 
 default c
 default co
 default f
 default fo
 defined in
 defined in 
 defrag
 delete t
 developing a
 dialog
 dialog 
 dialog box
 dialog box 
 directory?
 do I f
 do I g
 do I get 
 do ma
 do make 
 do this i
 doesn't a
 doesn't p
 doesn't seem 
 doesn't seem to
 doesn't seem to 
 doing wrong
 doing wrong?
 done. 
 drag
 draw t
 drawn 
 drawn in
 driver?
 each a
 each time
 each w
 emac
 emacs
 emb
 embe
 embed
 emm
 emulator 
 enhanced
 enhanced 
 enter
 enterp
 enterpoop
 enterpoop.
 entries 
 entry in
 environment vari
 environment variable
 environment variable 
 environment variables
 error:
 error: 
 esc
 escap
 escape
 escape 
 escape sequence
 escaped
 eva
 eval
 evalu
 evaluat
 event 
 event ha
 event handl
 event handler
 event is
 events
 events 
 events.
 example i
 example in 
 examples
 examples 
 except that
 except that 
 exception of
 executables
 executables 
 execute
 execute 
 executed
 existence
 exit
 exit 
 expo
 export 
 export.
 export.lcs.mi
 export.lcs.mit.edu
 export.lcs.mit.edu 
 export.lcs.mit.edu in
 export.lcs.mit.edu in 
 export.lcs.mit.edu:
 expos
 expose
 expose 
 expose event
 expose event 
 expose events
 fals
 false
 fatal
 feature of
 file (
 file d
 file de
 file e
 file l
 file manage
 file manager
 file n
 file nam
 file name
 file r
 file re
 file, a
 file, and
 file, and 
 filem
 files I
 files u
 files un
 first l
 first of
 first off
 flags
 following li
 font 
 font f
 font i
 font is 
 font s
 font t
 font.
 fonts are
 fonts i
 fonts in
 fonts in 
 fonts t
 fonts w
 fonts.
 fonts. 
 for Motif
 for Wi
 for Win
 for Windows 
 for Windows 3.
 for Windows 3.1
 for Wor
 for Work
 for X1
 for X11R
 for X11R5
 for a file
 for a wi
 for a window
 for drawing
 for some re
 for the X
 for the foll
 for the pro
 for the program
 for updat
 for wi
 for win
 for window
 for windows
 for windows 
 forW
 foreground
 foreground 
 foreground a
 found w
 framebuffer
 from Wi
 from Win
 from Windows
 from X
 from expo
 from export
 from export.
 from export.lcs.mi
 from export.lcs.mit.edu
 from scr
 from scratch
 ftp-
 ftp.c
 ftp.ci
 ftp.cica
 ftp.cica.indiana
 ftp.cica.indiana.edu
 ftp.cica.indiana.edu 
 fue
 function c
 function ca
 function t
 function.
 function. 
 functions t
 gc
 gcc
 gcc 
 get co
 handler
 handler 
 have several
 headers
 help s
 hierarch
 hostname
 how is
 how you
 how you 
 hp
 ico
 icon
 icon 
 iconi
 iconize
 icons
 icons 
 id 
 if (
 if the wi
 illustrat
 illustrate
 imake
 imake 
 implements
 implements 
 in .
 in /
 in /u
 in /usr
 in /usr/
 in /usr/l
 in /usr/lib
 in /usr/lib/X11
 in W
 in Wi
 in Win
 in Window
 in Windows
 in Windows 
 in Windows 3.
 in Windows 3.1
 in X
 in X 
 in X11
 in X11R
 in X11R5
 in Xt
 in a window
 in an i
 in conf
 in cont
 in contr
 in my .
 in the X
 in the X 
 in the app
 in the file
 in the following
 in the man
 in the wi
 in the win
 in xterm
 index f
 info@
 initialize
 instance 
 interesting t
 interface to
 into a p
 intrinsic
 intrinsics
 inval
 invalid
 invok
 invoke
 invoked
 invoked 
 is         
 is X
 is genera
 is generated
 is in a
 is install
 is installed
 is it??
 is my m
 is my mo
 is sen
 is sent
 is speci
 is specifi
 is welcome
 it may not
 it, o
 it.	
 it??
 itself, 
 kl
 knowing wh
 large number
 large number 
 large number of 
 latest d
 latest driver
 latest drivers
 leak
 libX
 libXm
 libXmu
 libraries a
 libraries and
 libraries, 
 like W
 linke
 linked
 linked 
 loads 
 logg
 logo
 louray@seas.gwu.edu
 louray@seas.gwu.edu 
 macr
 macro
 macro 
 macros
 make a m
 makefile
 man page
 man page 
 man pages
 man pages 
 manager
 manager 
 manager a
 manager i
 manager t
 manager to 
 manager w
 manager,
 manager, 
 manager.
 manager. 
 manager.  
 managers
 managers 
 manual p
 manual page
 mark@t
 mask 
 memory r
 memory re
 metric
 mit
 mit/
 mli
 monthly
 most use
 motif
 motif 
 mouse b
 mouse button
 mouse button 
 mouse in
 mouse in 
 mouse o
 mouse s
 mouse so
 ms-
 ms-win
 ms-windows 
 mt
 multiple w
 mw
 mwm
 mwm 
 my  
 my   
 my .
 my W
 my X
 my ap
 my app
 my application
 my application 
 my mouse
 my mouse 
 my program 
 my wi
 my win
 my window
 my x
 naming 
 nav
 need to do i
 need to do is
 never been w
 never been wrong
 new i
 new wi
 non-pro
 not   
 not at
 not be co
 not be con
 not ca
 not do 
 not st
 o |
 of		
 of Astronomy
 of Astronomy 
 of Computing
 of MS
 of Mo
 of Mot
 of Motif
 of Win
 of Window
 of Windows
 of Windows 
 of X
 of X 
 of X11
 of Xt
 of application
 of applications
 of cod
 of code
 of our 
 of text
 of the Wi
 of the Win
 of the Window
 of the X
 of the X 
 of the use
 of the user
 of the wi
 of the win
 of the window
 of the window 
 of user
 of using 
 of wi
 of win
 of window
 of x
 of xt
 of xterm
 offen
 offens
 offense
 olwm
 olwm 
 olwm and 
 on SunOS
 on W
 on Wi
 on X
 on X 
 on X1
 on X11
 on a D
 on a Sp
 on a Sparc
 on a d
 on ex
 on expo
 on export
 on export 
 on export.
 on export.lcs.mit.edu
 on export.lcs.mit.edu 
 on x
 on your s
 opens
 opens 
 openwin
 operating system 
 or X
 or use 
 os/2
 other X
 other new
 other wi
 overhead 
 overr
 override
 override 
 page f
 parent
 parent 
 pars
 parse
 patch f
 patche
 patches 
 patches f
 patches for
 patches for 
 periodic
 person u
 pixmap
 pixmap 
 pixmap.
 pixmaps
 pixmaps 
 pointer 
 pops
 popup
 popup 
 postscript file
 preprocess
 presse
 printer d
 printer driver
 printer driver 
 program b
 program e
 program g
 program ma
 program manager
 program?
 properties
 provided t
 provided th
 pub/pc/win3
 pub/pc/win3/
 pw
 rais
 raise
 raise 
 real w
 real wor
 realized
 reason th
 recompil
 recompile
 redirect
 redraw
 redraw 
 redraws
 reflect a
 register the
 remotely
 resiz
 resize
 resour
 resource
 resource 
 resource f
 resource i
 resources
 resources 
 resources a
 resources i
 resources in
 resources,
 resources.
 respondi
 responding
 right, but 
 rlogin
 rlogin 
 roman
 root window
 root window 
 run X
 run c
 run under 
 running M
 running Sun
 running X
 running x
 running. 
 running.  
 screen to
 screen to 
 scrollba
 secur
 securi
 security
 select a
 server 
 server (
 server and 
 server c
 server f
 server fo
 server for 
 server ha
 server i
 server in
 server ma
 server o
 server re
 server t
 server th
 server to 
 server w
 server wi
 server will 
 server.
 server. 
 server.  
 server.  I
 session 
 sessions
 set up t
 set w
 shared
 shared 
 shared lib
 shared librar
 shared libraries
 shared m
 shared mem
 shared memory
 shared memory 
 shel
 shell
 shell 
 shell i
 shell.
 should not be 
 should not be c
 should not be co
 should not be consider
 show the 
 simple w
 smartdrv
 so I a
 some reason
 someone has 
 source a
 specific c
 specific co
 specifies
 specifies 
 specify a
 spreadshe
 ss
 start the 
 start up 
 start up a
 status
 strings
 structure a
 subsequent
 subsequent 
 support@
 supporter
 supporters
 supporters.
 swap f
 swap file
 swap file 
 symbol
 symbol 
 symbol  
 symbol   
 syntax
 syntax 
 system.ini
 terminal emulator
 terminals
 terminals 
 text editor
 text i
 text s
 than P
 that MS
 that W
 that Win
 that Windo
 that X
 that contains
 that display
 that is     
 that is           
 that is            
 that the se
 that the w
 that the wi
 that the window
 that x
 the "s
 the -
 the An
 the Athena
 the Athena 
 the C 
 the DE
 the HP
 the HP 
 the Imake
 the MI
 the MIT
 the MIT 
 the MS
 the MS 
 the Microsoft
 the Microsoft 
 the Motif
 the Motif 
 the Not
 the Ope
 the Open
 the R5
 the R5 
 the Sun
 the Sun 
 the Wi
 the Win
 the Wind
 the Window
 the X
 the X 
 the X Window
 the X Window 
 the X Window System
 the X c
 the X p
 the X pr
 the X s
 the X se
 the X server
 the X server 
 the X-
 the X11
 the X11 
 the X11R
 the XV
 the Xlib
 the Xlib 
 the Xm
 the Xs
 the Xt
 the Xt 
 the appl
 the applic
 the application
 the application 
 the button
 the cal
 the call
 the client
 the colormap
 the command
 the command 
 the contrib
 the curs
 the cursor
 the cursor 
 the dial
 the dialog
 the exa
 the example
 the exi
 the expo
 the fact that th
 the following e
 the font
 the font 
 the frame
 the functionality 
 the header
 the icon
 the icon 
 the input 
 the job 
 the keys
 the lines 
 the man page
 the mouse 
 the name of th
 the name of the 
 the new i
 the parent
 the patch
 the read
 the release
 the requ
 the resource
 the resource 
 the resources
 the root
 the root 
 the root window
 the same ma
 the server i
 the server is
 the server t
 the server w
 the server.
 the server. 
 the server.  
 the shar
 the share
 the shell
 the shell 
 the stri
 the string
 the text 
 the title
 the title 
 the user 
 the user t
 the val
 the value
 the wi
 the widget
 the win
 the window
 the window 
 the window a
 the window i
 the window is
 the window is 
 the window manager
 the window manager 
 the window o
 the window t
 the windows
 the windows 
 the x
 the xt
 the xterm
 theX
 theapp
 theapplication
 these e
 thinks 
 this en
 this mat
 this value
 thom
 thomas
 to M
 to MS
 to Mi
 to Microsoft
 to Microsoft 
 to Mo
 to Motif
 to Wi
 to Win
 to Window
 to Windows
 to Windows 
 to X
 to X 
 to a h
 to a w
 to allocat
 to allocate
 to allocate 
 to come up 
 to comp.windows.
 to comp.windows.x
 to compile
 to compile 
 to develop 
 to make sure that 
 to play 
 to prev
 to start a
 to stop 
 to the X
 to the X 
 to the se
 to the serv
 to the server
 to the w
 to use X
 to wi
 to win
 to window
 toX
 toolkits
 toolkits 
 tree
 tree 
 tt
 tty
 tv
 tvt
 tvtwm
 tvtwm 
 twm
 twm 
 two questions
 typically
 typically 
 ugly 
 und 
 undef
 undefined
 undefined 
 under M
 under MS
 under Windows 
 under Windows 3.
 under Windows 3.1
 under Windows.
 under X11R
 underl
 underlying
 unnecessar
 unnecessarily 
 up an 
 updating 
 use M
 use X
 use and 
 use the fo
 use the mouse
 use x
 user f
 user m
 user, 
 user.
 uses X
 using Win
 using Windows
 using X
 using w
 utility.
 value of
 value of 
 value t
 variables 
 version of W
 version of X
 views,
 visual.
 visual. 
 void 
 wallpaper
 want to run
 way to do th
 way to do this
 way to f
 whale
 what is i
 what is it
 what is it?
 widget
 widget 
 widget a
 widget i
 widget is
 widget is 
 widget s
 widget t
 widget w
 widget, 
 widget.
 widget. 
 widget.  
 widgets
 widgets 
 widgets a
 widgets i
 widgets o
 widgets, 
 widgets.
 will mo
 win
 win 
 win a
 win an
 win.
 win.ini
 wind
 windo
 window
 window 
 window (
 window a
 window an
 window and 
 window at
 window b
 window h
 window i
 window id
 window in
 window is
 window is 
 window m
 window ma
 window man
 window manage
 window manager
 window manager 
 window manager t
 window manager to 
 window manager, 
 window manager.
 window manager. 
 window manager.  
 window managers
 window managers 
 window o
 window of 
 window on
 window s
 window t
 window th
 window that
 window that 
 window to
 window to 
 window w
 window wh
 window wi
 window with
 window with 
 window,
 window, 
 window.
 window. 
 window.  
 window?
 windowi
 windowing 
 windows
 windows 
 windows (
 windows a
 windows an
 windows and
 windows and 
 windows app
 windows di
 windows i
 windows in
 windows in 
 windows o
 windows on
 windows on 
 windows on a 
 windows p
 windows pr
 windows pro
 windows t
 windows v
 windows w
 windows,
 windows, 
 windows?
 windowsI
 with Mo
 with Motif
 with Su
 with Sun
 with W
 with Win
 with Windows
 with Windows 
 with X
 with X 
 with X11
 with X11R
 with X11R5
 with XPutImage
 with ch
 with cha
 with gcc
 with li
 with the w
 with wi
 with win
 with windo
 with window
 with windows
 with x
 without ha
 workaround 
 writes:<
 wrong..
 xa
 xan
 xannounce
 xb
 xc
 xd
 xdm
 xdm 
 xi
 xin
 xinit
 xm
 xmo
 xmod
 xp
 xpert
 xpert@expo
 xpert@expo.lcs.mit.
 xpert@expo.lcs.mit.edu
 xr
 xs
 xse
 xset
 xst
 xt
 xte
 xterm
 xterm 
 xterm a
 xterm w
 xterm wi
 xterm,
 xterm, 
 xterm.
 xw
 xwd
 xwd 
 xwi
 xwin
 you are running
 your   
 your .
 your X
 your ap
 your app
 your application
 your mou
 your program
 your ser
 your u
 your wi
 your win
 your window
 your window 
 {	
 {       
 {        
 | E-mail
 | E-mail: 
 | Fax: 
 | Te
 | Tel
 | Tel: 
 | s
 | th
 ||  M
 ~/
!#
!$
!%
!&
!,
!/
!0
!04
!1
!2
!3
!34
!34U
!3[
!4
!5
!6
!7
!8
!86
!9
!;
!<
!= 
!? 
!@
!A(
!D9
!D9&
!D9&1
!E
!MA
!P<
!Q
!U
!V
!X
!Y
!Z
![
!\
!^
!`
!`0
!de
!f
!lo
!se
!z
" )
" =
" Data in Windows 3.1?
" O
"!
""
"" 
"#
"$
"%
"&
"'
"(
");
"*
"+
"0
"0D
"0M
"4
"5
"6
"7
"8
"9
":
";
"<
"=
"@
"C"
"LK
"Licensed 
"Licensed To"
"Mo
"P&
"P4
"P4U
"PL
"PL+
"PL+"
"PL+"P
"PL+"PL
"PL+"PL+
"PL+"PL+"PL
"PL+"PM
"PL+"V
"PM
"PMF
"PMF9
"PMF9F
"PNE1
"Q
"V;
"V;$
"V;$,
"X
"X 
"Z
"Z6
"\
"\0
"]
"^
"_
"`
"fo
"set
"x
"z
# I
# T
#!
#!/
#"
##
#$
#$Q
#$Q,
#$Q,3
#%
#&
#'
#(
#)
#*
#+
#,
#-
#.
#/
#0T
#0T-#
#0T-#0T-
#0T-#0T-#
#0T-#0T-#0
#0T-#0T-#0T
#2+
#3%
#4
#4U
#7
#7K
#8
#;
#<
#=
#?
#@
#A
#B
#C
#D
#E
#F
#F3
#F3W2
#F9
#F9D
#F9F9
#F9F9F
#G
#H
#I
#J
#K
#L
#M
#M7
#M;
#N
#O
#P
#P\
#P\/
#P\/#
#P\/#P
#P\/#P\
#P\/3
#P\/3$
#P]
#P],
#P]G
#P]G9
#Q
#R
#S
#T
#TQ
#TQ,
#TQ,3
#TQ,3$
#TQ,3$Q,
#TQ,3$Q,3
#U
#V
#V=
#V=G
#V=G9
#V?
#W
#X
#Y
#Z
#[
#\
#]
#_
#`
#`P
#`P,#
#`P,#`
#`P,#`P
#`P,#`P,
#`P,#`P,#
#`P-z
#`P.
#`U
#`Y
#`YF9
#define
#define 
#e
#endif
#if
#ifdef
#ifdef 
#include <X
#include <X11/
#include <X11/X
#o
#over
#z
$!
$!A
$!`
$"
$#
$%
$&
$'
$(
$*
$+
$,
$,3
$,3$Q,
$,8
$,8z'AX
$,8z'AXz'AX
$,8z'AXz'AXz'
$,8z'AXz'AXz'AX
$,8z'AXz'AXz'AXz'
$,8z'AXz'AXz'AXz'AXz'
$,8z'AXz'AXz'AXz'AXz'A
$-
$/
$1$
$9&
$9@
$9F
$9L
$:
$;
$<
$=
$?
$@
$A
$A(
$B
$C
$D
$DI
$E
$F
$G
$H
$HO
$HOME
$HOME/
$I
$J
$K
$L
$M
$M,
$M9
$MQ
$N
$O
$P
$P/
$Q
$Q#
$Q#$Q,
$Q&
$Q,
$Q,0Q,
$Q,3
$Q,3$
$Q,3$Q
$Q,3$Q,
$Q,3$Q,3$Q,3$
$Q,3$Q,3$Q,3$Q
$Q,3$Q,3$Q,3$Q,
$Q,3$Q,3$Q,3$Q,3
$Q,3$Q,3$Q,3$Q,3$
$Q,3&'
$Q,3&'AXz'A
$Q,3&'AXz'AX
$Q,3&'AXz'AXz'
$Q,3&'AXz'AXz'AXz'
$Q,3&'AXz'AXz'AXz'A
$Q,3&'AXz'AXz'AXz'AX
$Q,3&'AXz'AXz'AXz'AXz'
$Q,3&'AXz'AXz'AXz'AXz'AXz'
$Q,3&'AXz'AXz'AXz'AXz'AXz'AXz'
$Q,8z'
$Q,8z'A
$QA
$QM
$QQ
$R
$R)
$S
$T
$U
$V
$W
$X
$Y
$Z
$[
$\
$\M
$]
$^
$_
$`
$z
${
%!
%!0
%"
%#
%$
%%
%%1
%%@
%%M
%&
%(
%)
%*
%+
%-
%-#
%-#2
%-(
%-3
%/
%/M
%0
%1
%14
%2
%3
%4
%5
%6
%7
%8
%9
%9P
%9V
%9V=
%9V=G
%:
%;
%<
%=
%=7
%@
%A
%A8
%A86
%A86%
%A86%A
%A9
%A94
%B
%C
%D
%E
%F
%G
%H
%I
%I:
%J
%K
%L
%M
%M-
%M;
%MQ
%N
%O
%P
%Q
%Q&
%Q&1F
%Q3
%Q6
%Q<
%Q<5
%Q<5G
%Q<5G9
%Q<7'
%QM
%QT
%R
%S
%T
%U
%V
%W
%X
%Y
%Z
%\
%]
%^
%_
%a
%craft@uunet.uu.net
%z
&!
&"
&#
&$
&%
&%A
&&
&& 
&'
&'A
&'AX
&'AXz'
&'AXz'A
&'AXz'AX
&'AXz'AXz'
&'AXz'AXz'AX
&'AXz'AXz'AXz
&'AXz'AXz'AXz'
&'AXz'AXz'AXz'A
&'AXz'AXz'AXz'AX
&'AXz'AXz'AXz'AXz'AXz'AXz
&'AXz'AXz'AXz'AXz'AXz'AXz'AX
&'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
&'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
&'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
&'M
&(
&)
&*
&+
&,
&-
&.
&/
&0
&1
&1D
&1D9
&1D9&
&1D9&1
&1D9&1D
&1D9&1D9
&1D9&1D9&
&1D9&1D9&1
&1D9&7
&1E
&1EQ
&1EQ<
&1EQ<=
&1F
&2
&3
&4
&5
&6
&7
&7%
&7%Q<
&7%QT
&7'
&7'2
&7'2T
&8
&9
&9F
&:
&;
&;!
&;"
&<
&=
&?
&@
&A
&AH
&B
&C
&E
&F
&G
&H
&I
&J
&K
&L
&M
&N
&O
&P
&Q
&Q[
&R
&S
&U
&V
&X
&Y
&Z
&[
&\
&]
&^
&_
&a
&z
' B
' wo
'!
'"
'#
'$
'$9
'$Q
'&
'(
') 
'*
'+
',3
',<
'/
'1
'1T
'1T='I
'1T='I:
'1T?
'1Z
'1]
'1]]
'2
'2/
'2M
'2T
'3
'4
'5
'5U
'6
'7
':
': 
';
'<
'=
'?
'@
'A
'AS
'AU
'AX
'AX<
'AXz
'AXz'
'AXz'A
'AXz'AX
'AXz'AXz
'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AS
'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'M
'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MA
'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAX
'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'
'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'A
'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AX
'AXz'AXz'M
'AXz'AXz'MA
'AXz'AXz'MAX
'AXz'AXz'MAXz
'AXz'AXz'MAXz'
'AXz'AXz'MAXz'A
'AXz'AXz'MAXz'AX
'AXz'AXz'MAXz'AXz
'AXz'AXz'MAXz'AXz'
'AXz'AXz'MAXz'AXz'A
'AXz'AXz'MAXz'AXz'AX
'AXz'AXz'MAXz'AXz'AXz
'AXz'AXz'MAXz'AXz'AXz'
'AXz'AXz'MAXz'AXz'AXz'A
'AXz'AXz'MAXz'AXz'AXz'AX
'AXz'AXz'MAXz'AXz'AXz'AXz
'AXz'AXz'MAXz'AXz'AXz'AXz'
'AXz'AXz'MAXz'AXz'AXz'AXz'A
'AXz'AXz'MAXz'AXz'AXz'AXz'AX
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'A
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AX
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'A
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AX
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'A
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
'B
'F
'I
'I0
'I0L+
'I:
'I:6
'K
'L
'M
'M1
'M1T
'MA
'MI
'MQ
'N
'P
'Q
'Q[
'Q\
'U
'V
'W
'WW
'W]
'X
'X 
'Z
'[
'\
']
'^
'_
'`
's X
's very 
've been u
've been using 
'z
("
("T
("`
("`@
("`@(
(#
(%
(&
('
((
()
() 
() a
() an
() and
() and 
() f
() function
(),
(), 
().
();
(); 
();  
()?
(+4
(,
(-
(..
(...
(02
(11
(:
(;
(<
(@
(B(
(DE
(F)
(F)B
(M;
(MS
(N+
(NU
(OM
(ST
(Some
(Some 
(X
(X1
(X11
(X11R
(Xt
([
(\
(]
(]/
(^
(`
(app
(arg
(dis
(disp
(display
(dp
(dpy
(dpy,
(gd
(top
(z'
(z'A
(z'AX
(z'AXz
(z'AXz'
)				
) 	
) !
) &
) *
) .
) 36
) 89
) X
) Y
) \
) and H
) ch
) fu
) function
) writes:Try 
) {
) { 
)! 
)"0
)#
)$
)%
)&
)'
));
),      
),       
),        
),          
),           
)-4
)/(
)0
)24
)25
)27
)3$
)3$Q
)3$Q,
)3$Q,3
)3$Q,3$
)37
)42
)45
);
);	
);  
);   
);T
);Th
);X
);}
)<
)@
)AJ
)B4
)B8
)B8F
)B8F)B8E,3$
)B<
)MB
)MR
)Q
)Q<
)R8
)R<
)R<F
)R<G)R<G)
)R<G)R<G)R
)Sender: news@
)Sender: news@athena.mit.eduMessage-ID: <
)V
)X
)X 
)XX
)Z
)[
)\
)]
)^
)m
)z
* 3
* 4
* Err
* H
* X
* co
* d
* v
*!
*"
*"@
*#
*$
*%
*&
*'
*(
*** E
*** Error code 
*** Error code 1
**B
*+
*-
*/
*/	
*/ 
*/#
*0
*2D
*3
*5
*6
*7
*8
*9
*:
*;
*<
*?
*@
*B
*BH
*BHJ*B
*BHJ*BH
*BHJ*BHJ
*BHJ*BHJ*
*BHJ*BHJ*B
*BHJ*BHJ*BHJ
*BHJ*BIZ
*BHJ*BIZz
*BHJ*G
*BHJ*GIZ
*BHJz
*BI
*BIZzGI
*BIZzGIZ
*E
*F
*G
*GI
*GIZ
*GIZz
*GK
*H
*J
*K
*KM
*KN
*M0
*M2
*Q
*RL
*RM
*V
*X
*Y
*Z
*[
*\
*\\
*]
*^
*_
*x
*z
+ 3
+ o
+ w
+ wi
+!
+!3
+"
+"P
+"PL+"
+"PL+"P
+"PL+"PL
+"PL+"PL+
+"PL+"PL+"
+"PL+"PL+"P
+"V
+"V9F9
+"V9FQ
+"V9FQ,
+"Z
+#
+$
+%
+&
+'
+(
+*
++/
+-#
+-,
+----------------------------+
+.
+/
+2
+2/
+2M
+2T
+2TG
+2TM
+2TM+
+2TM+2
+2TM+2T
+2TM+2TM
+31 
+32
+49 2
+49 23
+5
+7
+8
+9
+9F
+9F9F9
+9F;
+9F;$
+9F;$Q
+9L
+:
+;
+<
+?
+A
+B
+BS
+BX
+BXN
+BXO
+B^
+B^W
+B^WM
+B^WM[
+D
+E
+G
+H
+I
+I4
+I:
+J
+K
+L
+M
+M"
+M-
+M9
+MB
+N
+O
+P
+P3
+Q
+R
+T
+U
+V
+W
+X
+Y
+Z
+[
+[5
+[z
+[zU3
+\
+]
+^
+_
+`
+z
,			 
,			  
, 0)
, 0);
, 0,
, 0, 
, 0, 0
, DOS 
, I get t
, Lin
, Linux
, Microsoft 
, Moti
, NU
, NULL
, Op
, Ope
, Open
, RI
, Win 
, Win 3.1
, X
, X1
, X11
, X11R
, X11R5
, X11R5 
, Xt
, and I've 
, arg
, argv
, but I'd
, but I've 
, but I've n
, but in
, except th
, gc
, inf
, info
, the X
, the fo
, the following
, win
, window
, x
,!
,#
,#7
,#F
,#F9
,#M
,#P
,#V
,#`
,#`P,#
,$
,%
,&
,'
,)
,*
,+
,/
,0Q
,1F
,3$
,3$Q
,3$Q,3
,3$Q,3$
,3$Q,3$Q
,3$Q,3$Q,
,3$Q,3$Q,3
,3$Q,3$Q,3$
,3$Q,3$Q,3$Q,3$Q,
,3$Q,3&
,3$Q,8
,3$QA
,3$QAX
,3$QAXz'
,3$QAXz'AX
,3$QAXz'AXz'
,3$QAXz'AXz'A
,3$QAXz'AXz'AX
,3$QAXz'AXz'AXz'
,3$QAXz'AXz'AXz'A
,3$QAXz'AXz'AXz'AX
,3$QAXz'AXz'AXz'AXz'
,3&
,3&'A
,3&'AXz'AXz'AXz
,3&'AXz'AXz'AXz'AXz'AXz'AXz'A
,3&'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
,3&'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
,3&'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
,3'
,34
,3`
,5G
,7%
,7%9
,8
,8z'A
,8z'AXz'A
,8z'AXz'AXz'A
,8z'AXz'AXz'AXz'A
,8z'AXz'AXz'AXz'AX
,9
,;
,<
,<1
,=
,?
,@
,B8
,C(
,C)
,M3
,M3$Q,3
,M3$Q,3$
,Mic
,PW
,Q
,X
,Xt
,[
,\
,]
,^
,_
,it's 
- La
-!
-"
-#
-#0
-#0T
-#0T-#0T
-#0T-#0T-#
-#2
-#2+
-#2+B
-%
-&
-(N
-(N+
-,5
-,7
-- so
--------------------------------------------------------------------------/
--------------------------------------------------------------------------\
------------------------------------------------------------------------\
---------------------------------------------------------------------/
----------------------------------------------/
---------------------------------------------\
------------------------------/
----------------------\
------------/
--\ 
--e
-34U
-34U-
-34U-3
-34U-34
-34U-34U
-34U/
-3L
-3[
-3[z
-466
-572
-572-
-:
-;
-@
-C8
-Posting-Host: e
-Posting-Host: en
-S<
-S<W
-SH
-U%
-UX
-W4
-WI
-WIN
-WINDOW
-Windows a
-Z
-[
-]
-^
-_
-`
-berlin.de (
-def
-default
-display
-dor
-file
-fu
-he
-head
-lXa
-lXaw
-mail   
-manage
-manager
-n 
-news
-news.
-o 
-ret
-roo
-root 
-server 
-str
-struct
-term
-termina
-terminal
-wind
-window
-windows
-windows a
-windows.
-z7
-z7K
-zM
-zN
-|| 
.	Not
.  :-
.  :-)
.  For a 
.  From 
.  How do
.  I'm a
.  You have
.  You have 
. Internet
. Lewis
. Mc
. Ric
. Rich
. Richard
. Richardson
. The w
."(
.",
.##
.#@
.%
.&
.);
.. In
... In
... Internet
...!u
...!uunet
...!uunet!
.../
...Co
../
./.
.0"
.00 h
.1	
.1 i
.1 in
.1 is
.1 is 
.1 p
.1 s
.1.1 
.1.1.
.1.2 
.1.3
.1.3 
.170
.180
.1I
.2 a
.2,
.2, 
.3 a
.3D
.737
.7M
.9/
.9/3
.930
.9304
.93042
.9F
.@
.AA
.AA0
.AA1
.AA2
.Brian 
.CH
.Edu (M
.Edu (Ma
.GO
.I use
.INI
.INI 
.In article <C
.In the 
.K. 
.K.  
.Mc
.OK
.P&
.PL
.PM
.Pat
.Patrick 
.Patrick L. M
.Patrick L. MahanWaking a person unnecessarily should not be considered  - Lazarus Longa capital crime.  For a first offense, that is            From the Notebooks of							  Lazarus Long
.RL
.Tom
.Tom 
.X1
.Xdefault
.Xdefaults
.Xdefaults 
.Z   
.\
.\ 
.] 
.^
.ac.b
.ac.be
.ac.uk |
.ari
.arizona.edu
.arizona.edu 
.ast
.bm
.bmp
.bmp 
.cam.
.cam.ac.uk
.cam.ac.uk 
.clark
.clarku.edu
.clarku.edu 
.cle
.cmu.eduzReferences: <
.co.uk)
.color
.colorado.edu
.com                                   
.com                                       
.com  or 
.com -
.comzNNTP-Posting-Host: e
.deIn article <
.def
.dez, 
.dezReferences: <19
.dis
.edu (Se
.edu a
.edu!
.edu!l
.edu:/
.eduDe
.eduM
.eduMessage-ID: <
.eduMessage-ID: <930
.eduMessage-ID: <9304
.eduMessage-ID: <93041
.eduMessage-ID: <93042
.eduMessage-ID: <9305
.eduMessage-ID: <93051
.eduTo
.eduTo: 
.eduz k
.eduzNNTP-Posting-Host: en
.eduzNNTP-Posting-Host: enterpoop.mit.edu
.eduzNNTP-Posting-Host: enterpoop.mit.eduTo: 
.eduzNNTP-Posting-Host: enterpoop.mit.eduTo: x
.eu
.ext
.grp
.grp 
.grp file
.grp file 
.gw
.h 
.hz#
.hz#include 
.hz#include <
.informatik.uni-dortmund.de
.ini
.ini 
.ini and
.ini and 
.ini file
.ke
.lc
.lcs.mi
.lcs.mit.
.lcs.mit.edu
.lcs.mit.edu 
.lcs.mit.edu (
.lcs.mit.eduH
.lcs.mit.eduHi
.lcs.mit.eduz
.lcs.mit.eduzNNTP-Posting-Host: 
.lcs.mit.eduzNNTP-Posting-Host: enterpoop.mit.edu
.log
.login
.mcrcim.mcgill.
.mcrcim.mcgill.edu
.mit.edu in
.mit.edu in 
.mit.edu)
.mit.edu:
.mit.edu:/
.mit.eduT
.o 
.od
.oi
.op
.open
.sh
.shar
.uc.edu
.uc.eduz
.uc.eduz 
.uk |
.unc.eduz
.uni-d
.uni-dortmund.de
.upenn.eduz
.win
.window
.windows
.x a
.xinit
/		
/  \ 
/  \  
/ 3
/ D
/ G
/ a
/ d
/!
/#
/#P
/#P\
/#P\/
/#P\/#
/#P\/#P
/#P\/#P\
/#P\/#P\/
/#T
/#TQ,
/$
/%
/&
/'
/(
/(_
/)
/*
/* 
/* d
/* s
/**
/+
/,
/--------------------
/-----------------------
/---------------------------------------------
/----------------------------------------------
/------------------------------------------------------------------------
/--------------------------------------------------------------------------
/.
/./
///      
///       
/11
/14
/28
/3$
/3$Q,
/3$Q,3
/3T
/3T]
/3T]/3T
/3T]/3T]
/3V
/3V9F9F9
/3V9F9F9F
/3W
/3W2T
/9D
/9D#
/9D#7
/9F
/9F9
/9F9F
/9V
/9V=G
/9\
/:
/;
/<
/=
/=)
/=)Q
/=+
/=+2
/=+2<
/@
/CX
/CZ
/IN
/K
/M#
/M[
/Net
/Q
/R5
/S\
/X
/X 
/X,
/X1
/X11
/X11/
/X11/x
/X11R
/X11R5
/Xa
/Xm
/Xs
/Xt
/Y
/Z
/\       
/\        
/^
/bi
/bin
/bin/
/bin/s
/bin/sh
/contrib
/contrib/
/dev/
/fonts
/inc
/includ
/include
/include/
/l
/li
/lib
/lib 
/lib/
/lib/X
/lib/X11
/lib/X11/
/lib/l
/libX
/local
/op
/open
/pc/
/pub/X
/pub/p
/pub/pc/
/sun
/to
/u
/up
/us
/usr
/usr/
/usr/X
/usr/l
/usr/lib
/usr/lib/
/usr/lib/X11
/usr/lib/X11/
/win3
/win3/
/x
/xd
/xdm
/z
/|  *
0 Do
0#
0$!
0&
0(
0)4
0);
0+I
0, 0
0,#
0-z
0.AA
0.tar.Z 
0/3
00 D
00 ha
00 has
00 has 
00..
00...
0002
01                
04%
0419
0421
0426
04@
04M
0;
0<
0@v
0D)
0D*
0G
0HA
0J
0L
0L+
0L+"
0L+"P
0L+"PL
0MM
0O$
0Q
0Q,
0Q,3
0Q,3$Q
0Q,3$Q,
0Q,3$Q,3
0QA
0QAXz'
0QAXz'A
0QAXz'AX
0QAXz'AXz'
0QAXz'AXz'AX
0QAXz'AXz'AXz'
0QAXz'AXz'AXz'AX
0QAXz'AXz'AXz'AXz'
0T-
0T-#
0T-#0
0T-#0T
0T-#0T-
0T-#0T-#
0T-#0T-#0
0T-#0T-#0T
0T-#0T-#0T-
0T-#2
0T-(
0TB
0TBX
0TM
0TQ
0Y
0Z
0[
0\
0^
1 7
1 75
1 R
1 W
1 Wi
1 font
1 se
1 |
1!
1#
1%
1&
1) i
1);
1*
1, M
1-50
1.1, 
1.15
1.154
1.2.
1.2.1
1.AA
1.B
1/'
1/x
11 -
11 s
11 se
11/
1141 
11R
11R5
11R5 
11R5 d
141 
145%
145%1
145%14
14M
188
1993Ma
1;
1<
1=
1?
1D9
1D9&
1D9&1
1D9&1D
1EQ
1F"
1F9
1FP
1FPL
1In
1In 
1In article 
1In article <
1J
1JZ
1K
1M4
1M8
1O
1Q
1R
1R3
1R4
1R4 
1R5
1R5.
1S
1T
1T=
1T='
1T='1
1T='1T
1T='1T='
1T='1T='1
1T='1T='1T
1T='1T='1T='
1T?
1T??
1T??W
1T??W]
1T??W]_?
1Tz
1U
1V
1W
1Y
1Z
1Z4
1Z6
1Z6E
1[
1\
1]]
1]]Z
1]]Z*
1^
1_
1z
2 on a
2!
2#
2&
2'
2'A
2'AXz'
2(
2);
2+
2+B
2+[
2-82
2.2 
2.3.3
223) 
23    
23      
23       
23        
23         
23            
23             
23) 
24@
24E
24G
28:
292
2<
2<1
2=
2D/
2DI
2J
2M<
2MD
2MT
2O
2Q
2R
2T
2TC
2TCT
2TCT]
2TCV9
2TG
2TG%Q
2TM
2TM(
2TM(]
2TM(]/
2U
2U=
2VY
2X
2Z
2[
2\
2^
2`
2z
3 co
3!
3#
3$,
3$,3
3$,3$Q
3$9
3$M
3$MQ
3$P
3$Q#
3$Q#$Q
3$Q,1F
3$Q,3
3$Q,3$
3$Q,3$Q,3$Q
3$Q,3$Q,3$Q,
3$Q,3$Q,3$Q,3
3$Q,3$Q,3$Q,3$Q,3
3$Q,3$Q,3$Q,3$Q,3$
3$Q,M
3$Q,M3
3$R
3$R)
3$R)B
3%
3%Q
3%Q6
3%Q6=
3%Q6=G
3&
3'
3'$
3) 3
3.00 
3.1 
3.1 a
3.1 and 
3.1 i
3.1 s
3.1 w
3.1?
3.1I
3/1
301-5
3051
30T
31 7
31)
32+
33) 
34M
34U
34U-
34U-3
34U-34
34U-34U
34U/
34[
34["
34["P
34^
34^V
34^W
386 e
386 en
386 enh
399
3<
3=
3?
3B
3B1
3DY
3H
3K
3L!
3L+
3L+"P
3M4
3MM
3M[
3May
3O
3Q
3T]
3T]/
3T]/3
3T]/3T
3T]/3T]
3T]T
3T]TM
3T]TM+2
3U
3V9
3W2
3X
3Y
3Z
3[
3[8
3[z
3[zV+
3[zW
3`
3`\
3`\/
3`\/#
3z
4 3
4 9
4!
4#
4%
4%!
4&
4(
4)"
4)-
4+
4+"
4+"P
4+9
4.1 
4.1.
4.1.1
4.1.2
4.1.3
4.A
4.AA
4/0
421
4211
4221
4261
45!
45%
45%1
45%14
45%145
45%145%
45)
46#
4600 Dortmund 
466
4;
4<
4=
4='
4='1
4?
4??
4C
4E)
4G
4H
4J
4L
4M+
4M5
4MU
4P
4Q
4Q,
4T-
4T-#
4TM
4U
4U-
4U-3
4U-34
4U-34U
4U-34U-
4U-34U-3
4U-34U-34
4U-34U-34U
4U-3L
4U.
4U/
4W
4Y
4Z
4[
4["
4["P
4["PL
4[`9
4\
4^
4^V
4^V+
4_
5 0
5 X
5 on
5 on 
5 se
5 server
5!
5%0
5%1
5%145
5%145%
5%145%1
5%@
5&
5'
5'1
5'1T
5'1T='
5'1]
5'W
5(
5-34
5.P
5/M
501
501 
52)
55   
572-
57@
588
598
5<
5=
5@net
5C
5DI
5E
5G#
5G9
5G9V
5I:
5M;
5MM
5Q
5R
5U
5U=
5U=7
5U=75
5W
5X
5Y
5Z
5\
5_
5z
6 0
6 5
6 en
6!
6#
6#,
6%
6%A
6%A8
6%A86
6%A86%
6%E
6&
6.A
6.AA
63D
692
6;
6<
6=G
6AP
6B1
6E
6E"
6E1
6EI
6EI0
6EI:
6EI:6EI:
6EI:6EI:6
6EI:6EI:6E
6EM
6G
6L
6M%
6O
6P
6Q
6QL
6R
6T
6UM
6W
6X
6Z
6[
6\
6^
6_
6z
7!
7#
7$9
7%
7%9
7%9V
7%Q
7%Q&
7%Q&1
7%Q6
7%Q<
7%Q<4
7%Q<7
7%Q<7%
7%Q<7%Q
7%Q<7%Q<
7%Q<7%Q<7
7%Q<7%Q<7%
7%Q<7%Q<7%Q
7%Q<=
7%Q<=+2
7&
7'2
7'2T
7'2TC
7(
7*
7+
71Y
7359
7523
75M
75U
75U=
75U=7
75Z
783
7<
7=
7@,
7@,#F
7@.
7@.9
7@m
7EX
7EX#`P
7EY
7EYz
7EYz7
7EYz7E
7EYz7EY
7EYz7EYz
7EYzN
7EZ
7EZ[
7G
7K
7KL
7KLJ
7KLJz
7KM
7KN[*
7KN[N
7N
7O
7P
7Q
7R
7S
7T
7U
7U%
7U]
7W
7Y
7Z
7[
7\
7_
8 0
8!
8" 
8#
8%
8&
8&#
8'
8+
8+"
8+M
8,P
8/9
8267
83-
86 e
86$
86%
86%A
86%A8
86%A86
865
86B
86R
886
8<
8A
8D
8E
8E,
8F
8F)
8F)B
8F)B8E,
8F)B8E,3
8F)B8E,3$
8F)B8F
8F)B8F)
8F)B8F)B
8G
8G)
8H
8J
8N+
8N+B
8O
8OM
8P
8Q
8T
8V
8VM
8W
8X
8Y
8Z
8\
8z
8z'
8z'AXz
8z'AXz'AXz'AXz'AXz'AXz'
8z'AXz'AXz'AXz'AXz'AXz'A
8z'AXz'AXz'AXz'AXz'AXz'AX
8z'AXz'AXz'AXz'AXz'AXz'AXz'
8z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
8z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
8z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
8z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
8z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
8z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
8z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
8z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
8z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
8z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
8z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
8z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
8z'M
8z'MA
9 3
9!
9#
9%
9&
9&1
9&1D
9&1D9
9&1D9&
9&1D9&7
9&1E
9&1EQ
9&1EQ<
9&7
9&7%Q
9&;
9(
9*
9+
9-8
9.A
9.AA
9/
9/3
9/3W2
9/9
92]
9304
930419
9304191
93042
930421
9304211
930426
9305
93051
93May
93May1
93May12
93May14
941
9;
9<
9<7
9<=
9=
9?
9@L
9@M
9@N
9@NE
9D
9D#7
9D#`
9D]
9E
9F
9F"
9F0
9F0-z
9F3
9F3T]
9F8
9F9
9F9D
9F9D]
9F9D]/
9F9F
9F9F0
9F9F9
9F9F9F
9F9F9F9
9F9F9F9F
9F9F9F9F9
9F9F9F9F9F
9F9F9F9F9F9
9F9F9F9F9F9F
9F9F;$
9F9F;$Q
9F9F;$Q,
9F9FQ
9F9`
9FM
9FQ
9G
9J
9L
9L%
9L+
9L0
9L3
9L3$
9L3$Q
9M
9M&
9MF
9ML
9N
9O
9P\
9P]
9Q
9R
9S
9T
9U
9V
9V<
9V=
9V=G
9V=G#
9V=G#P
9V=G9
9V=G9V
9V=G9V<
9V=G9V=
9V=G9V=G
9V=G9V=G9
9V=G9V=G9V=
9V=G9V=G9V=G
9V=G9V=G9V=G9
9V=G9V=G9V=G9V
9W
9X
9Y
9Z
9[
9\
9\4
9\4T
9\7
9\7%
9\7%Q
9^
9_
9`
9`U
9z
:	B
:   (5
:  i
: #
: (0
: +3
: +49
: +49 
: +61 
: <0
: <1s
: <3
: <9
: <93
: <930
: <9304
: <93041
: <930419
: <93042
: <C6
: ?
: ATM
: Animation
: Animation with XPutImage()?
: Bl
: Can I Change "
: Canon 
: Canon BJ200 (BubbleJet) and HP DeskJet 500...
: Ch
: Cha
: Challenge to Microsoft supporters.
: Challenge to Microsoft supporters.I
: Challenge to Microsoft supporters.In 
: Challenge to Microsoft supporters.In a
: Forcing a window manager to accept specific coordinates for a window
: GUI 
: Help with changing Startup logo
: How can 
: How can I 
: How to 
: Key
: Looking for X
: Looking for X 
: Looking for X windows on a PC
: MAC 
: More Cool BMP files??
: Mot
: Motif
: Program
: Program 
: Re: X
: SU
: Tru
: Ut
: Utilit
: Utility 
: WI
: WIN
: Why is
: Why is my mouse so JUMPY? 
: Wi
: Win
: Win 
: Win NT - what is it???
: Window
: Windows
: Windows 
: Windows 3.1
: Windows 3.1 
: Windows NT
: Wo
: Wor
: Work
: X
: X 
: X-
: X11
: X11R
: X11R5
: X11R5 
: XV 3.0
: XV 3.00 has escaped!
: Xt
: col
: comp.windows.
: comp.windows.x
: david
: en
: ex
: exp
: head
: head-
: head-to-head win and
: head-to-head win and os/2
: je
: lou
: re: C
: re: Challenge to Microsoft supporters.
: re: Challenge to Microsoft supporters.I
: roman
: roman.bmp 
: vi
: x
: xa
: xan
: xdm
: xdm 
: xp
: xpert
: xpert@expo
: xpert@expo.lcs.mit.
: xpert@expo.lcs.mit.edu
: xpert@expo.lcs.mit.eduH
: xpert@expo.lcs.mit.eduI
: xpert@expo.lcs.mit.eduI 
: xt
: xterm
: xterm 
:!
:#
:$
:%
:&
:&A
:&B
:'
:/
:/co
:0.
:0.0
:4+
:41
:5'
:6E
:6EI:
:6EI:6
:6EI:6E
:6EI:6EI
:6EI:6EI:
:6EM
:6F
:7
:;
:=:
:?
:FI
:J
:M&
:Q
:RL
:Try 
:V
:VM
:X
:X 
:Z
:\
:\O
:]
:_
:pub/
;	
;		
;	/
;	/*
;	/* 
; X
;!
;"
;"P
;#
;$
;$,
;$,8z'
;$,8z'AXz'
;$A
;$M
;$Q
;$Q#
;$Q,0Q
;$Q,3$
;%
;&
;&Q
;'
;(
;*
;+
;,
;.
;/
;0
;1
;2
;3
;4
;5
;6
;6Q
;6U
;6V
;6W
;7
;8
;9
;:
;;
;<
;=
;?
;@
;A
;B
;C
;D
;E
;F
;FY
;F[
;G
;H
;I
;J
;K
;L
;M
;N
;O
;P
;Q
;R
;S
;T
;Th
;The
;U
;V
;W
;X
;Y
;Z
;[
;\
;]
;^
;_
;`
;c
;z
;{
;}
<   
<    
<!
<"
<#
<$
<%
<&
<'
<(
<)
<*
<+
<,
<.
</
</#
</3
<1D
<1D9
<1D9L
<1F
<3
<3$
<4
<4T
<5
<6
<7$
<7%
<7%9
<7'
<9
<93
<:
<;
<=(
<=+
<?
<@
<B
<C6
<C7
<D6
<E
<F)
<G
<G)
<G)R
<G)R<
<G)R<G
<G)R<G)
<G)R<G)R
<G)R<G)R<
<G)R<G)R<G
<G)R<G)R<G)
<G)R<G)R<G)R
<G)R<G)R<G)R<
<H
<K
<Ke
<Key
<Keyz
<L
<O
<P
<Q
<Q,
<QM
<QQ
<QQ&
<R
<T
<U
<V
<W
<W-
<W-S
<X
<X1
<X11/
<X11/X
<Y
<[
<\
<]
<^
<_
<x
= "
= 3
= N
= S
= X
=!
=#
=$
=%
=&
='
='1T
='1T=
='1T='
='1T='1
='1T='W
='1T='W]
='1T='W]_?
='1]
='1]_?
='M
='M1
='M1T
='W
='W]_?W]
=(]
=)
=)Q
=+
=+2
=+2TM
=,
=.
=/
=0
=0;
=14
=2
=5
=6
=7
=75
=77
=9
=:
=;
=<
=?
=@
=B
=F
=G
=G#
=G#P
=G9
=G9V
=G9V<
=G9V=G
=G9V=G9
=G9V=G9V
=G9V=G9V=
=G9V=G9V=G
=G9V=G9V=G9
=G9V=G9V=G9V
=G9\7%Q
=G:
=GM
=GQ
=H
=HM
=J
=K
=M
=N
=O
=Q
=R
=U
=V
=X
=Y
=Z
=[
=\
=]
=^
=`
=e
?#
?$
?%
?%Q
?%Q<
?&
?'
?'Q
?*
?*\
?/
?0
?1
?1T
?1T=
?1T='
?1T='1
?1TzE
?1TzEI
?1TzEI0
?1Z
?5
?6
?7
?7U
?7U]
?8
?9
?;
?<
?=
??*
??WW
??W]
??W]_
??z
?@
?GY
?Ha
?Has an
?Has any
?M1
?MW
?MW]
?Mz
?Q
?Sender: news@athena.mit.eduMessage-ID: <
?U
?V
?WT
?WT='1
?WT='1T
?WT='I
?WW
?WWI
?W]
?W]]'
?W]_?WT
?W]_?WT='
?W]_?W]
?W]_?W]]
?W]_?W]_
?W]_?W]_?
?W]_?z
?W]_?zG
?Z
?\
?z
?zGIZ
?zGIZz
@!
@"
@#
@$
@$!
@%
@&
@'
@(
@("
@("`
@("`@
@(#
@)
@*
@+
@,
@,#
@,#`
@,#`P
@,#`P,#
@-
@.
@.9
@/
@0
@2
@3
@4
@5
@6
@7
@8
@9
@:
@;
@<
@=
@?
@E
@H
@H*
@J
@K
@L+
@M'
@N
@O
@Q
@S
@S#
@TGV.COM
@TGV.COMz
@W
@Y
@Z
@[
@\
@]
@^
@`
@access.digex.com 
@access.digex.com (
@ae
@andrew.cmu.eduzReferences: <
@at
@athen
@athena
@athena.
@athena.mit.edu
@athena.mit.eduM
@cci
@cleveland.Freenet.Edu (Ma
@ct
@ex
@expo
@expo.lcs.mit.
@expo.lcs.mit.edu
@expo.lcs.mit.edu 
@expo.lcs.mit.eduI
@expo.lcs.mit.eduI 
@expo.lcs.mit.eduz
@expo.lcs.mit.eduzNNTP-Posting-Host: 
@expo.lcs.mit.eduzNNTP-Posting-Host: enterpoop.mit.edu
@expo.lcs.mit.eduzNNTP-Posting-Host: enterpoop.mit.eduTo: 
@her
@hub
@ko
@mail.
@met
@metr
@mh
@microsoft
@microsoft.c
@microsoft.com
@netnews.
@netnews.upenn.eduz
@nl
@ora.com
@pho
@pri
@prism.gatech.
@prism.gatech.edu
@sam
@samba.oit.unc.eduz
@samba.oit.unc.eduz 
@sea
@seas.
@seas.gwu.edu
@sun.
@sunb
@sunbar.mc.duke.edu
@tay
@taylor
@taylor.
@uceng.uc.edu
@uceng.uc.eduz
@uceng.uc.eduz 
@vax.
@vax.c
@vax.clarku.edu
@vax.clarku.eduz
@vp
A!
A#
A$
A%
A&
A(2
A*
A+
A.B
A02
A04
A6
A8
A86
A86%
A86%A
A86%A8
A9
A90
A94
A;
A;)
A<
A=
AA0
AA1
AA2
AEL
AH:
AM@
AME
AME 
API 
ARS
ARY
ARY_
AS$
AS'
ATH
ATH 
ATM
ATM 
AXz
AXz'AX
AXz'AX<Q
AXz'AX<QQ
AXz'AXz
AXz'AXz'
AXz'AXz'A
AXz'AXz'AXz'AS'$9
AXz'AXz'AXz'AS'$9@
AXz'AXz'AXz'AXz',
AXz'AXz'AXz'AXz',<
AXz'AXz'AXz'AXz'AX?
AXz'AXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz',3
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX<
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz',
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX<
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'M
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MA
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAX
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'A
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'M
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MA
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAX
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'A
AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'M
AXz'AXz'AXz'AXz'AXz'AXz'MA
AXz'AXz'AXz'AXz'AXz'AXz'MAX
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'A
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'M
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MA
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAX
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'A
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'M
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MA
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAX
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'A
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AX
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'A
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'M
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MA
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAX
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'A
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AX
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'A
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AX
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'A
AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AX
AXz'AXz'AXz'MAXz
AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz
AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'
AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'A
AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AX
AYI
AZ
A[
A\
A]
A^
A`
Administrator
Allo
Alloc
AppC
AppContext
ApplicationContext
Ard
Area
Area 
Area(
Area()
Area() 
Ath
Athe
Athen
Athena
Athena 
Athena widget
Attr
Attrib
Attribute
Author 
B!
B#
B$
B%
B&
B(
B*
B+
B. L
B.D
B3 
B6
B8
B8E
B8F)
B8F)3
B8F)3$
B8F)B
B8F)B8
B8F)B8E,
B8F)B8E,3$
B8F)B8F)B8F)B8
B8F)B8F)B8F)B8F
B8F)B8F)B8F)B8F)
B8F)B8F)B8F)B8F)B
B8G
B;
B<
B<G
B=
B@I
BAT
BC+
BDF
BF
BHJ
BHJ*
BHJ*B
BHJ*BH
BHJ*BHJ
BHJ*BHJ*
BHJ*BHJ*BHJ
BHJ*K
BHJ*KN[
BHJ*KN[N
BHJM
BHJN
BHJN[
BHJN[Mz
BIZ
BJ
BJ-
BJ2
BJ[7@
BJ[NU
BJ[NUYz
BK
BMP file
BMP files
BQ
BS0T
BS3
BUG
BV
BX
BXL
BXLT
BXN
BXN+
BXN+BX
BXO
BXOM[z
BXOM[zWM
BZ
B[
B\
B^
B^U
B^W
B_
BadMatch
Better
Brad 
Brett
Brett 
Brian D
Brian De
Bubble
BubbleJet
Butt
Button
C DI
C DISK
C"
C" 
C#
C$
C%
C&
C*
C.O
C4U
C7
C:\
C;
C<
C=
CB3
CCC
CCM
CF,
CHP
CHZ
CIC
CICA
COPY
CP/
CP@
CQ
CT]
CV9
CX^
CZ
C[
C\
C_
C`
Cann
Canno
Cannot 
Canon BJ200 (BubbleJet) 
Canon BJ200 (BubbleJet) and 
Cc: 
Chal
Challenge
Challenge 
Challenge to M
Client
Client 
Clients
Colormap
Colormap(
Compiling 
Conso
Consort
Consortium
Contex
Context
Context 
Control 
Cool 
CopyArea
Crea
Creat
Create
CreateColormap
CreateManagedWidget
CreateWi
CreateWindow
Creating 
Ctrl
Curs
Cursor
Cursor 
D#
D#7
D#M
D#`
D#`P
D$
D%
D%!
D&
D(
D)"
D+
D-4
D4
D6
D6%
D8
D9
D9&
D9&1D
D9&1D9
D9&1D9&1D
D9&1D9&1D9
D9&1D9&1D9&
D9&1D9&1D9&1
D9&7%Q
D9<
D9M
D;
D<
D=
DESQview
DESQview/X
DI*
DISPL
DK
DK 
DK)
DMD
DMY
DOM
DOS app
DOS b
DOS box
DOW
DQ
DRV
DW
DW 
DY.
DZ
D[
D\
D]
D]/
D]/3
D]/3T]
D]/=
D^
D_
D_S
Dave L
Dave La
David B. Lewis
Default
Derek 
Derek C. Richardson
Dialog
Display(
Distribution: worldMessage-ID: <1t
Dortmund
E"
E"P
E"PM
E"PMF
E"V
E#
E$
E%
E(
E)2
E,3
E-Mail: 
E-mail   
E01
E14
E1T
E1]
E5
E;
E<
E=
ECS
EFT
EI0
EI4
EI4=
EI4='
EI:4
EI:6
EI:6E
EI:6EI
EI:6EI4
EI:6EI4=
EI:6EI4='
EI:6EI:
EI:6EI:6
EI:6EI:6E
EISA v
EJ
EL P
EM"
EM)
EM@
EMU
ENG
ENW
EQ<
EQM
EQT
EU=
EX#
EYz
E[
E\
E^
E_
E`
Event
Event 
Events
Exe
Exec
Exi
Expos
Expose
Expose Event
Expose Events
F"
F"P
F"PN
F"PNE
F"PNE1
F#
F$
F%
F&
F(
F)3
F)B
F)B8
F)B8F
F)B8F)
F)B8F)B
F)B8F)B8
F)B8F)B8E,
F)B8F)B8F
F)B8F)B8F)
F)B8F)B8F)B
F)B8F)B8F)B8
F)B8F)B8F)B8F
F)B8F)B8F)B8F)
F)B8F)B8F)B8F)B
F)B8F)B8F)B8F)B8
F)R
F+
F0,#
F0-
F0-z7
F1
F3T
F3T]
F3W2<
F9
F9/
F9@
F9@L+
F9D
F9D#
F9D]/3
F9D]/3T]
F9D]T
F9F
F9F3
F9F9
F9F9D
F9F9D]
F9F9D]/
F9F9F9F
F9F9F9F9
F9F9L
F9F9`
F9F;
F9M
F;
F<
F=
FIJ
FILES
FJ
FK
FLA
FM"
FM9
FP4
FPL
FPL+
FPM
FQ
FQ#
FQ,
FQ,3$
FY
FYN
FZ
F[
F]
F_
Fals
False
Fax   
Fax : +
Ferr
Ferrell
Fill
Font 
Fore
Foreground
Fue
Fz
G#
G#P
G$
G$9
G%
G%Q
G&
G)%
G)B
G)M
G)R
G)R<G
G)R<G)R<
G)R<G)R<G
G)R<G)R<G)
G)R<G)R<G)R
G)R<G)R<G)R<
G)R<G)R<G)R<G
G*
G+
G3
G4
G5
G6
G7
G8
G9
G9P
G9P\/
G9V
G9V=
G9V=G
G9V=G9
G9\
G:
G;
G<
G=
GC
GC 
GCS
GF
GG5
GIZ
GIZM
GIZWT
GIZzG
GIZzGI
GIZzGIZ
GIZzM
GIZzM_?
GIZzM_?W
GJ
GK?
GK?1
GK?1T
GK?1TzE
GK?W
GK?WT
GL w
GM9
GMA
GQ
GV
GV.
GX
GXxor
GY
GZ
G[
G\
G]
G^
G_
Georgia Institute of Technology
GetV
Grab
Graphical
Guide
Guide 
Gz
H    
H"
H#
H$
H%
H&
H'
H*
H+
H/
H0
H1
H4
H6
H7
H8
H9
H:
H;
H<
H=
H?
H@
HA 
HA  
HAE
HAP
HC
HF
HG
HJ
HJ*
HJ*BH
HJ*BHJ
HJ*BHJ*
HJ*BHJ*B
HJ*BIZzG
HJ*BJ[
HJ*BJ[N
HJM
HJM*
HJN
HJNU
HJz
HJzG
HJzGI
HM
HM 
HOME/
HOS
HP 9
HP 9000
HP'
HP-U
HP-UX
HP-UX 
HP-UX 8
HPA
HW
HX
HZ.
H[
H\
H]
H^
H_
Handl
Handle
Handler
Hin
Hint
Hope it 
I ain't 
I can e
I creat
I create
I create 
I mean, 
I start
I start 
I!
I"
I#
I$
I%
I&
I&1
I've been u
I've been using 
I*
I*2
I+
I0
I0L
I0L+9
I0L+9L
I0M
I0O
I1
I3
I4
I4=
I5
I6
I7
I8
I9
I:4
I:4+
I:4+"
I:4+"V
I:4+"V9F
I:5
I:6
I:6E
I:6E"
I:6E"P
I:6EI
I:6EI:
I:6EI:6
I:6EI:6E
I:6EI:6EI
I;
I<
I=
I=7
ICC
ICCCM
IG.
IIM
IJ:
ILD
ILES
IM+
IM.
IM/
IM0
IMS
IN-
IN.
IN;
IND
INI 
IOT
IPC
IPC 
IPX
IS:
IS: 
IT X
IT'
IT's
IT)
IT-
IT?
IUB
IV=
IXI
IZ
IZ*
IZE
IZM
IZW
IZWT
IZW]
IZW]]
IZW]]'
IZz
IZzB
IZzBHJ
IZzBHJ*
IZzGIZz
IZzGIZzG
IZzGIZzGI
IZzGIZzGIZ
IZzGIZzGIZz
IZzGK?
IZzGK?W
I[
I\
I]
I^
I_
Imakefile 
In article <1993Ma
In article <1993May
In article <1993May1
In article <1s
In article <930
In article <9304
In article <C6
Initiali
Initializ
Initialize
Inp
Input
International I
Intri
Intrinsic
Intrinsics
Iskandar Taib
It n
It no
It's c
Iz
J!
J"
J#
J$
J%
J&
J'
J(
J)
J*
J*B
J*BH
J*BHJ
J*BHJ*
J*BHJ*B
J*BHJ*BH
J*BHJ*BHJ
J*BIZ
J*BIZz
J*BIZzG
J*G
J*GIZz
J*K
J+
J-
J-2
J/
J0
J1
J20
J4
J5
J6
J7
J8
J9
J:
J:F
J;
J<
J=
J?
J@
JD
JH
JJ
JL
JM
JM*
JMN
JMz
JN
JNU
JN[
JQ
JS
JU
JUM
JW
JX
JY
JZ
J[
J[7
J[7E
J[N
J\
J]
J^
J_
J`
Jesse
Jesse 
John A
John Br
Johnson 
Jz
JzG
JzGIZ
JzM
K (
K!
K"
K#
K$
K%
K&
K'
K(
K*
K*R
K*RL
K*S
K*Z
K+
K.        
K.S
K3
K5
K6
K7
K8
K9
K:
K: 
K;
K<
K=
K?
K?1
K?I
K?M
K?W
K?W]_
KD
KF
KIS
KJ
KMZ
KMz
KN[N[
KN[N[N[
KO
KQ
KS IN 
KT
KU
KV
KX
KZ
K[
K\
K]
K^
K_
Ken L
KeyPress
Keys
L PA
L!
L!D
L"
L#
L$
L%
L%-
L%-34U
L%/
L%/M
L&
L(
L);
L*
L+
L+!
L+!3
L+!34
L+"
L+"P
L+"PL
L+"PL+
L+"PL+"PL+
L+"PL+"PL+"
L+"PL+"PL+"P
L+"PN
L+"PNE
L+9
L+9F
L+9F9F
L+9F;
L+9F;$
L+9L3
L+I
L+M
L0
L0Q
L2'
L3$
L45
L4M
L6
L7
L;
L<
L=
L?
LD_
LF
LG)
LG)R
LH
LIM
LIT
LJ
LJ*
LJ*BHJ
LJzM
LK*
LK*R
LL)
LL, 
LM:
LOO
LOOK
LQ
LSE
LTQ
LV
LX 
L[
L\
L]
L^
Lak
Lake
Lic
Licen
Licens
License
Litt
Lotus
Lotus 
Lz_
M!H
M"
M"P
M#
M#P
M$
M$1
M%
M%A
M&
M&1
M&7
M'W
M(
M(]
M)Q
M*
M*B
M*K
M+
M+2
M+2T
M+2TM
M+2TM+
M+R
M,3
M-#
M-(
M-,
M.B
M.M
M/3
M/X
M0
M1T
M3$
M3$Q,
M3$Q,3
M3$Q,3$
M34
M4U
M4U-3
M4U-34
M4U-34U
M4[
M5%
M6
M7
M75
M7E
M8
M86
M9
M9F
M9F9
M9P
M9V
M;
M;%
M;&
M;6
M;F
M<
M<1
M<7
M<B
M=
M@
MA8
MAL
MAM
MARY
MAXz
MAXz'
MAXz'A
MAXz'AX
MAXz'AXz
MAXz'AXz'
MAXz'AXz'A
MAXz'AXz'AX
MAXz'AXz'AXz
MAXz'AXz'AXz'
MAXz'AXz'AXz'A
MAXz'AXz'AXz'AX
MAXz'AXz'AXz'AXz
MAXz'AXz'AXz'AXz'
MAXz'AXz'AXz'AXz'A
MAXz'AXz'AXz'AXz'AX
MAXz'AXz'AXz'AXz'AXz
MAXz'AXz'AXz'AXz'AXz'
MAXz'AXz'AXz'AXz'AXz'A
MAXz'AXz'AXz'AXz'AXz'AX
MAXz'AXz'AXz'AXz'AXz'AXz'
MAXz'AXz'AXz'AXz'AXz'AXz'A
MAXz'AXz'AXz'AXz'AXz'AXz'AX
MAXz'AXz'AXz'AXz'AXz'AXz'AXz
MAXz'AXz'AXz'AXz'AXz'AXz'AXz'
MAXz'AXz'AXz'AXz'AXz'AXz'AXz'A
MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz
MB8
MBS
MBX
MCP
MD9
MD=
MDT
ME)
ME.
ME/
MEC
MF3
MF9
MF9F
MF9F9
MF9F9F
MFC
MFQ
MFQ#
MG9
MI0
MI0MF
MI:
MI:6
MI:6E
MICH
MICHAEL 
MIT X
MIT X11R5
MIT-
MK&
MK:
MK@
ML+
MM+
MM;
MMA
MMR
MMV
MM[
MNU
MN[
MN[N
MOU
MOUS
MOUSE
MPY
MQ
MQ#
MQ,
MQ<
MQ\
MR8
MR<
MS M
MS W
MS Win
MS Window
MS Windows
MS Windows 
MS s
MS3
MSW
MSW 
MTM
MTX
MU-
MVM
MW
MWT
MW]
MZ
M[
M[5
M[8
M[8N+
M[z
M[zU3
M[zU34
M[zW
M[zWM
M[zWM[
M[zWM[z
M\
M]
M]'
M^
M_
M_?
M_?W
M_?W]
M_?W]_
M_?W]_?
M`
Mah
Maha
Mahan
Mail: 
MainLoop
Managed
Manager.
Mark A. D
Mark A. Davis
Mask
Mask 
Mask,
Match
Menu
Message-ID: <0
Message-ID: <1s
Message-ID: <1sr
Message-ID: <93
Message-ID: <930
Message-ID: <9304
Message-ID: <93042
Michael Panayiotakis
Mick
Micke
Mickey
Mickeype-|| ||  MICHAEL PANAYIOTAKIS: louray@seas.gwu.edu ace|| ||                                   ...!uunet!seas.gwu.edu!louray|||| \/|  
Mickeype-|| ||  MICHAEL PANAYIOTAKIS: louray@seas.gwu.edu ace|| ||                                   ...!uunet!seas.gwu.edu!louray|||| \/|  *how do make a ms-windows .grp file reflect a HD directory??*\\\\   |  "well I ain't always right, but I've never been wrong.."(gd)
Microso
Microsoft
Microsoft 
Microsoft's 
Moore
Moti
Motif
Motif 
Motif 1.
Motif 1.1
Motif 1.1 
Motif 1.2
Motif 1.2 
Motif 1.2.
Motif W
Motif Wi
Motif a
Motif and
Motif and 
Motif app
Motif application
Motif i
Motif pr
Motif t
Motif v
Motif w
Motif wi
Motif,
Motif, 
Motif.
Motif. 
Motif?
Mz7
Mz7E
Mz7EY
MzF
MzG
MzM
MzN
Mz`
Mz`Y
N 1
N L
N W
N WINDOWS
N!
N"
N#
N$
N%
N&
N(
N*
N+
N+-
N+B
N+BX
N+BXN
N+BXN+
N+BXN+B
N+M
N+[
N.9
N.C
N;
N;F
N;G
N<
N=
NAG
NAM
NAME
NAME 
NASA/
NAY
NCD
NCD 
ND.
NDO
NDW
NDW 
NE1
NE1T
NEI
NEI:
NEM
NH
NNTP-Posting-Host: e
NNTP-Posting-Host: en
NNTP-Posting-Host: enterpoop.mit.edu
NNTP-Posting-Host: enterpoop.mit.eduTo: 
NNTP-Posting-Host: enterpoop.mit.eduTo: x
NNTP-Posting-Host: enterpoop.mit.eduTo: xpert
NNTP-Posting-Host: enterpoop.mit.eduTo: xpert@expo
NNTP-Posting-Host: enterpoop.mit.eduTo: xpert@expo.lcs.mit.edu
NNTP-Posting-Host: enterpoop.mit.eduTo: xpert@expo.lcs.mit.eduI
NNTP-Posting-Host: irzr17.inf.tu-dresden.deIn article <
NNTP-Posting-Host: se
NQ
NRH
NRHJ
NRHJ*
NRHJ*B
NRHJz
NRHJzG
NRI
NRIZ
NRIZz
NT,
NT, 
NT?
NUL
NULL
NULL)
NULL);
NULL,
NUX
NUX#
NUY
NUYz
NUYz`
NUZ
NW
NWI
NX
NZ
N[
N[*
N[*BHJ
N[7
N[L
N[LJ*
N[LJ*B
N[M
N[Mz7
N[Mz7E
N[N
N[N[
N[N[*B
N[N[N
N[N[NR
N[N[NRHJ
N[N[N[
N[N[N[N
N[N[N[N[
N[N[N[N[N
N[N[N[N[N[
N[N[N[N[N[N
N\
N]
N^
N_
Name: 
Network S
Norton D
Norton Desktop
Norton Desktop 
Norton Desktop for 
Norton Desktop for Windows
Noti
Notif
Notify
Ny
Nz
O U
O e
O error
O#
O$
O%
O&
O'R
O'Reilly
O'Reilly 
O(
O*
O+
O+R
O.B
O.C
O.L
O/
O0
O1
O2
O2 
O4
O5
O6
O7
O8
O9
O;
O<
O=
O?
O@
OAD
OCAL
ODI
OJ
OLI
OLIT
OM;
OM[
OM[5
OM[zWM
OND
OPEN
OPENWIN
OQ
OQ\
OR A
ORR
OS 4
OS 4.
OS 4.1
OS 4.1.
OS 4.1.2
OS box
OS2
OS4
OS5
OTIF
OW 3.
OW T
OWS
OWS 
O[
O[^
O\
O]
Open
Open Look
OpenD
OpenDis
OpenDisplay
OpenDisplay(
OpenL
OpenLook
OpenWin
OpenWindow
OpenWindows
OpenWindows 
OpenWindows 3.0 
OpenWindows.
Output
Overr
P 9
P 9000
P#
P$
P%
P&
P&1
P&7
P(
P*
P+
P,#
P,#`
P,#`P
P,#`P,
P,#`P,#
P,#`P,#`
P,#`P,#`P
P-PC
P-U
P-z
P-z7
P/
P/#
P/M
P4
P4U
P4U-
P4U-3
P4U-34
P7
P8
P;
P<
P<'
P=
P@
PANA
PAT
PATH
PATH 
PAX
PCF
PEN
PF
PIF
PIF 
PJ
PK
PL!
PL!D9
PL!D9&
PL%
PL%-3
PL%-34
PL+
PL+!
PL+"PL+"
PL+"PL+"P
PL+"PL+"PL
PL+"PL+"PL+
PL+"PL+"PL+"
PL+"PL+"PL+"P
PL+`
PM&
PM4
PMF
PML
PNE
PQ
PX.
PY?
PZ
P[
P\
P\/
P\/#
P\/#P
P\/#P\
P\/#P\/
P\/3
P\/3$
P\/3$Q,
P\/3$Q,3
P]
P],
P],3
P],3$
P],3$Q,
P],3$Q,3
P]G
P^
P_
P`
Pana
ParcPlace
Parent
Patrick L
Patrick L.
Patrick L. M
Patrick L. Mahan
Perm
Permi
Permission 
Pixmap
Pixmap 
Plane 
Pointer
Pop
Popu
Procomm 
Program M
Program Ma
Program Man
Program Manager
Proper
Propert
Properties
Pse
PutImage
Q#
Q#$
Q#$QAXz'
Q#&
Q#&'
Q#&'AX
Q#&'AXz'
Q#&'AXz'A
Q#&'AXz'AXz'
Q#&'AXz'AXz'AX
Q#&'AXz'AXz'AXz'
Q#&'AXz'AXz'AXz'AXz'
Q#&'AXz'AXz'AXz'AXz'AXz'
Q#&'AXz'AXz'AXz'AXz'AXz'AXz
Q#&'AXz'AXz'AXz'AXz'AXz'AXz'
Q$
Q%
Q&
Q&1
Q&8
Q&8+
Q&9
Q&9F"
Q&;
Q(
Q*
Q+
Q,#
Q,0
Q,1
Q,1F"
Q,3
Q,3$P/
Q,3$Q&
Q,3$Q&9F
Q,3$Q,3$Q
Q,3$Q,3$Q,3$Q,3$Q
Q,3$Q,3&'AX
Q,3$Q,3&'AXz'
Q,3$Q,M
Q,3$Q,M3
Q,3&
Q,3&'AXz'AXz'AXz'AXz'A
Q,3`
Q,3`\/
Q,<
Q,M
Q,M3$
Q,M3$Q,
Q-
Q/
Q0
Q04
Q1
Q30
Q30T
Q32
Q6
Q6=
Q6=G
Q;
Q<
Q<1
Q<4
Q<4T
Q<4T-
Q<5
Q<5G
Q<5G9
Q<7
Q<7%
Q<7%9
Q<7%9V
Q<7%9V=G
Q<7%Q
Q<7%Q<7%
Q<7%Q<7%Q
Q<7%Q<7%Q<
Q<7%Q<7%Q<7
Q<=
Q<=+2
Q<=+2T
Q=
Q?
Q@
QAXz'A
QAXz'AXz'AXz'AXz'A
QAXz'AXz'AXz'AXz'AXz'
QAXz'AXz'AXz'AXz'AXz'A
QAXz'AXz'AXz'AXz'AXz'AX
QAXz'AXz'AXz'AXz'AXz'AXz'
QAXz'AXz'AXz'AXz'AXz'AXz'A
QAXz'AXz'AXz'AXz'AXz'AXz'AX
QAXz'AXz'AXz'AXz'AXz'AXz'AXz
QAXz'AXz'AXz'AXz'AXz'AXz'AXz'
QAXz'AXz'AXz'AXz'AXz'AXz'AXz'A
QAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
QAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
QAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
QAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
QAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
QAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
QAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
QAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
QAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
QB
QD
QF
QG
QH
QJ
QK
QL
QM
QM,
QM<
QMA
QMT
QO
QP
QQ
QQ&
QQ,
QS
QTC
QTM
QTM+
QTM+2
QV
QVT
QY
QZ
Q[
Q[^
Q\
Q\?
Q\?'
Q\z
Q]
Q^
Quer
Query
Qz
R!
R#
R$
R%
R&
R(
R)B
R)B8
R)B8F
R*
R+
R,C
R0
R3 
R3,
R4
R4 
R4 a
R4 and 
R4 o
R4 s
R4 server
R4)
R4,
R4, 
R4.
R4/
R5
R5 
R5 X
R5 a
R5 and
R5 and 
R5 d
R5 di
R5 dis
R5 dist
R5 distribution
R5 i
R5 o
R5 on
R5 on 
R5 s
R5 server
R5 t
R5 to
R5)
R5,
R5, 
R5.
R5. 
R5/
R5?
R6
R7
R8
R8F
R;
R<
R<D
R<G
R<G)
R<G)R
R<G)R<
R=
R?
RAR
RB 
RCI
RCS
RFI
RH
RHJ
RHJ*
RHJ*B
RIZ
RJ
RLK
RM)
RMD
RRO
RUN
RW
RX
RY:
RYN
RY_
RZ
R[
R\
R\O
R^
R_
Raine
Rainer
Rainer 
Re: X
Realize
Rect
Redi
References: <93
References: <930
References: <9304
References: <C6
Reilly
Reilly 
Release 
Return
Richard G
Richard Gooch
Root
RootWindow
RootWindow(
Runn
Running
Running 
Rz
S		
S 4
S 4.
S 4.1
S B
S IN 
S MO
S MOU
S Wi
S Win
S Window
S and W
S app
S apps
S box
S window
S#
S#z
S$Q
S%
S&
S'$
S,S
S.G
S.M
S0T
S3%
S5
S8
S9
S<
S<W
S<W-
S=
SC?
SD-
SDK
SEM
SHM
SJ
SLI
SL[
SL[.
SMA
SPARC 
SQM
SS2
SUB
SVR
SVR4
SVR4 
SW 
SYSV
SZ
S[
S\
S\_
S]
S^
Save
Sean Eckton
Sender: news@
Sender: news@a
Sender: news@athena.mit.eduMessage-ID: <
Sender: news@athena.mit.eduMessage-ID: <930
Sender: news@athena.mit.eduMessage-ID: <9304
Sender: news@athena.mit.eduMessage-ID: <93041
Sender: news@athena.mit.eduMessage-ID: <93042
Sender: news@athena.mit.eduMessage-ID: <9305
Sender: news@athena.mit.eduMessage-ID: <93051
Senior 
Server
SetF
SetFo
SetValue
SetValues
SetValues 
SetW
Setting 
Shel
Shell
Shell 
ShellWidget
ShellWidgetClass
Sola
Solar
Solari
Solaris
Solaris 
Solaris 2
Solaris 2.
Strange 
String
String 
Subject: Problem with 
Subject: Re: AT
Subject: Re: Animation
Subject: Re: Animation with XPutImage()?
Subject: Re: Blinking Cursor in Xterm???
Subject: Re: Canon BJ200 (BubbleJet) and HP DeskJet 500...
Subject: Re: Ch
Subject: Re: Cha
Subject: Re: Challenge to Microsoft supporters.
Subject: Re: Challenge to Microsoft supporters.I
Subject: Re: Challenge to Microsoft supporters.In 
Subject: Re: Challenge to Microsoft supporters.In article 
Subject: Re: Challenge to Microsoft supporters.In article <
Subject: Re: Challenge to Microsoft supporters.In article <1
Subject: Re: Looking 
Subject: Re: Looking for 
Subject: Re: Looking for X windows on a PC
Subject: Re: MAC
Subject: Re: MAC DISKS IN WINDOWS?
Subject: Re: More 
Subject: Re: More Cool BMP files??
Subject: Re: Ti
Subject: Re: Tr
Subject: Re: Why is my mouse so JUMPY? 
Subject: Re: Wi
Subject: Re: Win
Subject: Re: Window
Subject: Re: Windows 
Subject: Re: X
Subject: Re: X 
Subject: Re: XV 3.0
Subject: Re: XV 3.00 has escaped!
Subject: Re: XV 3.00 has escaped!I
Subject: Re: XV 3.00 has escaped!In
Subject: Re: he
Subject: Re: head-to-head win and
Subject: Re: r
Subject: Re: re: Challenge to Microsoft supporters.
Subject: Wi
Subject: Win
Subject: Window
Subject: Windows
Subject: Windows 
Subject: X
Subject: X 
Subject: X11
Subject: comp.
Subject: comp.windows.x
Subject: roman
Subject: roman.bmp 
Subject: x
SunO
SunOS
SunOS 
SunOS 4
SunOS 4.
SunOS 4.1
SunOS 4.1.
SunOS 4.1.1
SunOS 4.1.3
Sus
Systems A
Systems P
Systems Pro
Systems Programmer
Systems Programmer 
T X
T"
T#
T$
T%
T-#0
T-#0T
T-#0T-
T-#0T-#0T-
T-#2
T-#3
T-(
T-(N+
T-,
T-S
T0
T10
T6
T7
T9
T<
T=
T='
T='1
T='1T
T='1T=
T='1T='
T='1T='1
T='1T='1T
T='1Z
T='1Z6E
T='1Z6EI
T='1]
T='I:4+
T='I:6E
T='M
T='W]_?W
T??
T@
TAK
TAKI
TBX
TBXOM
TBXOM[
TCP
TCT
TCT]
TCV
TDR
TDRV
TE)
TERM
TFM
TG$
TG%
TGV
TH,
TH.
TJ
TM(
TM(]
TM(]/
TM)
TM)Q
TM)Q<
TM+
TM+2TC
TM+2TM
TM+2TM+
TM+2TM+2
TM+2TM+2T
TM+2TM+2TM
TM-
TQ
TQ6
TQ<
TWM
TZ
T[
T\
T]/
T]/3T]/
T]/3V
T]/=
T]F
T]M
T]T
T^
T_
Technical Co
Technical Con
Technical Conference
Tel: +
Text 
The X
The X 
The wi
The win
The x
This com
Title 
To co
To: x
To: xannounce@expo.lcs.mit.edu
To: xpert
To: xpert@expo
To: xpert@expo.lcs.mit.edu
To: xpert@expo.lcs.mit.eduH
To: xpert@expo.lcs.mit.eduI
To: xpert@expo.lcs.mit.eduI 
Tob
Tobias
Translations
TrueType
TrueType 
TrueType font
TrueType fonts
TrueType fonts 
Tut
Type f
Type font
Type fonts
Type fonts 
TzE
TzEI0L+
TzEI:
U!
U"
U#
U$
U%
U%1
U&
U(
U)2
U*
U+
U-3
U-34
U-34U
U-34U-
U-34U-3
U-34U-34
U-34U-34U
U.P
U/
U/M
U0
U1
U2
U3
U34
U34U
U3L
U4
U5
U6
U7
U8
U9
U:
U;
U<
U=
U=3
U=7
U=75U
U=75U=
U=75U=7
U?
U@
UA 
UAX
UH
UIL
UIM
UJ
ULL)
UM-
UM8
UM;
UM=
UMM
UMP
UQ
USE)
USM
UX 8
UX 8.
UX#
UYz
UYz7
UZ
UZZ
U\
U]
U]1
U]?
U^
U_
U`
Ultrix 
Undefined
Usenet news
Utility f
V 3
V 3.
V!
V!1
V"
V#
V$
V%
V&
V(
V*
V+
V+-
V+B
V+BS
V.C
V1
V6
V7
V8
V9
V9F
V9F9
V9F9F
V9F9F9F9
V9M
V:
V;
V;$
V<
V=
V=G
V=G9
V=G9V=G9V=G9V
V=G9\
V=G9\7%
V=GM
V?
V?%
V@
VB
VD
VF
VJ
VK
VMK
VML
VMM
VP&
VQ
VR4
VT
VT1
VU
VUM
VW
VX 
VY
VZ
V[
V\
V]O
V^
V_
Values
Values 
Visual 
Voice 
Voice  
Voice   
Vz
W   
W    
W 2
W 2.
W 3.
W T
W m
W"
W#
W$
W%
W&
W(
W*
W+
W-S
W/
W2T
W3
W4
W46
W4W
W4WG
W4WG 
W6
W8
W9
W;
W<
W=
W@
WF
WG
WG 
WHJ
WIN
WINDO
WINDOW
WINDOWS
WINDOWS 
WIZ
WJ
WL
WM
WM 
WM-
WM4
WMB
WMM
WM[
WM[zU3
WM[zW
WORD
WP-
WQ
WS?
WT
WT=
WT='
WT='1
WT='1T
WT='I
WT='I:
WT='M
WTz
WW
WWH
WWHJ
WWHJN
WWHJNU
WWI
WWIZ*
WWIZ*B
WX
WY
WZ
W[
W\
W]
W]]
W]]'1
W]]Zz
W]]ZzB
W]]ZzBHJ
W]_
W]_?
W]_?1
W]_?1T
W]_?M
W]_?W
W]_?W]
W]_?W]]
W]_?W]]Z
W]_?W]_
W]_?W]_?
W]_?W]_?W
W]_?W]_?W]
W]_?W]_?W]_
W]_?W]_?W]_?
W]_?z
W]_?zG
W^
W_
Ware 
Warn
Wc
Whal
Whale
When I t
When I try 
Whenever
Whenever 
Wid
Widg
Widget
Widget 
Widget(
WidgetClass
WidgetClass,
Widgets
Widgets 
Win
Win 
Win 3
Win 3.
Win 3.1
Win 3.1 
Win.
Win3
Win3.1
Win3.1 
Wind
Windo
Window
Window 
Window S
Window System
Window i
Window(
Windows 
Windows & 
Windows (
Windows 2
Windows 3
Windows 3.
Windows 3.0
Windows 3.0 
Windows 3.1
Windows 3.1 
Windows 3.1?
Windows ?
Windows NT
Windows NT 
Windows S
Windows a
Windows and
Windows and 
Windows app
Windows application
Windows applications
Windows e
Windows f
Windows fo
Windows for
Windows for 
Windows for W
Windows for Work
Windows for Workgroups
Windows h
Windows on 
Windows p
Windows pr
Windows pro
Windows program
Windows re
Windows s
Windows se
Windows so
Windows t
Windows u
Windows us
Windows w
Windows wi
Windows, a
Windows?
Windows? 
Word f
Workgroup
Workgroups
Workgroups 
Wz
X -
X 8
X A
X Co
X Con
X Conso
X I
X M
X R
X Re
X Res
X Resource
X T
X Toolkit
X W
X Win
X Window
X Window 
X Window S
X Window System
X Window System 
X X
X app
X applica
X applicatio
X application
X application 
X c
X cl
X client
X d
X di
X dis
X p
X pr
X pro
X protocol
X protocol 
X re
X se
X ser
X server
X server 
X servers
X servers 
X so
X te
X term
X terminal
X terminal 
X wi
X window
X!
X"
X#
X#F
X#F3
X$
X%
X&
X'
X*
X-A
X-s
X-server
X-server 
X-te
X-terminal
X-window
X.#
X0
X1
X11
X11,
X11, 
X11/
X11/X
X11R
X11R4
X11R4 
X11R4 s
X11R5
X11R5 
X11R5 a
X11R5 and
X11R5 and 
X11R5 s
X11R5,
X11R5, 
X11R5.
X11R5/
X4
X6
X7
X8
X9
X;
X<
X<Q
X=
X?
X? 
X?$
X@
XAll
XC
XCo
XCop
XCopy
XCopyArea
XCopyArea(
XCopyPlane
XCreate
XCreateWindow
XCreateWindow(
XDM
XDraw
XFree
XFree86
XFree86 
XG
XGet
XH
XI
XI 
XImage
XIn
XJ
XK
XKey
XLT
XMa
XN
XN+
XN+B
XN+BX
XO
XOpen
XOpenDisplay
XP
XPut
XPutImage
XPutImage(
XPutImage()
XQ
XR
XRe
XS
XSe
XSet
XSetF
XSetW
XTe
XTerm
XU
XVi
XView
XView 
XW
XWi
XZ
X[
X\
X]
X^
X_
X`
Xa
Xaw
Xaw 
Xb
Xc
Xco
Xd
Xde
Xdefault
Xdefaults
Xdefaults 
Xex
Xext
Xext 
Xh
Xin
Xl
Xli
Xlib
Xlib 
Xlib,
Xlib.
Xm
Xmu
Xmu 
Xmu -lX
Xmu.
Xo
Xp
Xpe
Xper
Xr
Xre
Xs
Xse
Xserver
Xservers
Xsu
Xt
Xt 
Xt,
XtA
XtApp
XtC
XtCreate
XtD
XtDi
XtDisp
XtDisplay
XtG
XtI
XtM
XtN
XtP
XtPo
XtPointer
XtR
XtRe
XtReal
XtRealizeWidget
XtS
XtSet
XtVa
XtW
XtWi
XtWindow
XtWindow(
Xte
Xter
Xterm
Xterm 
Xv
Xvi
Xview
Xview 
Xw
Xwi
Xwindows
Xx
Xz
Xz'
Xz'A
Xz'AXz'AXz'AXz'AXz'AX?
Y"
Y#
Y$
Y%
Y&
Y'
Y(
Y*
Y+
Y.3
Y.9
Y0
Y2
Y3
Y4
Y5
Y6
Y7
Y8
Y9
Y:6
Y;
Y<
Y=
Y?
Y? 
Y@
YD]
YF
YF9
YF9F
YG
YI
YIO
YJ
YL
YN;
YP
YSV
YV
YW
YX
YY
Y[
Y\
Y^
Y^?
Y_
Yz
Yz7
Yz7E
Yz7EY
Yz7EYz
YzM
YzN
Yz`P
Yz`P.9
Z!
Z"
Z#
Z$
Z%
Z&
Z'
Z(
Z*
Z*B
Z*BH
Z*BHJ
Z*BHJ*
Z*K
Z*KMz
Z+
Z.C
Z/
Z0
Z3
Z4
Z4+
Z5
Z5'
Z6
Z6E
Z6EI
Z6EI:
Z6EI:6
Z7
Z8
Z9
Z:
Z;
Z<
Z=
Z?
Z@
ZB
ZC
ZD
ZF
ZG
ZH
ZJ
ZL
ZM
ZMz
ZN
ZNK
ZO
ZP
ZQ
ZR
ZS
ZU
ZUM
ZV
ZWT
ZWTzE
ZWTzE"
ZX
ZY
ZZ
ZZ.
Z[
Z[N
Z[NR
Z[N[
Z]
Z^
Z_
Zz
ZzB
ZzBHJ*B
ZzG
ZzGI
ZzGIZW
ZzM
[!
["
[#
[$
[%
[&
['
[(
[)
[*
[*B
[*BHJ*
[*BHJz
[+
[,
[-
[.R
[.S
[/
[0
[0]
[10
[4
[5
[5-
[5.
[6
[7
[7@
[7@,
[7@,#
[7E
[7EX#
[7EX#`
[8
[8L
[8N
[8O
[9
[:
[;
[<
[=
[?
[@
[C
[D
[E
[G
[H
[J
[K
[L
[LJ
[M
[M*
[Mz
[NR
[NRHJ*
[NRHJ*B
[NU
[NUYz
[NUYz`
[N[
[N[L
[N[LJ
[N[LJ*
[N[LJ*B
[N[M
[N[Mz
[N[Mz7
[N[N
[N[N[*
[N[N[N[N[N
[O
[R
[R\
[T
[U
[V
[X
[Y
[Z
[[
[\
[^
[^_
[_
[`
[a
[th
[z
[zU
[zU34U
[zV
[zV+
[zV+B
[zW
[zWM
[zWM[
[zWM[z
\		
\   | 
\!
\"
\#
\$
\%
\&
\'
\(
\)
\*
\+
\,
\----
\-------
\--------
\-----------------------
\---------------------------
\------------------------------
\---------------------------------------------------------------------
\--------------------------------------------------------------------------
\.
\/#
\/#P
\/#P\
\/#P\/
\/#P\/#
\/3
\/9
\/9V
\/9V=G
\/M
\/|  
\0
\1
\2
\3
\4
\4T
\5
\6
\7
\7%
\7%Q
\7%Q<
\8
\9
\:
\;
\<
\=
\?
\?'
\@
\A
\B
\C
\D
\E
\F
\G
\H
\I
\J
\K
\L
\M
\N
\O
\O+
\P
\Q
\R
\S
\T
\U
\V
\W
\X
\Z
\[
\\\ 
\\\  
\\\\
\\\\ 
\\\\  
\\\\   |  
\]
\^
\`
\n
\n"
\n\
\z
] =
] s
] se
]!
]"
]#
]$
]%
]&
]'
]'1
]'1T
]'1T=
]'I
]'M
](
]+
],
],3
],3$
],M
]-
]/
]/3
]/3T]/
]/3T]/3
]/3T]/3T
]/3T]/3T]
]/3V
]/3V9
]/3V9F
]/3V9F9
]/3W2
]/9
]/9F9
]/=
]0
]1
]2
]3
]34
]5
]6
]7
]75
]8
]9
];
]; 
]<
]?
]?7
]?7U
]@
]B
]E
]F
]F0
]F9
]F9D
]G
]G9
]GM
]GQ
]J
]K
]L
]M/
]MF
]O
]Q
]S
]TM
]TM)Q
]TM+2T
]V
]W
]X
]Y
]Z
]ZzBHJ*
]\
]]
]]'
]]ZzB
]^
]_
]_?
]_?W
]_?WW
]_?WWIZ
]_?WWIZz
]_?W]
]_?W]_
]_?z
]_?zG
]`
]z
^!
^"
^#
^$
^%
^&
^'
^(
^*
^+
^,
^-
^.
^/
^0
^1
^2
^3
^4
^5
^6
^8
^9
^:
^;
^<
^=
^?
^@
^A
^B
^C
^D
^E
^F
^G
^H
^I
^J
^K
^L
^M
^N
^O
^P
^Q
^R
^S
^T
^U
^U3
^V
^V+
^W
^WM
^WM[
^WM[z
^X
^Y
^Z
^[
^\
^]
^_
^_O
^z
_                    
_                     
_                       
_                          
_                            
_                              
_                                 
_                                  
_!
_$
_%
_&
_'
_(_
_)/
_*
_+
_--
_/S
_0
_4
_5
_6
_7
_7U
_8
_9
_:
_;
_<
_?
_?1
_?M
_?MW
_?W
_?W]
_?W]_
_?W]_?W]_?W
_?W]_?W]_?W]
_?z
_@
_DE
_Ge
_H
_K
_L
_LI
_LIB
_M
_MA
_MO
_PA
_PATH
_Q
_R
_V
_X
_[
_\ 
_\  
_\   
_\    
_\      
__          
__            
__             
__               
__                 
__                  
__                    
__                     
__                       
__                          
__                            
__    __
__G
__\ 
__\  
___          
___               
___                 
___                  
___                     
___                          
___\ 
___\  
____          
____                 
____                  
____                     
_____            
_____             
______          
______            
______             
______                 
______                  
________          
________            
________             
________                 
________                     
_________            
_________             
_________                 
_application
_eve
_g
_ge
_get
_i
_in
_li
_mas
_n
_na
_no
_not
_p
_r
_s
_st
_wi
_win
_wm
`!
`"
`$
`(
`)
`.
`0
`0$
`0$!
`1
`2
`9
`9&
`9&1
`9<
`:
`;
`=
`@
`A
`C
`H
`M
`N
`P
`P,
`P,#F
`P,#M
`P,#M`
`P,#`P,
`P,#`P,#`
`P,#`P.9
`P-
`P-z
`P-zM
`P.
`P.9/
`P.9F
`S
`T
`U
`UY
`UYz
`UYzN
`W
`X
`Y
`YD
`YD]
`YD]T
`YF
`YF9
`YF9F
`YF9F9
`[
`\
`]
`s
a Bad
a Moti
a Motif
a Motif 
a Widget
a X
a X 
a dial
a dialog
a dialog 
a display 
a font
a font 
a function
a in Wi
a server
a server 
a shel
a shell
a tool
a valu
a value
a virtual 
a wid
a widget
a widget 
a widgets
a win
a window
a window manager
a window manager 
a()
a.gsfc.nasa.gov
a.m
a.mi
a.mit
a.mit.edu
a.mit.eduM
a.uc
ables to
about X
about your
ac.be
ace|
ach time
ach w
acro 
actually t
ad win
ad-t
adM
administrator
aes
afer
age(
age()
ager a
ager t
ager to 
ager,
ager, 
ager.
agers
agers 
ags 
aib
ail: a
ail: w
ain wi
ain'
ain(
ainer 
aji
akefile
akefile 
akefile.
aking a p
al Conf
al Conference
al Wi
al X
al X 
al cr
al error
al files
al fun
al functi
al function
al number of 
al page
al serv
al window
alam
aley
aley@
all W
all X
all window
allb
allback
allen
alleng
allocati
alls to 
ally ju
alog b
alse
alse 
am M
am at
am get
am ma
am) w
am) writes:
am.ac.uk 
amas
amba
ame buffer
ame it
ame machin
ame machine
ameb
ample a
ample i
ample in
ample pr
an De
an Eck
an Gr
an HP 
an Ho
an OL
an OS
an Wi
an X
an X 
an X window
an ftp site
an page
an page 
an x
an xt
an xterm
an xterm 
an.b
an@cs
an@cs.
an@o
anBr
anBrian 
anW
anX
anager 
anager a
anager and
anager and 
anager i
anager is
anager is 
anager s
anager t
anager to 
anager w
anager,
anager, 
anager.
anager. 
anager.  
anager?
anagers
anagers 
anaging
anaging 
anced m
anced mo
and /
and Mot
and Motif
and Motif 
and Op
and Ope
and Open
and Pa
and Win
and Wind
and Windo
and Window
and Windows
and Windows 
and X
and X 
and conf
and config
and repl
and repla
and rest
and system.ini
and x
andler
andler 
andrew.cmu.eduzReferences: <
ange fo
anon 
another ma
another t
antic
anuary 
anvas
any X
any X 
any fe
any ne
any new
ap and
ap and 
ap d
ap f
ap fi
ap file
ap file 
ap fo
ap"
ap(
ap;
apane
apanese
apital 
app 
app-
appear in
appear in 
appears i
appears in
append
apper
application 
application a
application an
application and 
application c
application co
application de
application f
application t
application th
application that
application that 
application w
application wi
application's
application,
application, 
application?
applicationShell
applications i
applications u
apps
apps 
apps a
apps,
apps.
aps,
aque
ar          
ar           
ar            
ar.m
arato
archy
archy 
ard             
ardson
are not re
ared m
ared me
arent w
argc
argc,
argc, 
args
args,
argv
ariables 
aries a
aries and
aris 
arizona
arizona.edu 
ark@t
arku
ars in
ars in th
art the 
as 7
as Mal
as X
as _
as es
as escape
as par
as part of 
as x
ase su
ased on X
asho
ask,
ask, 
ast I 
ast.c
astc
at MS
at Mic
at Micro
at OS
at Wi
at Win
at X
at app
at display
at the R
at the X
at the se
at the w
at the wi
at the win
atX
atal 
atch a
atches f
atches for
atches for 
atches, 
ate some
ateC
ateCo
ateColor
ateMa
ateW
ateWi
ates for a 
ates for a w
athen
athena
athena.
athname
ating Win
ation but 
ation is s
ation of X
ationC
ationCo
ationS
ationt
att@
attribute 
ave L
ay to f
ay(
ay1
ay|
azar
b      
b       
b         
b dir
b director
b.com
b/X
b/X11
b/X11/
b/l
b/li
b/p
b@sun
bX
bar.
bar.m
bar.mc.duke.edu
based on X
bc.ca      
bc.ca           
be accept
be accepted
be considered
be considered 
be dr
be me
bfe
bferrell@
bim
bin/
bins
bitmap fo
bitmap, 
bitmaps
ble and m
bleJ
bmp 
bmp f
bog
borne
bout X
brown@
bub
build.
builder
builder 
button 
button.
buttons
buttons 
bw
bwi
c(
c.be
c.duke.edu
c/win
cCol
cColor
ca.i
ca.in
ca.indiana
ca.indiana.edu
cai
cal C
callback
cap.
capital
capsul
cation c
cation ca
cation ha
cation is
cation is 
cation is s
cation th
cation that
cation that 
cation wh
cation'
cationC
cations i
cations in
cc 
cc -
cc-
ce System
ce are 
ce dis
ce file
ced mode
ceng.
cept s
cept that 
ce|
ce|| 
cf 
ch contains 
ch window
ch, a
changed.
char 
char *
character s
characters
characters 
characters.
ches for
child
child 
children 
chne
chy 
cial,
cic
cica
cica.
cica.indiana
cica.indiana.edu
cica.indiana.edu 
cim
cim.
cina
cing a 
ck L
ck your 
ck(
cker   
cker     
cker             
cker)
cker) writes:
clae
class.
click on
click on 
client
client 
client a
client, 
client.
clients
clients 
clients t
cmap
cmd
co.a
co@p
code 1
code it
code of 
code.  
colora
colorm
colormap
colormap 
colormap, 
colormap.
colormap. 
colormaps
com -
command line 
comp.lan
comp.os.
comp.os.ms
comp.os.ms-windows.
comp.sources.x
comp.windows.
comp.windows.x
comp.windows.x.
compilation
compile a
compile o
compiled with
compiled with 
compiles 
compiling
compiling 
compliant 
con,
con, 
configuration f
cons 
cons.
consol
console
console 
contains the
contains the 
contex
context
contrib 
contrib/X
contrib/x
contrib/xv
cpp
cr@
creen(
cript and
cript and 
cript c
cript files 
cript o
cript w
crollba
crollbar
croso
crosoft
cs.col
cs.com
cs.com 
cs.m
cs.mi
csh 
ct u
cters
ction(
ctions in 
ctions.  I
ctory.  I
cured 
cursor
customiza
d = 
d As
d B.
d C++
d Comm
d Do
d Go
d HP DeskJet 
d He
d MI
d Mic
d Micro
d Microsoft
d Microsoft 
d Mot
d Motif
d Motif 
d Motif 1.
d Op
d Ope
d Open
d Sm
d Wi
d Win
d Wind
d Windo
d Window
d Windows
d Windows 
d X
d X 
d X-
d X11
d X11R
d X11R5
d X11R5 
d Xm
d Xt
d and ba
d bitmap
d character
d cli
d colormap
d disclaimer
d event
d font 
d for Windows
d ico
d icon
d in X
d in the X
d lib
d librar
d libraries
d library
d long
d mapp
d not r
d not re
d os
d she
d size
d sym
d symbol
d system.
d the ser
d to do is
d using X
d widget
d win
d wind
d window
d window 
d windows
d with X
d!I
d-to-
d."  
d.de
d.de 
d.de (
d.di
dEven
dEvent
dMessage-ID: <1t
dPr
dWi
dWidget
dX
dar 
dating 
db@
db@s
db@sunb
dcod
dcode
dcr@m
dcr@mail.ast.cam.ac.uk
dcr@mail.ast.cam.ac.uk 
de W
de fi
de file
debug 
ded to a
def 
default c
default co
default f
defaults
defaults 
defaults file
defaults file 
defined i
defined in
defined s
delete t
den@
der Mo
der Mouse
der file
der files
dered  
dev.
dft
dget
dget 
dget a
dget fo
dget is
dget is 
dget s
dget t
dget to
dget)
dget,
dget, 
dget.
dget. 
dget.  
dgets
dgets 
dgets a
dgets an
dgets and 
dgets o
dgets t
dgets, 
dgets.
dgets. 
dgi
dialog
difier
digex.com 
ding X
ding pr
disclaimerz
distributed with
dit.
dler 
dlib
dll
dmap
dministrator
dministrator 
do I g
do ma
do make
doCo
doColor
doc 
doesn't a
doing wrong
done. 
dos w
dow 
dow M
dow Ma
dow a
dow an
dow and 
dow at
dow b
dow m
dow ma
dow t
dow th
dowing
dows 
dows a
dows an
dows and 
dows e
dows o
dows on
dows on 
dows, a
dpy
dpy,
dpy, 
drag
drag 
draw i
draw t
drawn in
draws
draws 
driver?
drv 
dshe
dson)
dson) writes:
e "x
e */
e .b
e And
e C++
e Contr
e DIS
e Dev
e Ev
e Eve
e Event
e HP 
e MI
e MIT
e MIT 
e MS 
e Makefile
e Man
e Manag
e Manage
e Manager
e Manager 
e Microsoft
e Microsoft 
e Mot
e Moti
e Motif
e Motif 
e Not
e Note
e O'
e O'Reilly 
e OS/
e Open
e OpenWin
e OpenWindows
e Prod
e R5
e R5 
e Scho
e School
e Sun
e Sun 
e TC
e Windows 
e Windows s
e X
e X 
e X Window
e X c
e X p
e X pr
e X pro
e X s
e X server 
e X-
e X11
e X11 
e X11R
e X11R5
e XView 
e Xlib
e Xlib 
e Xm
e Xs
e Xsun
e Xsun 
e Xt
e Xt 
e `
e a Sun
e a me
e a wi
e a win
e a window
e a window 
e added to 
e an X
e any f
e app 
e applie
e apps
e are co
e aware of
e before t
e before th
e build
e build 
e builder
e button
e button 
e buttons
e callback
e calling
e calling 
e character 
e clients 
e colormap
e colormap 
e command line
e considered
e considered 
e curs
e cursor
e cursor 
e default 
e dele
e delet
e delete
e dialog
e dialog 
e distribution.
e document 
e drawn
e error message
e event
e event 
e event ha
e events
e events 
e exact 
e example 
e exe
e exec
e expo
e file a
e file c
e files in 
e files,
e flag
e font
e font 
e font f
e fonts 
e for W
e for Windows
e for X
e foreground
e foreground 
e from w
e functionality 
e functionality o
e functionality of 
e functions
e functions 
e hint
e hints
e icon
e icon 
e in X
e is go
e it does
e it he
e it's n
e login
e long 
e manager
e manager 
e new f
e not se
e of X
e of the ma
e of the wi
e of the window
e of your 
e on e
e on ex
e or r
e parent
e patche
e pointer
e pointer 
e position 
e propert
e reason,
e request
e requirement
e requirements
e resou
e resource
e resources
e server t
e server to 
e server w
e server.
e server. 
e server.  
e shared
e shared 
e shel
e shell
e shell 
e state 
e string
e subscri
e terminal
e text 
e the X
e the cur
e the cursor
e the cursor 
e the k
e the key
e the na
e the name
e the sta
e the ti
e the vi
e the wi
e the win
e the window
e the window 
e title 
e to    
e to M
e to Microsoft
e to have t
e typi
e typical
e typically 
e versions
e widget
e widget 
e widgets
e widgets 
e win
e window
e window 
e window a
e window m
e window manage
e window manager
e window manager 
e window o
e window s
e window t
e window w
e window, 
e window.
e windows
e windows 
e with W
e with X
e workstation
e xd
e xdm
e xdm 
e xs
e xt
e xte
e xterm
e xterm 
e()
e() 
e);
e, "
e, X
e, k
e, that is 
e, un
e-|
e.X
e.cs.tu
e00
e86
e: (5
e: AT
e: Canon BJ200 (BubbleJet) and HP DeskJet 500...
e: Ch
e: Cha
e: Challenge to Microsoft supporters.
e: Challenge to Microsoft supporters.I
e: Challenge to Microsoft supporters.In 
e: Challenge to Microsoft supporters.In article 
e: Challenge to Microsoft supporters.In article <
e: Challenge to Microsoft supporters.In article <1
e: Wi
e: Win
e: Window
e: Windows 
e: X
e: X 
e: e
e: head-
e: o
e: re
e:X
e;	
e@expo.lcs.mit.
e@expo.lcs.mit.edu
e@o
eDe
eGC
eJe
eMan
eManage
eNo
ePro
eSender: news@
eSender: news@athena.mit.eduMessage-ID: <
eType
eType 
eWi
eWid
eWidget
eWin
eWindow
eWindow 
eWindow(
e_p
each a
each time
each w
ead wi
ead win
ead-to-
eaded
eaded 
ean E
ears in
ears in 
ears that 
eas th
eated a
eating a
ebooks
ebooks 
ebuffer
echo 
echo "
eckt
ecom 
ecompil
ectangle
ectangle 
ectively 
ecurity
ecute
ed To
ed Win
ed Window
ed X
ed X 
ed by X
ed by e
ed cha
ed char
ed character
ed in X
ed lib
ed librar
ed libraries
ed long
ed on X
ed symbol
ed this a
ed to do i
ed win
ed window
ed with X
ed!I
ed, wi
edW
edWi
edef
edir
edirect
edirect 
edit.
edraw
edu@
ee       
efault
efault c
efault co
efault f
efault v
efaults 
efil
efile
efile 
efile.
egro
egrou
eight,
eight, 
eilly
eilly 
ek C
ektron
ektroni
ektronix
el	
el = 
el Pa
el: +
ele.
ell (
ell I
ell I 
ell I a
ell is
ell is 
ell s
elp s
em in a
emacs
emap
embed
embr
emory r
emory re
emson
emulator
emulator 
en *
en Le
en Lee
en W
en Wi
en Win
en Windows
en Windows 
en X
en creat
en dr
en en
en in the 
en pres
en start
en the r
en to d
en window
en wr
en wrong
en x
en(
en.a
en;
enD
enDi
enDis
enL
enW
enWin
enWindow
enWindows
enWindows 
ena 
ena.
endif
endif 
eng.uc
enge
enge 
enhanced
enhanced 
enhanced mode
ense, th
ent X
ent and t
ent and th
ent h
ent ha
ent handl
ent va
ent vari
ent whi
ent which
ent window
ent(
ent, but
ent, w
ent;
ent_
enterp
entry in
ents will 
ents.  Th
enu a
env 
environment vari
environment variable
environment variable 
enwi
eophy
ept, 
er                              
er                               
er                                
er *
er Mo
er Sol
er Windows
er Windows 
er X 
er X11R
er a b
er exi
er fin
er find
er font
er to ac
er to acc
er to com
er versions o
er versions of
er windows 
er, N
er, but t
er@w
erWi
erX
erformance is 
erm 
erm a
erm and 
erm i
erm is
erm is 
erm o
erm s
erm t
erm w
erm wi
erm window
erm"
erm*
erm,
erm, 
erm.
erm. 
erm.  
ermes
erminals
ernet  
erpoo
errel
erribl
error:
error: 
ers int
ers into
ers.I
ersion 1.2
ersion 11
ersion of W
erstr
ert@
ertext
ertext 
erver and 
erver c
erver d
erver f
erver fo
erver for 
erver i
erver p
erver t
erver w
erver wh
erver.
erver. 
erver?
erver? 
es Corp
es X
es are m
es for i
es the X
es the problem
es the w
es the wi
es to i
es under X
es win
es,        
es,         
es.|z 
es??
es@t
esX
escap
escape
escape 
escape sequence
escape sequences
esigner 
esktop f
esktop fo
esktop for 
esolve
esource f
esource i
esource t
esource, 
esources 
esources a
esources,
esources, 
espac
espace
est driver
est drivers
ests. 
et "
et -
et 5
et 500
et X
et `
et call
et da
et hi
et set
et the e
et(
et()
et) and 
et, t
et, w
et, wh
etA
etC
etCl
etF
etFo
etI
etT
etV
etValue
etValues
etValues 
etW
etWi
etWin
etWindow
et_
et_a
eta test
etenv
etenv 
etrics
ets and
ets and 
ets?
evalu
event ha
event handl
event handler
event handler 
event i
event t
event th
ew wi
ewindow
examples
exclud
exec 
executables
executables 
execute
executing
exit 
exit(
expo
expo.lcs.mit.
expo.lcs.mit.edu
expo.lcs.mit.edu 
expor
export
export 
export.
export.lcs.mi
export.lcs.mit.edu
export.lcs.mit.edu 
export.lcs.mit.edu in
export.lcs.mit.edu in 
export.lcs.mit.edu:
expos
expose
exposure
ext -
ext c
ext i
ext in
ext r
ext re
ext s
ext)
extE
eyP
eyco
eyp
eysym
eyz
ezReferences: <19
ezReferences: <1993
f							
f ( 
f /
f 1.
f Appli
f Ci
f I use
f MS
f MS 
f Mo
f Widget
f Win
f Window
f Windows
f Windows 
f X
f X 
f a wi
f applica
f application
f application 
f applications
f bi
f cod
f code
f fonts
f such a 
f text
f text 
f the app
f the us
f the use
f the user
f the user 
f the wi
f the win
f the window
f the window 
f users
f using
f using 
f wi
f widget
f widgets
f widgets 
f win
f window
f window 
f windows
f windows 
f x
f your w
f" 
fW
fals
false
fde
feature o
feature of
feld
fense
ferencing 
file	
file (
file de
file e
file l
file manage
file manager
file n
file nam
file r
file re
file was
file, a
file, and
file, and 
file, t
filem
files u
fire
firma
first of
first off
flags
flags 
following code
following li
font 
font s
font t
font,
font, 
font.
font. 
fonts are
fonts are 
fonts in
fonts in 
fonts.
fonts?
for Wi
for Win
for Windows 
for Windows 3.
for Windows 3.1
for drawing
for drawing 
for the program
for wi
for win
for window
for windows
for windows 
foreg
foregr
foreground
foreground 
found w
from Microsoft
from Wi
from Win
from Windows
from X
from expo
from export
from export.
from export.lcs.mi
from export.lcs.mit.edu
ft b
ft bu
ft co
ft d
ft s
ft.c
ft@u
ftm
ftp.ci
ftp.cica
ftp.cica.indiana
ftp.cica.indiana.edu
ftp.cica.indiana.edu 
fts
fue
function c
function ca
function t
g '
g Ge
g St
g X
g X 
g You
g an X
g box
g box 
g command
g def
g file 
g font
g group
g in X
g the new 
g wid
g widget
g win
g wrong?
g x
g!d
g.h
g@cs
g@cs.
ga ca
gc,
gc, 
gcc
gcc 
ge data 
ge n
ge number
ge number 
ge number o
ge number of 
ge this
ge this 
ge to M
ger f
ger than the
ger,
ger, 
ger. 
ger.  
ger?
get ca
get co
get(
get)
get_
gets an
gets i
gets in
gets in 
gets, 
gets.
gets. 
gets?
gin s
gle o
gler
gner 
granted
ground a
ground and
ground and 
groups. 
grp
grp 
gs    
gwa
gwu
h ...
h = 
h Bu
h MS
h Motif
h Op
h Ope
h Win
h Window
h Windows
h Windows 
h Windows 3.
h X
h X 
h Xt
h cha
h chan
h chang
h the X
h the w
h the wi
h the win
h to ch
h win
h windo
h window
h windows
h x
h2
hE
hX
hale
halle
halleng
hallenge
hallenge 
hallenge to M
hallenge to Microsoft 
hanW
handler
handler 
hange thi
har.
hared
hared 
hared m
hared mem
hared memory
hared memory 
hat    
hat MS
hat O
hat W
hat Wi
hat Win
hat Windo
hat Window
hat X
hat ap
hat appear
hat direct
hat display
hat file
hat is it?
hat is m
hat not
hat the se
hat win
hat window
have several
he Athena
he Athena 
he C 
he File
he Fo
he HP
he HP 
he IC
he MI
he MIT
he MIT 
he Microsoft
he Microsoft 
he O'
he O'Reilly 
he Ope
he Open
he Sun
he Sun 
he Wind
he Window
he X
he X 
he X Re
he X Window
he X Window 
he X Window System
he X server 
he X-
he XV
he XView 
he Xlib
he Xlib 
he Xm
he Xs
he Xt
he Xt 
he applic
he application
he application 
he bin
he button
he button 
he cal
he call
he colormap
he control 
he cursor 
he default 
he exa
he example
he example 
he following l
he following li
he font
he functionality 
he functions
he latest driver
he man 
he man page
he man pages
he new i
he pat
he patch
he problem, 
he program t
he release
he release 
he select
he server i
he shar
he share
he shared 
he shell
he shell 
he title
he title 
he val
he value
he values 
he wi
he wid
he widget
he widget 
he win
he window
he window 
he window a
he window i
he window is
he window is 
he works
he workstation
he x
he xs
he xt
he xte
he xterm
he xterm 
heX
head wi
head-
height,
height, 
hell i
hell is
hell is 
hell.
help s
hen I m
hen I start
hen I'm 
hen X
hen se
hen x
hena
hermes
hese e
hierarch
hild
hild 
hildren
hing  
hints a
his comm
his mat
his value
his works
hna
hok 
homas@
hostname
hosts
hostscript
how is
i fi
i file
i files
i files 
i-b
ialo
ialog
ialog 
ian D
ian G
ian@
iase
iases
ib 
ib  
ib a
ib and 
ib d
ib f
ib i
ib s
ib,
ib/
ib/X
ib/X11
ib/l
ib/lib
ib/x
ibraries a
ibraries and
ibraries, 
ic X
ic coo
ic coordinates
ic coordinates 
ic@
ica.in
ical C
ical Co
ical Con
ication c
ication co
ication i
ication is
ication is 
ication is s
ication t
ication th
ication that
ication that 
ication to
ication to 
ication w
ication'
ication?
ications i
ications in
ice, b
ick L
ick on
ick on 
ickey
icon,
icon.
iconi
icons
icons 
icroso
icrosoft
icrosoft 
icrosoft s
icrosoft.
ics.c
ics.co
ics.com
ics.com 
id E
id X
ide-
idget
idget 
idget c
idget i
idget s
idget set
idget t
idget th
idget to
idget w
idget(
idget)
idget,
idget, 
idgetC
idgets
idgets 
idgets a
idgets an
idgets t
idgets, 
idgets.
idgets. 
idth,
idth, 
ied by the 
ied to c
ient s
ients
ients 
ies for t
ies for th
iew/X
iew/X 
iews,
iews, 
if (
if 1
if W
if Wi
if and
if and 
if app
if pr
if wi
if, 
if.
if. 
if?
ifd
ific c
ific co
ify a 
ight, but 
ii.
ike W
il.a
ild.
ile M
ile Ma
ile Manag
ile a 
ile e
ile manage
ile manager
ile n
ile, a
ile, t
iled for
iled for 
ilem
iles u
iles un
iles unde
iles under 
ility for u
ill mo
ill.edu
illustrat
imak
imba
ime.  For a f
imeout
in .
in /
in 3.
in 3.1
in 3.1 
in Motif
in W
in Wi
in Win
in Window
in Windows
in Windows 
in Windows 3.
in Windows 3.1
in X
in X 
in X11
in Xt
in Xterm
in a DOS
in a DOS 
in a pro
in an i
in and o
in contr
in my a
in text 
in the Win
in the Window
in the X
in the X 
in the app
in the file
in the following
in the man
in win
in window
in't
in't 
in't a
in.de (
in.in
in.ini
in.ini 
in/
in/s
in/sh
in3
in3.
in3.1
in3.1 
in@i
in@m
inL
inW
inX
inal w
inals 
inaries a
include f
include file
incredibly
indo
indow
indow 
indow (
indow a
indow an
indow and 
indow b
indow c
indow f
indow i
indow in
indow is
indow is 
indow m
indow ma
indow man
indow manage
indow manager
indow managers
indow managers 
indow o
indow on
indow p
indow s
indow t
indow th
indow that
indow that 
indow to
indow to 
indow w
indow wi
indow'
indow(
indow,
indow, 
indow.
indow. 
indow.  
indow.  T
indow?
indows 
indows (
indows -
indows .
indows 2
indows 2.
indows 2.0
indows 3
indows 3.
indows 3.0
indows 3.0 
indows 3.1
indows 3.1 
indows 3.1?
indows 4
indows ?
indows NT
indows NT 
indows a
indows an
indows and
indows and 
indows app
indows application
indows applications
indows applications 
indows apps
indows ar
indows are
indows are 
indows b
indows di
indows dir
indows directory
indows e
indows f
indows fo
indows for
indows h
indows ha
indows in
indows is
indows is 
indows l
indows m
indows n
indows o
indows on
indows on 
indows on a
indows on a 
indows on a PC
indows p
indows pr
indows pro
indows problem
indows program
indows r
indows re
indows s
indows se
indows so
indows st
indows t
indows th
indows to
indows to 
indows u
indows us
indows use
indows w
indows wi
indows will 
indows(
indows) 
indows, a
indows, and 
indows, but
indows, t
indows.  I
indows. I 
indows?
indows? 
indowsI
indowsIn 
indowsIn article 
ine(
ing '
ing Cur
ing Li
ing Lin
ing Mo
ing Mot
ing Motif
ing Motif 
ing Open
ing OpenWindows
ing St
ing Star
ing Start
ing Sun
ing SunOS 
ing SunOS 4.
ing X
ing X 
ing X11
ing X11R
ing X11R5
ing X11R5 
ing Xt
ing a per
ing a person 
ing a w
ing a wi
ing a window
ing a window 
ing a window manager
ing an X
ing anything 
ing command
ing def
ing error
ing for X
ing for X 
ing memory 
ing the X
ing the X 
ing the fo
ing the fol
ing the following
ing the mouse
ing the new
ing the new 
ing the wi
ing the win
ing the window
ing to comp
ing win
ing wind
ing window
ing windows
ing windows 
ing wrong?
ing x
ingX
ings   
ings    
ink.com
inked
inked 
insen
int  
int    
int      
int c
inter c
inter d
inter f
inter)
inting t
into w
intrinsic
intrinsics
intu
intuiti
inval
invalid
invalid 
invok
invoke
invoked
invoked 
ioc
ion 1.2
ion 11
ion file
ion is r
ion of W
ion of X
ion of the X
ion see
ion which i
ionCo
ional f
ions h
ions ha
ions have
ionth
ious co
ipt o
ired, 
is 	
is 2.
is X
is change
is install
is installed
is specifi
is va
is val
isplay(
ist b
isual 
isual,
isual, 
it is al
it may not
it may not 
it myself
it ret
it win
it window
it(
it, it 
it.eduM
it.u
it??
it???
ith MS
ith Mo
ith Motif
ith Su
ith Sun
ith W
ith X
ith the w
ith wi
ith win
ith windo
ith window
ith windows
ith x
ithout f
itle bar
itle fo
itmaps
itmaps 
itself, 
ix 4.
ix is 
ix'
ixm
ixma
ixmap
ixmap 
ixmap i
ixmaps
ixmaps 
iya
ize(
izeW
izeWi
izeWidget
j$
k =
k = 
k C.
k C. 
k over
k te
k the p
k |
k()
k.  This 
k.Un
k.com 
k.com  
k.comz
k.comz 
k@ta
kJe
karound 
kdb
kdb@
ke U
ke Uni
ke Universit
ke W
ke a m
ke the following
ke-
kent
ker     
ker             
ker                
ker)
ker) 
ker) writes:
keymap
keyp
keystrokes
king C
king me
kip 
kits 
km@
kmem
kton
ktr
l DOS
l DOS 
l J.
l Pa
l Pan
l Pane
l Panel
l Win
l Window
l X
l X 
l cli
l client
l clients
l clients 
l cri
l desktop
l emulat
l fun
l mou
l number of 
l tool
l version 
l widget
l win
l wind
l window
l window 
l windows
l windows 
l x
l | 
l);
l+
l." 
l."  
l.o
l: S
l: d
lR
lRe
lW
lWi
lWidget
lWidgetClass
lX
lXe
lXm
lacke
lags
lags 
lama
lamas
laris
laris 
lass.
lay b
lbar
lcs.mit.edu 
ld X
ld:
ld: 
lding the 
le Man
le Manag
le Manager
le X
le and m
le and ma
le bar
le call
le cl
le files
le font
le for X
le na
le nam
le name
le ref
le set 
le wid
le win
le window
le window 
le.	
le.  W
leS
leak
lease su
lect a
lect a 
led X
led int
led into 
led on 
lee@s
les u
les'
les??
less a
leu
lib 
lib f
lib i
lib/
lib/X
lib/X11
lib/X11/
lib/X11/x
lib/l
lib/lib
libX
libXm
libXmu
libXt
libs
lication an
lication i
lication is
lication is 
lication w
lication,
lication, 
lications i
lick o
lick on
lick on 
lick on th
lien
lient
lient 
lient.
lients
lients 
lients w
like the f
lin.c
ling X
ling X11R
lingt
lington
lington, 
link.c
link.co
linked
linked 
linking 
lizing 
lkits
lkits 
ll I a
ll X
ll appl
ll use th
ll win
ll wind
ll window
ll windows
ll windows 
ll.EDU
ll@d
llW
llWi
ll_
llack
llba
llback
llback,
llback, 
lled X
lling X
lloc
llocati
logo
logo 
look and 
loura
louray
louray@seas.gwu.edu
louray@seas.gwu.edu 
louray@seas.gwu.edu (Michael Panayiotakis) wr
louray@seas.gwu.edu (Michael Panayiotakis) writes:
lse)
lt   
lt X
lt c
ltrix 
lue of
lue of 
lue t
lue to 
lush
ly X
ly appl
ly ev
ly eve
ly requ
ly set
ly set 
ly should not 
ly when the
m                                  
m                                   
m                                    
m                                       
m  o
m  or 
m (I
m *
m ?
m Man
m Manager
m Manager 
m Plus 
m Win
m X
m att
m being 
m in a 
m manager
m manager 
m new to
m new to 
m sou
m ti
m to be able
m to be able to 
m to the
m under 
m using X
m window
m windows
m writing a
m' 
m.ac.uk 
m.g
m.ga
m.i
m/X
mN
macr
macro
macro 
macros
mage(
mail: d
mail: w
main(
makefile
makefile 
manager
manager 
manager a
manager i
manager is
manager t
manager to 
manager w
manager wi
manager,
manager, 
manager.
manager. 
manager.  
managers
managers 
mand line
mand line 
mand w
many X
map a
map an
map and
map and 
map c
map d
map f
map fo
map(
map,
map, 
map.
map. 
map;
maps a
maps,
maps, 
mark@t
mark@taylor
mark@taylor.
martdrv
mask 
mation wi
mba.
mbed
mbedd
mber in 
mbol
mbol 
mcco
mcr
mcrcim.mcgill.
mcrcim.mcgill.edu
me X
me buffer
me machine 
me win
me window
me.  F
me.  For 
ment va
metrics
microsoft
microsoft.
mines
mit/
mod 
moh
mohns@
mohns@vax
mohns@vax.clarku.edu
most use
motif
motif 
mouse b
mouse in
mouse s
mouse@
mp fo
mp for
mpc
mple i
mple in
mple program
mple w
mplements
mplements 
ms A
ms, I 
ms-win
ms-windows
ms-windows 
mu 
multiple w
multiple window
mund
mwm
mwm)
my ap
my app
my application
my application 
my mouse 
my program 
my wi
my win
n (p
n /
n /u
n /usr
n 3.1
n 3.1 
n 3/
n A.
n At
n Bu
n CO
n Des
n Desk
n Desktop
n Desktop 
n I st
n I start
n I'm 
n Lee
n Loo
n MS 
n Mot
n Motif
n Motif 
n NT 
n OL
n Op
n Ope
n Open
n OpenWindows
n OpenWindows 
n OpenWindows 3
n SPARC
n Sol
n Wi
n Win
n Windo
n Window
n Windows
n Windows 
n Windows 3.
n Windows 3.1
n X
n X 
n X a
n X s
n X server
n X server 
n X wi
n X window
n X-
n X1
n X11
n X11R
n X11R4
n X11R5
n X11R5 
n XView
n Xli
n Xlib
n Xlib 
n Xm
n Xs
n Xt
n Xt 
n Xterm
n Xterm?
n a DOS
n a DOS 
n a wi
n a win
n a window
n a window 
n an app
n an application
n bel
n belo
n below
n ci
n cli
n client
n color 
n do th
n enhanc
n enhance
n event
n expo
n export
n export.
n export.lcs.mit.edu
n export.lcs.mit.edu 
n expos
n expose
n files 
n font
n ftp site
n ftp.c
n ico
n icon
n improve
n is f
n is r
n is re
n log
n manag
n manage
n my .
n my a
n my application
n not fi
n of W
n page
n page 
n practice
n recei
n receiv
n receive
n resource
n response to 
n seems 
n select
n serve
n server
n server 
n shar
n share
n start
n tab
n table
n table 
n the R5
n the R5 
n the Win
n the Wind
n the X
n the X 
n the app
n the file
n the program 
n the rea
n the res
n the server
n the wi
n the win
n the window
n the window 
n the x
n under 
n wid
n widget
n win
n window
n window 
n windows 
n with X
n wro
n wrong
n x
n xt
n xterm
n xterm 
n you g
n you want
n you want 
n#
n't always
n't always 
n't find the 
n't speak for m
n()
n);
n, wi
n, with
n.X
n.de (
n.deIn
n.deIn article <
n.in
n.ini
n.ini 
n/X
n/c
n/s
n/sh
n3
n3.
n3.1
n3.1 
n3/
n31
n32
n@v
n@wi
nBr
nBri
nCon
nCont
nL
nLoo
nO
nOS
nOS 
nPr
nSh
nSoft
nW
nWa
nWi
nWin
nWindow
nWindows
nWindows 
nWindows 3
nWindows 3.
nX
n\
na T
na wid
na.m
naliz
name it
name t
naming 
nbar
nbi
ncapsulat
ncat
nce@
ncha
nchan
ncur
ncurre
ncurrent
nd Micro
nd SS
nd Wi
nd Win
nd Wind
nd Windo
nd Window
nd Windows
nd Windows 
nd X
nd X 
nd Xt
nd config
nd genera
nd pas
nd repl
nd repla
nd.D
nd/or t
ndar 
ndef
ndefin
ndefined
ndefined 
ndif
ndif 
nding to
nding to 
ndir
ndler
ndler 
ndow
ndow 
ndows 3
ndows 3.
ndows 3.1
ndows 3.1 
ndows 3.1 i
ne window
ne(
ne.cs.
necessarily s
netnews.
new wi
ng                        
ng Ge
ng Lin
ng St
ng X
ng for X
ng group
ng the new
ng the new 
ng!d
ng.g
ng@cs
ng@cs.
nga c
ngb
nge to 
nger h
ngle o
nhanced mode
ni and
ni and 
ni-do
ni. 
nico
nimation w
nimation with 
ning r
ning x
nitialize
nitialize(
nix:
nked
nked 
nning X
nning. 
nning.  
no sc
not   
not be co
not cr
not famil
not include 
not st
not_
nother t
notice a
ns are n
ns are no
ns in a
ns run
nse, th
nsic
nsole
nsole 
nsort
nt *
nt Win
nt a p
nt files
nt hand
nt lo
nt man
nt manage
nt ser
nt serv
nt server
nt size 
nt to run
nt vari
nt which
nt which 
nt window
nt window 
nt);
ntH
nt_
nter d
ntering 
nterpo
nterviews
ntex
ntext
ntrin
ntrinsic
ntrinsics
nts co
nts li
nts with 
nts.  I
ntui
ntuiti
nuts
nval
nvalid
nvalid 
nvok
nvoke
nvoked
nwin
nwindow
nwindows
nwindows 
ny A
nzi
o I fin
o I find 
o I get 
o Mi
o Micro
o Micros
o Motif
o Wi
o Win
o Window
o Windows
o Windows 
o X
o X 
o a w
o aw
o be pr
o compile
o copy
o expo
o expose
o expose 
o files
o happen
o live
o log
o make a m
o note
o note 
o onl
o only
o start a
o suppl
o the W
o the Win
o the X
o the file
o the se
o the serv
o the server
o the server 
o the w
o this i
o this is
o this is 
o this w
o type 
o use X
o win
o wind
o window
o windows
o windows 
o xt
o xterm
o, o
o-h
o-head
o.l
o: x
o;
o; 
oCol
oColor
obia
ocl
ocomm 
ode it
odev
odifier
odma
oell
oelle
of MS
of Window
of Windows
of Windows 
of X
of Xt
of cod
of code
of code 
of the Win
of the Window
of the X
of the X 
of the wi
of the win
of the window
of the window 
of wi
of win
of window
of windows
of(
offen
oft 
oft a
oft d
oft,
oft, 
oft.
oft.c
oft.com
og b
og.
ogma
ohns@
oing wrong
ointer 
oit.
ok A
okes 
ol   
ol    
ol     
ol B
ol P
ol Pane
ol to
ol-
ol/
olari
olaris
olaris 
olaris 2
olaris 2.
olaris 2.1
olor visual
olorm
olormap
olormap 
olormap(
olormap,
olormap, 
olormaps
olormaps 
olwm
olwm 
olwm and 
om  o
om -
om Microsoft
oman.
ome X
ome ba
ome win
ommand f
ommand line
ommand line 
ommand w
ompilation
ompilation 
ompiled with
ompiled with 
ompiling
ompiling 
ompiling X
on    |
on /
on Des
on Su
on Wi
on Win
on X
on X 
on X1
on X11
on a D
on a d
on ex
on exp
on manage
on men
on start
on the X
on the wi
on unnecessarily 
on wid
on win
on x
on your s
onSh
onW
onal f
oncu
onfirmation
ong!
onga
onix
ons co
ons h
ons ha
ons have
ons have 
ons@
onsol
onsole
onsole 
onsort
onsortium
onsortium 
ont f
ont i
ont s
ont t
ont w
ontains the 
ontex
ontext
ontext 
ontha
onthly
onts are
onts.
onts. 
on|
on|z
on|z 
ooch
ooking for X
ooking for X 
oolkits
oolkits 
oon as I 
oop.
oot w
oot wi
oot window
op u
op(
op()
op.
opaque
opc
opens
openwin
openwin/
option o
opup
opup 
opups
or /
or Motif
or Motif 
or Wi
or Win
or Windows 
or Windows 3.
or Windows 3.1
or Windows,
or Wo
or Wor
or X1
or X11
or X11R
or X11R5
or a fi
or a first 
or a wi
or a window
or addition
or ce
or dra
or draw
or drawing
or drawing 
or han
or hand
or handl
or in a
or rel
or serv
or server
or some re
or some reason
or the X
or the program
or updat
or vis
or visual
or win
or window
or xt
or xte
orWin
orX
ora.c
ora.com
orcing 
orcing a 
ord f
ord for
ord for 
ore Co
oregr
oreground
oreground 
orfo
ork S
ork:
orkgroup
orkgroups
orkgroups 
orkp
orkspace
orter
ortmund
ortmund.
or|  
os 6
os 6 
os.m
ose e
ose event
ose events
ositioning
ositioning 
osoft
osoft 
osoft.
osoft.c
osoft.com
ost   
ost us
ostas 
ostn
ostname
ostscript f
ostscript file
ot set
ot st
ot win
otak
otebooks
otebooks 
other X
other to
other win
other window
otif
otif 
otif 1.
otif 1.1
otif 1.1 
otif a
otif an
otif and
otif and 
otif app
otif application
otif t
otif w
otif wi
otif widget
otif widgets
otif,
otif, 
otif-
otif.
otif. 
otyp
ouble c
ould  
ould   
ould not be 
ound co
our   
our X
our app
our en
our ser
our use
our user
our wi
ource and
ource d
ource di
ource in
ource t
ource to 
ources a
ources an
ources i
ouse b
ouse c
ouse cursor
ouse in
ouse in 
ouse s
out X
overr
override
override 
oving i
ow Ma
ow Manag
ow ma
ow man
ow of th
ow po
ow sy
ow system
ow(
ow, s
owI
owM
ow_
owing whe
own is
own is 
ows (
ows -
ows 3
ows ap
ows app
ows application
ows ar
ows e
ows f
ows l
ows n
ows on
ows p
ows pr
ows pro
ows program
ows re
ows s
ows to
ows to 
ows(
ows) 
ows, a
ows?
ows? 
owsD
ow|
p W
p X
p an 
p does
p file 
p file re
p font
p fonts
p format
p so 
p st
p ti
p window
p(
p()
p() 
p+
p-d
p-de
p.ci
p.l
p.m
p.mi
p.o
p.t
p.w
p.win
p.windows
pA
pC
pCo
pMa
pS
pW
pWi
pX
pad 
page f
page.
parent wi
pars
parse
patch f
patch.
patche
patches 
pbu
pcc
pe it he
pe se
pe sequence
pe sequences
pe-
pe-|| ||  MICHAEL PANAYIOTAKIS: louray@seas.gwu.edu ace|| ||                                   ...!uunet!seas.gwu.edu!louray|||| \/|  
pe-|| ||  MICHAEL PANAYIOTAKIS: louray@seas.gwu.edu ace|| ||                                   ...!uunet!seas.gwu.edu!louray|||| \/|  *how do make a ms-windows .grp file reflect a HD directory??*\\\\   |  "well I ain't always right, but I've never been wrong.."(gd)
pecifies
pecifies 
pecify a
pecify a 
ped!
penwi
penwin
penwindow
penwindows
penwindows 
pert@
phone: +
phone: +4
pile o
piled i
piles
piles 
pital 
pixmap
pixmap 
pixmaps
pj
play b
ple X
ple ab
ple window
ple windows
plication a
plication an
plication and 
plication t
plication th
plication w
po.
pointer 
positioning
posting o
pp 
pp-
pplication 
pplication i
pplication is
pplications i
pplications u
pps 
pps a
pps and
pps,
pps, 
preadshe
preadsheet
printer d
printer driver
printer driver 
printf
prism
program e
program ma
program manager
properties
provided t
provided th
ps	
ps r
ps up
ps up 
pt sp
pub/X
pub/pc/
pub/pc/win3
pub/pc/win3/
pup
pups
py)
qvi
r                           
r                            
r                             
r                              
r                               
r                                
r                                   
r (b
r *
r **
r / 
r MS 
r MS W
r MS-W
r Mot
r Motif
r Motif 
r Sol
r Solaris
r Solaris 
r Sun
r SunOS
r Ta
r W4W
r Wi
r Win
r Windo
r Window
r Windows
r Windows 
r Windows 3.
r Windows 3.1
r Windows 3.1 
r Windows s
r Windows?
r Work
r X 
r X a
r X s
r X windows
r X.
r X1
r X11
r X11R
r X11R5
r X11R5 
r XT
r XTerm
r Xt
r a wi
r a window
r any of
r applications 
r command
r dra
r draw
r drawing
r drawing 
r environment
r find 
r font
r ic
r icon
r in X
r in Xt
r messages 
r mou
r mouse
r mouse 
r open
r options
r pixmap
r rele
r releas
r release
r release 
r resource
r server
r server 
r the X
r the X 
r the wi
r the win
r the window
r to com
r updat
r user 
r versions of
r widget
r win
r window
r window 
r window m
r window man
r windows
r windows 
r xt
r xte
r xterm
r()
r) s
r);
r.UUCP
r.l
r.mc
r.t
r/b
r/l
r/o
r30.1
r: C
r: news@
r@mail
rWi
rWin
rWindow
rWindows
rX
r_
ra.com
rag a
ragg
ram b
ram ma
ram?
ranslations
ranted
ranted 
rarchy
rary (
raw i
rawa
rawable
rawingArea
rce d
rce di
rce t
rce to
rce to 
rces. 
rd              
rd               
rd Go
rdb 
re X
re not s
re that you
re them
re: C
reated a
reating a
reating a 
rectory?
red l
red li
red me
redir
redirect
redr
redraw
redraw 
redraws
redraws 
ree86
registration 
regr
regre
rek 
rell
remotely
rent se
rent wi
rent,
rent, 
reserve 
resiz
resize
resize 
resized
resource 
resource i
resources 
resources a
resources,
resources, 
rett 
rgc
rgs
rgs,
rguments
rian D
rian@
ride 
ries are 
ries th
right (
right, but 
rime.
ring(
ript files 
ris 2
risc
rism.
river?
rizona
rizona.
rk:
rk: 
rku.
rlog
rm -
rm is
rm on
rm on 
rm w
rm wi
rm"
rm?
rmI
rmap
rmap 
rmaps
rmaps 
rmohns@
rmohns@vax
rns a
ro w
rocomm 
rog 
rogram M
rogram m
rogram ma
rogram manager
rogram manager 
rograms   
rom the N
rom the No
roman
rong..
root 
root wi
root window
root window 
roperties
roperties 
rosoft 
round and 
round c
rovided t
rovided th
rp f
rr@
rrell
rror code 
rror w
rror:
rror: 
rs.In
rses 
rsm
rsome 
rst offen
rt Bo
rt@
rters
rters.
rtext
rtext 
run Windows 
run X
run under 
running M
running Sun
running SunOS 
running X
running an
running on the
running u
runtime
rv 
ry                
ry                    
ry                      
ry                       
ry                         
ry                             
ry                                  
ry is a
ry to run
ry to run 
ry using
ry(
ry??
r|  
s 		
s    | 
s   |
s */
s 12
s 2.
s 3.
s 3.0
s 3.0 
s 3.1
s 3.1 
s 3.1 i
s 6 
s = 
s AP
s Lab
s Ltd
s Ltd.
s Mal
s Malamas
s Mot
s Motif
s Motif 
s NT
s NT 
s Op
s Ope
s Open
s Programm
s Programmer
s Programmer 
s Sh
s X
s X 
s X11
s X11R
s Xt
s a col
s a win
s a window
s an exp
s and Co
s and Com
s application
s application 
s applications
s applications 
s apps
s apps 
s are N
s child
s comma
s command
s compil
s compile
s compiled
s compiled 
s conte
s escap
s execut
s font
s fonts
s for W
s for Win
s for a w
s for a wi
s for wi
s for window
s for windows
s for windows 
s generate
s generated
s generated 
s how the
s how the 
s ic
s icon
s in X
s in your
s in your 
s initia
s initial
s like it
s local
s not at
s obviously 
s of		
s of			
s of X
s on ex
s patch
s pop
s press
s problem w
s relative
s resource
s right,
s right, 
s right, but 
s server
s server 
s somehow
s somewh
s specifie
s specified
s the W
s the X
s the X 
s the app
s the na
s the name
s the server
s the wi
s the win
s the window
s the window 
s to X
s to be t
s to be th
s to be the
s to be the 
s under X
s up the 
s up.  
s val
s welcome
s win
s window
s window 
s with W
s with X
s with w
s works 
s x
s#
s()
s, I can
s, however,
s, use
s, we 
s-w
s-wi
s.	The
s. How
s. However
s. However, 
s.In
s.In 
s.In a
s.In article 
s.In article <
s.colo
s.color
s.com)
s.comIn
s.hz
s.mi
s.mit
s.mit.
s.mit.edu
s.mit.eduI
s.mit.eduI 
s.mit.eduz
s.mit.eduzNNTP-Posting-Host: 
s.ms-
s.ms-windows
s.nl 
s.unc.edu (
s.x
s.x 
s.x,
s.x.
s/2
s/x
s:	 
s@a
s@at
s@uc
s@v
s@va
s@vax
s@vax.
sSender: n
sSender: news@
sSender: news@athena.mit.eduMessage-ID: <
sSender: news@athena.mit.eduMessage-ID: <930
s[
s\
samb
same machine
same machine 
scap
scape
screen to
screen to 
script a
script f
script file
script files
script files 
se		
se '
se O
se Wi
se Win
se and a
se but
se button
se cha
se cu
se cur
se ev
se eve
se even
se event
se event 
se events
se font
se mu
se only
se so 
se the "
se the w
se wid
se widget
se x
se xterm
se, that
se, that 
se, that i
se, you
securi
security
sed T
sed X
sed on X
sed to i
sed to th
select a
seman
senb
ser f
ser m
server 
server (
server and 
server c
server f
server fo
server for 
server i
server in
server o
server on
server on 
server re
server t
server w
server wi
server with
server.
server. 
server.  
server.  I
server/
server?
ses X
sessions
set in
set in 
set in the
sete
setenv
setenv 
seudoColor
se|z 
sh b
sh(
shared
shared 
shared m
shared mem
shared memory
shell 
shell i
shell is
shell,
shell, 
shell.
should not be 
should not be c
show the
show the 
simple w
sing Win
sing Windows
sing Windows 
sing X
sing wi
sion 11
sion in 
sion of W
skand
sl.c
soft 
soft s
soft t
soft.
soft.c
soft.com
soft.com 
sole 
son u
sor in
sorti
source a
source an
source and
source d
source file
source i
source in
source s
source t
source to
source to 
sources a
sources an
sources ar
sources are
sources are 
sources i
sources in
sources in 
sources. 
specific c
specific co
specified by
specifies
specifies 
spreadshe
spreadsheet
srun
srunning 
ssion in
ssion in 
ssion w
st X
st appl
st lin
st line
stas 
stna
stname
str.
strc
string
strings
strings 
struct 
stty
sual c
sual,
sual, 
sual.
sual. 
sually w
sun3
sure that you
swap f
swap file
swap file 
sy wa
symbol
symbol 
syno
synop
system.ini
t    t
t    th
t !
t */
t +
t + 
t -l
t /
t 500
t Acc
t Access
t Corporation 
t Fe
t I l
t I li
t I'd like to
t I'd like to 
t I've n
t I've never 
t MS 
t Microsoft
t Motif
t Motif 
t NT
t OS/2
t OS/2 
t Ob
t Su
t Sw
t True
t X
t X 
t X11
t X11R
t Xt
t `
t a H
t a prog
t a program 
t always r
t an X
t and pa
t appear 
t appears that 
t application 
t be con
t be cons
t change th
t code
t code 
t colormap
t compi
t compil
t compile
t doesn't s
t editor
t editor 
t entr
t entry
t everyone
t fam
t famil
t font
t font 
t for W
t for Win
t for Windows
t for Windows 
t for d
t handler
t handler 
t implement
t in X
t is available 
t is ge
t knowing
t lets 
t lib
t load
t load 
t modif
t multiple 
t myself
t of X
t of the X
t of wi
t open 
t path
t receive 
t resou
t resour
t resource
t resources
t select
t server
t specifi
t specific
t specific 
t supporte
t that d
t the X
t the cha
t the cl
t the cli
t the client
t the server
t the server 
t the source
t the user
t the user 
t the wi
t the win
t the window
t the window 
t this in
t to X
t tre
t value 
t variable
t variable 
t variables
t variables 
t widget
t widget 
t win
t window
t window 
t windows
t windows 
t work for 
t!s
t" a
t". 
t's ver
t's very 
t("
t()
t() 
t) m
t);
t, X
t, but I've 
t,i
t-ba
t-based
t.F
t.cam
t.cam.
t.l
t.ps
t.so
t: e
t: ro
t: su
t: x
t;   
t???
t@e
t@ex
t@expo
t@expo.lcs.mit.
t@expo.lcs.mit.edu
t@uu
t@uunet.uu.net
tA
tAd
tApp
tAr
tCa
tClass,
tColor
tCon
tCr
tCreate
tDe
tDisp
tDisplay
tE
tEvent
tFo
tFor
tGe
tH
tHa
tIm
tImage
tImage(
tImage()
tPoint
tRe
tReal
tRes
tRo
tRoot
tScreen
tSe
tSet
tStr
tU
tV
tVa
tVi
tW
tWi
tWidget
tWin
tWindow
tWindow(
tX
t_a
t_w
table to
takis
tart the 
tartup logo
taylor
tches t
tdown 
tdrv
te X
te.d
teC
teCo
teM
teMa
teMan
teW
te_
ted X
tenv
tenv 
tepa
ter@p
term 
term -
term a
term f
term i
term is
term o
term s
term t
term w
term wi
term window
term"
term.
term. 
term.  
term?
terminal
terminal 
terminal emulat
terminal emulator
terminal.
terminals
terminals 
ters) 
ters.I
tes for a
tes for a 
tester
text i
text s
text.
th Motif
th Su
th Win
th Windows
th Windows 
th X
th X 
th X11
th X11R
th X11R5
th ch
th cha
th chan
th in the 
th lib
th the w
th x
that not
that the se
that the w
that win
the C 
the HP
the HP 
the MI
the MIT
the MIT 
the MS 
the Makefile
the Microsoft
the Microsoft 
the Motif
the Motif 
the Not
the R5
the R5 
the Sun
the Sun 
the Wind
the Window
the X
the X 
the X p
the X pr
the X11
the X11 
the X11R
the XV
the XView 
the Xlib
the Xlib 
the Xt
the appl
the applic
the application
the application 
the backgrou
the background
the cal
the client
the fact that the
the following l
the header
the icon
the icon 
the job 
the keys
the man page
the name of th
the name of the 
the output o
the release
the requ
the resource
the resource 
the root
the root 
the server
the server i
the server t
the stri
the string
the terminal
the val
the value
the values 
the wi
the widget
the widget 
the win
the window
the window 
the window i
the window manager
the window manager 
the x
thena
thena 
thena widget
thena widgets
thena.
ther X
ther win
ther window
these e
thing  
thom
thomas
thomas@
tialize
tics.com
tif 
tif i
tif t
tif,
tif, 
tility for 
ting System
ting W
ting Win
ting X
ting of t
ting of the
ting us
ting win
ting window
tion file
tion of X
tion of the X
tion ta
tion table
tion with X
tionCo
tionS
tions ha
tions.  If
tions.  If 
tionth
tion|
tlas
tle ba
tle fo
tle for
tle for 
tmu
tnam
tname
to M
to Mi
to Micro
to Mo
to Motif
to Wi
to Win
to Window
to Windows
to Windows 
to X
to a file
to a h
to a w
to a wi
to come up 
to compile
to compile 
to see it
to start a
to the X
to the next
to the se
to the serv
to the server
to the server 
to the w
to the wi
to the window
to wi
to win
to window
to windows
toX
toolkits
toolkits 
top f
top fo
top for 
topl
torial 
tory.  I
tr 
translations
trc
tree 
trics
tring
tring(
tring.
trings
trings 
tronix
truct 
try in
try in 
try se
try to run
try.c
ts (e
ts fil
ts file
ts file 
ts files
ts un
tsN
tsS
tsX
ts_
tton 
tton.
ttribute 
tual de
tup f
tup l
ture th
ture"
turns a
tutorials
tvie
tvt
tvtwm
tvtwm 
twm
twm 
twm,
twm, 
twm.
typically
typically 
u "
u.edu (M
u.edu a
u.edu!
uMessage-ID: <
ual (
ual mo
ual pa
uary 
ubble
ubw
ucbvax
ucen
udici
ue   
ue    
ue       
ueT
ueType
ueType 
ugly 
uicke
uild.
uin 
ulder
ult f
ult fo
ulti-screen
ultiple w
ultiple window
ults f
ummi
ummin
un 3/
un O
un Windows 
un X
un se
un under 
un1
un3
unO
unOS
unOS 
unOS 4
unOS 4.
unOS 4.1
unOS 4.1.
unOS 4.1.2
unbi
unca
unctions t
und.d
undef
undefined
undefined 
underl
underlying
uni-d
unnecessar
unning X
unning x
unsig
unsigned
unsigned 
unz
unzip
up an 
up lo
up me
up so 
up window
upS
updating 
upporter
upporters
ups. 
ur app
ur application 
ur@
uray
ure/
urns a
urrent se
urses 
urso
ursor
ursor 
ursor i
ursor in
ursor in 
use	
use M
use X
use bu
use but
use cu
use cursor
use se
use the mouse
use x
use@
used to i
user.
uses X
ush(
using Win
using Windows
using Windows 
using X
usr
ustrate
ut W
ut X
ute s
util.
utorial 
utput,
utput, 
utton 
utton w
uttons
uttons 
uudecode
uudecode 
uunet!s
uwm
uwm.edu
uz.
v 1.
value t
value to 
variables 
vax!u
vax.clarku.edu
vax.clarku.edu 
ve X
ve app
ve it a 
ve never been 
ve several
ve several 
ve the cur
veW
veWi
vent ha
vent handl
vent i
vent is
vent is 
vent t
vent)
vent, 
vent.
venue 
ver as
ver at
ver fi
ver is a
ver us
ver?
verr
verrid
verride
via X
view/
view/X
view/X 
views,
views, 
ving an 
virtual d
visual,
visual, 
visual.
vity i
vok
voke
vtwm
vwm
w *
w System
w System 
w X
w id
w man
w prog
w wid
w widget
w win
w window
w(
w.com
w3
wIn
wL
wM
wP
w_
wable
wable 
wallpaper
way to f
wd 
well I 
whal
whale
which com
which contains 
widget
widget 
widget is 
widget s
widget t
widget w
widget)
widget, 
widget.
widget. 
widgets
widgets 
widgets i
widgets in
widgets.
width,
width, 
will mo
win 
win a
win an
win and
win and 
win,
win/
win3
wind
windo
window
window 
window a
window an
window and 
window i
window in
window is
window is 
window m
window ma
window man
window manage
window manager
window manager 
window manager t
window manager to 
window manager.
window manager. 
window manager.  
window o
window of 
window on
window p
window s
window system
window t
window th
window that
window that 
window to
window to 
window w
window wh
window wi
window with
window with 
window,
window, 
window, a
window-
window.
window. 
window.  
windowi
windowing 
windowing s
windows
windows 
windows (
windows 3
windows 3.
windows a
windows an
windows and
windows and 
windows app
windows b
windows f
windows in
windows in 
windows o
windows on
windows on 
windows on a
windows p
windows pr
windows pro
windows s
windows t
windows v
windows w
windows)
windows,
windows, 
windows.
windows.  
windows?
wing code
wins
with MS
with Su
with Sun
with W
with Win
with Windows
with Windows 
with X
with X 
with X11
with X11R
with X11R5
with the X
with the w
with win
with windo
with window
with windows
wm
wm 
wm a
wm and 
wm t
wm)
wm,
wm, 
wm.
wm. 
wmS
wman
wmr
wmrc
wn@
wrappe
ws	
ws & 
ws (
ws -
ws 3
ws 3.
ws 3.0
ws 3.1
ws 3.1?
ws N
ws ap
ws app
ws application
ws ca
ws di
ws is
ws n
ws on a
ws on a 
ws pr
ws pro
ws se
ws ser
ws serv
ws st
ws to
ws to 
ws wa
ws wi
ws will 
ws(
ws) 
ws, a
ws, and 
ws, but
ws, but 
ws.  I 
ws.m
ws?
ws? 
ws@
wsD
wu.edu 
wu.edu (
wz
w|
x D
x Da
x O
x X
x.s
xcept that
xcept that 
xcl
xd
xdm
xec 
xecute
xecute 
xecuting
xecuting 
xho
xhost
xinit
xit 
xm
xma
xmo
xmod
xmodmap
xn
xon
xpert
xpert@
xpert@expo
xpert@expo.lcs.mit.
xpert@expo.lcs.mit.edu
xpo
xport.
xport.lcs.mi
xport.lcs.mit.edu
xpos
xpose
xpose 
xpose event
xpose event 
xpose events
xr
xrdb
xrdb 
xre
xse
xset
xst
xt -
xt c
xt i
xt is 
xt)
xt.  
xterm
xterm 
xterm -
xterm i
xterm'
xterm,
xterm, 
xterm.
xterms
xwd
xwd 
xwi
xwin
y .X
y MI
y Mar
y OS
y Ri
y Soft
y Software
y Windows
y X
y X 
y appl
y appli
y applica
y application
y application 
y buil
y build
y cli
y creat
y does th
y doesn't
y ent
y event
y if I
y if I 
y is m
y is my 
y mou
y mouse
y mouse 
y prov
y red
y resource
y screen
y server
y should not 
y the X
y the u
y the use
y the user
y to ma
y to make 
y tool
y widget
y widgets
y win
y wind
y window
y window 
y x
y xterm
y()
y);
y,      
y,       
y,        
y, X
y, my
y, wi
y.p
y.s
y12
y14
y14.
y:	
y@k
yAr
yF
yPl
yPlane
yPlane 
yPr
yW
yWi
yWid
ya.
ym 
ymap
ymb
ymbol
ymbol 
ymon
yntax 
you are running
your D
your mou
your program
your ser
your serv
your server 
your u
your us
your user
ype fo
ype font
ype fonts
ype-
ystem: 
z "
z .
z <1993Ma
z <1993May
z <1993May1
z <s
z Any 
z Mo
z X
z!
z#
z#include
z$
z%
z&
z'
z',
z'A
z'AX
z'AX?
z'AXz'AXz'AXz'AXz'AS
z'AXz'AXz'AXz'AXz'AS'$
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'M
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MA
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'M
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MA
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'A
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AX
z'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'MAXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz'AXz
z'AXz'AXz'MAXz'AXz'AXz'AXz
z'M
z'MA
z*
z+
z0
z3
z5
z6
z7
z7@
z7@,
z7@,#
z7E
z7EY
z7EYz7
z7EYz7E
z7EYz7EYz
z7K
z7KN[
z9
z;
z<
zBH
zBHJN
zBJ
zBJ[
zBJ[7
zE
zEI
zGH
zGHJ
zGHJ*
zGHJ*B
zGI
zGIZ
zGIZ*
zGIZ*B
zGIZM
zGIZz
zGIZzGIZzG
zGK
zGK?W]
zGK?W]_?
zJ
zK
zM7
zMN
zM]
zM_
zM_?W]
zNNTP-Posting-Host: e
zNNTP-Posting-Host: en
zNNTP-Posting-Host: enterpoop.mit.edu
zNNTP-Posting-Host: enterpoop.mit.eduTo: 
zNNTP-Posting-Host: enterpoop.mit.eduTo: x
zNNTP-Posting-Host: enterpoop.mit.eduTo: xpert
zNNTP-Posting-Host: enterpoop.mit.eduTo: xpert@expo.lcs.mit.edu
zNR
zNRHJ
zN[
zQ
zReferences: <93
zTo
zTo: 
zTo: x
zTo: xpert@expo.lcs.mit.edu
zU
zU3
zV
zV+
zWM
zWM[
zWM[z
zWM[zW
zWM[zWM
zY
zZ
z[
z\
z]
z^
z_
z`
z`P
z`P,
z`P,#
zona.
zv
{	
{       
{        
{uu
{uunet
|  "w
|  *
|  MI
| "Th
| "The
| Di
| E-mail
| E-mail: 
| La
| Mar
| Mark 
| No
| Sys
| \/
| ||
| || 
| ||  
| ||                                   
|z X
|| |
|| ||
|| ||  
}	
};
~/
~~~~~~~~~~~~~  
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  
