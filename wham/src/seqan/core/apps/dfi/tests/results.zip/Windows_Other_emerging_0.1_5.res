 3.1
 Windows 
 X
 X 
 X1
 win
 wind
 windo
 window
 window 
 windows
 windows 
: X
Win
Wind
Windo
Window
Windows 
X1
X11
dow 
dows 
e X
he X
indo
indow
indow 
indows 
n X
ndow
ndow 
ndows 3
ows 3
s 3.
the X
wind
windo
window
window 
windows
windows 
ws 3
