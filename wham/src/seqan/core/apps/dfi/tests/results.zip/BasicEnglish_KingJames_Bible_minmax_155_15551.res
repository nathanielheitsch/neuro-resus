 (
 A
 Aaron
 Aaron 
 Ab
 Abi
 Abr
 Abra
 Abraham
 Ah
 Aha
 Am
 Amm
 An
 And
 And 
 And h
 And he
 And he 
 And t
 And th
 And the
 Ar
 Ara
 As
 B
 Ba
 Bab
 Babylon
 Be
 Ben
 Benjami
 Benjamin
 Bet
 Beth
 Bu
 C
 Ca
 Can
 Cana
 Canaan
 Ch
 Christ
 Christ 
 Co
 D
 Da
 David
 David 
 David,
 David, 
 E
 Eg
 Egypt
 Egypt 
 Egypt,
 Egypt, 
 El
 Eli
 Ep
 Eph
 Ephr
 Ephra
 Ephrai
 Ephraim
 F
 Fa
 Fat
 Father
 G
 Ga
 Ge
 Gi
 Give
 Give 
 Go
 Go 
 God
 God 
 God a
 God h
 God ha
 God has
 God i
 God is
 God is 
 God o
 God of
 God of 
 God of Is
 God of Israel
 God w
 God,
 God, 
 God, a
 God, an
 God, and 
 God.
 God;
 God; 
 H
 Ha
 He
 Hi
 Ho
 I
 I 
 I a
 I am
 I am 
 I am t
 I am th
 I am the
 I am the 
 I g
 I h
 I ha
 I have
 I have 
 I have g
 I m
 I ma
 I may
 I may 
 I s
 I sa
 I said
 I saw
 I saw 
 I say
 I say 
 I say t
 I say to 
 I t
 I to
 I w
 I wa
 I was
 I was 
 I wi
 I will
 I will 
 I will b
 I will be
 I will g
 I will give
 I will give 
 I will m
 I will ma
 I will make
 I will make 
 I will n
 I will no
 I will s
 I will se
 I will send
 I will send 
 If
 If 
 Is
 Isa
 Israel
 Israel 
 Israel w
 Israel,
 Israel, 
 Israel, a
 Israel.
 It
 It 
 J
 Ja
 Jac
 Jacob
 Jacob 
 Je
 Jeh
 Jeho
 Jer
 Jeru
 Jerus
 Jerusalem
 Jerusalem 
 Jerusalem,
 Jerusalem, 
 Jes
 Jesu
 Jesus
 Jesus 
 Jesus,
 Jew
 Jews
 Jews 
 Jo
 Joa
 Joh
 Jor
 Jordan
 Jos
 Jose
 Joseph
 Josh
 Joshua
 Ju
 Jud
 Juda
 Judah
 Judah 
 Judah,
 Judah, 
 K
 Ki
 Kin
 King
 King 
 L
 La
 Le
 Let
 Let 
 Levi
 Levit
 Levite
 Levites
 Lo
 Lor
 Lord
 Lord 
 Lord a
 Lord c
 Lord h
 Lord ha
 Lord i
 Lord is
 Lord is 
 Lord o
 Lord of 
 Lord of a
 Lord s
 Lord t
 Lord w
 Lord wi
 Lord will
 Lord will 
 Lord,
 Lord, 
 Lord, a
 Lord, an
 Lord, and 
 Lord, t
 Lord, th
 Lord, the
 Lord, the 
 Lord, w
 Lord.
 Lord:
 Lord: 
 Lord;
 Lord; 
 M
 Ma
 Man
 Me
 Mi
 Mo
 Moa
 Moab
 Mos
 Mose
 Moses
 Moses 
 Moses,
 Moses, 
 N
 Na
 Ne
 No
 O
 O 
 O L
 O Lord
 O Lord, 
 P
 Pa
 Pe
 Ph
 Pha
 Phar
 Pharaoh
 Phi
 Phil
 Phili
 Philisti
 Philistine
 Philistines
 R
 Ra
 Re
 S
 Sa
 Sam
 Saul
 Saul 
 Se
 See
 See, 
 Sh
 She
 Si
 So
 So 
 Solomon
 Solomon 
 Son
 Son 
 Son of 
 Sp
 Spirit
 T
 Ta
 Te
 Tem
 Th
 The
 The 
 Thi
 This
 This 
 This i
 This is 
 U
 W
 Wh
 What
 What 
 Why
 Why 
 Y
 Yo
 You
 Z
 Ze
 Zi
 Zio
 Zion
 a 
 a b
 a c
 a ca
 a d
 a de
 a f
 a g
 a gr
 a gre
 a great
 a great 
 a h
 a ho
 a hu
 a hundred
 a hundred 
 a l
 a li
 a lo
 a m
 a ma
 a man
 a man 
 a me
 a n
 a p
 a pr
 a r
 a re
 a s
 a se
 a si
 a so
 a st
 a str
 a t
 a th
 a v
 a w
 a wa
 a wi
 a wo
 ab
 able
 able 
 able t
 able to
 able to 
 abo
 abou
 about
 about 
 about t
 about th
 about the
 ac
 acc
 acco
 account
 account 
 act
 acts
 af
 after
 after 
 after h
 after t
 after th
 after the
 after the 
 ag
 aga
 again
 again 
 against
 against 
 against h
 against hi
 against him
 against m
 against me
 against t
 against th
 against the
 against the 
 against you
 agr
 agree
 agreement
 agreement 
 agreement w
 al
 all
 all 
 all I
 all h
 all hi
 all his
 all his 
 all m
 all o
 all t
 all th
 all the
 all the 
 all the p
 all the pe
 all the people
 all the people 
 all the t
 all the w
 all thi
 all tho
 all those
 all those 
 all w
 all y
 all you
 all your 
 alt
 altar
 altar 
 am
 am 
 am t
 am th
 am the
 am the 
 am the L
 am the Lord
 amo
 among
 among 
 among t
 among th
 among the
 among the 
 among you
 an 
 an a
 an e
 an en
 an end
 an end 
 an end t
 an end to
 an end to 
 an o
 an oa
 an oath
 an off
 an offe
 an offer
 an offering
 an offering 
 and A
 and B
 and E
 and I
 and I 
 and I w
 and I wi
 and I will 
 and J
 and Je
 and M
 and S
 and a
 and a 
 and al
 and all
 and all 
 and all t
 and all th
 and all the
 and all the 
 and b
 and be
 and be 
 and c
 and ca
 and came
 and co
 and d
 and do
 and do 
 and e
 and ev
 and eve
 and ever
 and every
 and f
 and fo
 and for
 and for 
 and fr
 and fro
 and from 
 and g
 and ga
 and gave
 and gave 
 and gi
 and giv
 and give
 and give 
 and go
 and h
 and ha
 and had 
 and hav
 and have 
 and he
 and he 
 and he w
 and he wi
 and he will 
 and hi
 and his
 and his 
 and his s
 and ho
 and i
 and in
 and in 
 and in t
 and in th
 and in the
 and in the 
 and it
 and it 
 and k
 and l
 and le
 and let
 and let 
 and m
 and ma
 and mad
 and made
 and made 
 and mak
 and make
 and make 
 and my
 and my 
 and n
 and no
 and not
 and not 
 and o
 and of
 and of 
 and on
 and on 
 and on t
 and on th
 and p
 and pu
 and put
 and put 
 and put i
 and put t
 and put th
 and put the
 and r
 and s
 and sa
 and sai
 and said
 and said 
 and said t
 and said to 
 and said,
 and said, 
 and say
 and se
 and sh
 and she
 and so
 and st
 and t
 and ta
 and tak
 and take
 and take 
 and th
 and tha
 and that
 and that 
 and the
 and the 
 and the L
 and the b
 and the c
 and the ch
 and the f
 and the h
 and the m
 and the p
 and the s
 and the t
 and the w
 and their 
 and there
 and there 
 and they
 and they 
 and they w
 and they wi
 and they will 
 and thi
 and tho
 and those 
 and those w
 and those wh
 and to
 and to 
 and to t
 and too
 and took
 and took 
 and tw
 and w
 and wa
 and we
 and went
 and went 
 and wh
 and whe
 and when
 and when 
 and wi
 and wil
 and will
 and will 
 and wit
 and with
 and with 
 and y
 and yo
 and you
 and you 
 and your
 and your 
 ang
 ange
 angel
 angel 
 angr
 angry
 ano
 another
 another 
 answer
 answer 
 answer,
 answer, 
 any
 any 
 any m
 any ma
 anything
 ar
 are
 are 
 are a
 are c
 are f
 are g
 are i
 are in
 are in 
 are l
 are li
 are m
 are n
 are no
 are not
 are not 
 are o
 are s
 are t
 are th
 are the
 are the 
 are to
 are to 
 are w
 are y
 are you
 ark
 ark 
 arm
 armi
 armies
 army
 army 
 as
 as 
 as a
 as a 
 as f
 as h
 as i
 as t
 as th
 as the
 as the 
 as w
 as y
 as you
 at
 at 
 at a
 at t
 at th
 at the
 at the 
 att
 atta
 atte
 atten
 attent
 attenti
 au
 author
 authorit
 authority
 authority 
 aw
 awa
 away
 away 
 away f
 away fr
 away from
 away from 
 away from th
 away from the
 away t
 away th
 away the
 away,
 away, 
 ba
 back
 back 
 back f
 back t
 back to
 back to 
 ban
 band
 bas
 base
 be
 be 
 be a
 be a 
 be b
 be c
 be cu
 be cut
 be d
 be f
 be g
 be gi
 be given
 be given 
 be h
 be i
 be in
 be l
 be li
 be m
 be ma
 be mad
 be made
 be made 
 be n
 be o
 be on
 be p
 be pu
 be put
 be put 
 be put t
 be put to
 be put to 
 be r
 be s
 be se
 be seen
 be t
 be ta
 be taken
 be th
 be the
 be the 
 be turn
 be turned
 be turned 
 be u
 be w
 be wi
 be wit
 be with
 be y
 be yo
 be you
 be your
 be your 
 bea
 beast
 beasts
 bec
 beca
 became
 became 
 because
 because 
 because h
 because he
 because he 
 because o
 because of 
 because of t
 because of th
 because of the
 because of the 
 because t
 because th
 because the
 because y
 because you
 becom
 become
 become 
 bee
 been
 been 
 been m
 been ma
 been t
 bef
 before
 before 
 before h
 before hi
 before him
 before m
 before t
 before th
 before the
 before the 
 before the L
 before the Lord
 before y
 before you
 being
 being 
 bes
 best
 best 
 bet
 better
 betw
 between
 between 
 bi
 bir
 bird
 birth
 birth 
 bit
 bitte
 bitter
 bitter 
 bl
 ble
 bless
 blessing
 blessing 
 blo
 bloo
 blood
 blood 
 bo
 bod
 body
 body 
 boo
 book
 br
 bra
 bre
 brea
 bread
 bread 
 bro
 broken
 broken 
 broth
 brother
 brother 
 brothers
 bu
 buil
 build
 building
 building 
 bur
 burn
 burne
 burned
 burned 
 burni
 burning
 burning 
 but
 but 
 but h
 but he
 but he 
 but i
 but t
 but th
 but the
 but the 
 but w
 but y
 but you
 by
 by 
 by a
 by f
 by h
 by hi
 by his 
 by m
 by t
 by th
 by the
 by the 
 by the s
 by w
 by y
 by you
 c
 ca
 cam
 came
 came 
 came a
 came b
 came o
 came out
 came t
 came to
 came to 
 came to h
 came to hi
 came to t
 came to th
 came to the
 came to the 
 capt
 captain
 car
 care
 care 
 care o
 cau
 caus
 cause
 cause 
 cause o
 cause of 
 causing 
 ce
 cer
 cert
 certain
 certain 
 certain t
 certain th
 certain that
 certain that 
 ch
 cha
 chan
 chang
 change
 chi
 chief
 chief 
 child
 child 
 children
 children 
 children o
 children of 
 children of I
 children of Is
 children of Israel
 children of Israel,
 children of Israel, 
 cl
 cle
 clea
 clean
 clear
 clear 
 clear t
 clo
 cloth
 clothing
 clou
 cloud
 co
 com
 come
 come 
 come a
 come b
 come ba
 come i
 come in
 come o
 come on
 come on 
 come out
 come t
 come to
 come to 
 come to t
 comes
 coming
 coming 
 comp
 compl
 complet
 complete
 con
 cou
 coun
 count
 countr
 country
 country 
 cove
 cover
 covere
 covered
 covered 
 cr
 cro
 cru
 cruel
 cruel 
 crus
 crush
 crushe
 crushed
 cry
 cry 
 crying
 crying 
 cu
 cur
 curs
 curse
 cut
 cut 
 cut o
 cut of
 cut off
 cutt
 d
 da
 dar
 dark
 dau
 daughter
 daughter 
 daughter o
 daughters
 day
 day 
 day o
 day of
 day of 
 day of t
 day of th
 day of the
 day w
 day,
 day, 
 day.
 days
 days 
 days o
 de
 dea
 dead
 dead 
 death
 death 
 death o
 death,
 death, 
 death.
 dec
 deci
 decision
 dee
 deep
 des
 desi
 desir
 desire
 desire 
 dest
 destr
 destruction
 destruction 
 destruction o
 di
 did
 did 
 did n
 did no
 did not
 did not 
 dir
 direct
 direction
 dis
 disc
 discipl
 disciple
 disciples
 disciples 
 disease
 disg
 disgu
 div
 divi
 division
 do
 do 
 do no
 do not
 do not 
 do t
 do th
 do the
 do w
 doe
 does
 doing
 doing 
 done
 done 
 done t
 door
 dow
 down
 down 
 down o
 down on
 down on 
 down t
 down to
 down to 
 dr
 dri
 drink
 dry
 du
 dust
 e
 ea
 ear
 ear 
 ear t
 ear to
 ear to 
 ear to t
 ear to th
 ear to the
 earl
 ears
 ears 
 earth
 earth 
 earth,
 earth, 
 earth.
 eas
 east
 effe
 effect
 en
 end
 end 
 end t
 end to
 end to 
 enough
 ev
 eve
 even
 even 
 even t
 ever
 ever 
 ever.
 every
 every 
 every m
 every ma
 every man
 every man 
 everything
 everything 
 evi
 evil
 evil 
 ex
 eye
 eyes
 eyes 
 eyes o
 eyes of 
 fa
 fac
 face
 face 
 fai
 faith
 faith 
 faith i
 faith in
 faith in 
 fal
 fall
 falling
 fals
 false
 false 
 fam
 fami
 famil
 famili
 families
 family
 family 
 family o
 far
 far 
 far a
 fat
 fath
 father
 father 
 father o
 father of 
 father,
 fathers
 fathers 
 fe
 fea
 fear
 fear 
 fear o
 fear of
 fear of 
 feast
 fee
 feet
 feet 
 fi
 fie
 field
 fift
 fig
 fight
 fighting
 fir
 fire
 fire 
 first
 first 
 five
 five 
 fixed
 fl
 fla
 fle
 flesh
 flesh 
 fli
 flight
 flight 
 flo
 flock
 flow
 fo
 foo
 food
 food 
 food,
 food, 
 fool
 foolish
 foolish 
 for
 for 
 for I
 for I 
 for a
 for a 
 for al
 for all
 for all 
 for e
 for ev
 for eve
 for ever
 for ever.
 for f
 for fo
 for h
 for he
 for he 
 for hi
 for him
 for his
 for his 
 for i
 for it
 for m
 for me
 for my
 for my 
 for o
 for s
 for t
 for th
 for the
 for the 
 for the L
 for the Lord
 for the p
 for their
 for their 
 for them
 for they
 for they 
 for w
 for y
 for you
 for you 
 for your
 for your 
 forc
 force
 fou
 four
 four 
 fr
 fre
 free
 free 
 free f
 free from 
 fri
 frie
 friend
 fro
 from
 from 
 from a
 from h
 from he
 from hi
 from him
 from his
 from his 
 from m
 from me
 from t
 from th
 from the
 from the 
 from the d
 from y
 from you
 from your 
 fru
 fruit
 fruit 
 fu
 ful
 full
 full 
 full o
 full of 
 g
 ga
 gave
 gave 
 gave h
 gave hi
 gave him
 gave him 
 gave o
 gave t
 gave th
 gave the
 gave them
 gave them 
 ge
 gen
 gene
 genera
 generation
 get
 get 
 get t
 gi
 giv
 give
 give 
 give a
 give e
 give ear
 give ear 
 give ear t
 give ear to
 give ear to 
 give h
 give hi
 give him
 give him 
 give m
 give me
 give me 
 give p
 give t
 give th
 give the
 give them
 give them 
 give u
 give w
 give y
 give you
 give you 
 given
 given 
 given t
 given th
 given the
 given to
 given to 
 given u
 gives
 giving
 giving 
 gl
 gla
 glad
 glad 
 glo
 glor
 glory
 glory 
 go
 go 
 go a
 go b
 go d
 go i
 go in
 go in 
 go o
 go on
 go on 
 go ou
 go out
 go out 
 go t
 go to
 go to 
 god
 gods
 goe
 goes
 going
 going 
 gold
 gold 
 gone
 gone 
 good
 good 
 good t
 goods
 got
 got 
 gr
 gra
 grac
 grace
 grace 
 grain
 grain 
 gre
 grea
 great
 great 
 great n
 great number
 greate
 gri
 grie
 grief
 gu
 gui
 guid
 ha
 had
 had 
 had a
 had a 
 had b
 had be
 had been
 had been 
 had c
 had co
 had com
 had come
 had come 
 had g
 had gi
 had given
 had given 
 had go
 had m
 had ma
 had made
 had n
 had no
 had no 
 had s
 had sa
 had sai
 had said
 had t
 had ta
 had th
 had the
 hai
 hair
 han
 hand
 hand 
 hand o
 hands
 hands 
 hands o
 hands of
 hands of 
 har
 hard
 hard 
 has
 hat
 hate
 hater
 haters
 hav
 have
 have 
 have a
 have a 
 have b
 have be
 have been
 have been 
 have c
 have co
 have com
 have come
 have come 
 have d
 have do
 have done
 have done 
 have f
 have g
 have gi
 have give
 have given
 have given 
 have go
 have h
 have k
 have know
 have knowledge
 have knowledge 
 have m
 have ma
 have made
 have made 
 have n
 have no
 have no 
 have not
 have not 
 have p
 have pu
 have put 
 have s
 have sa
 have said
 have se
 have t
 have ta
 have taken
 have taken 
 have th
 have the
 have the 
 have y
 have you
 have you 
 having 
 he
 he 
 he c
 he ca
 he came
 he came 
 he d
 he di
 he did
 he g
 he ga
 he gave
 he gave 
 he go
 he h
 he ha
 he had
 he had 
 he has
 he i
 he is
 he is 
 he m
 he ma
 he made
 he made 
 he p
 he pu
 he put
 he put 
 he s
 he sa
 he sai
 he said
 he said 
 he said t
 he said to 
 he said to th
 he said to the
 he said to them
 he said,
 he said, 
 he se
 he sen
 he t
 he to
 he took
 he took 
 he w
 he wa
 he was
 he was 
 he we
 he went
 he went 
 he wh
 he who
 he who 
 he wi
 he will
 he will 
 hea
 head
 head 
 heads
 hear
 hearing
 hearing 
 heart
 heart 
 heart,
 heart, 
 hearts
 hearts 
 heav
 heave
 heaven
 heaven 
 heaven,
 heaven, 
 hel
 help
 her
 her 
 her h
 her,
 her, 
 here
 here 
 heritage
 heritage 
 hi
 high
 high 
 high p
 hill
 him
 him 
 him a
 him an
 him and
 him and 
 him b
 him i
 him in
 him in 
 him o
 him t
 him th
 him the
 him to
 him to 
 him w
 him wh
 him who
 him who 
 him,
 him, 
 him, a
 him, an
 him, and
 him, and 
 him.
 him;
 him; 
 himself
 himself 
 his
 his 
 his a
 his b
 his br
 his bro
 his brother
 his c
 his d
 his de
 his e
 his f
 his fa
 his fat
 his father
 his g
 his h
 his ha
 his hand
 his he
 his hea
 his ho
 his hou
 his house
 his l
 his li
 his m
 his mo
 his n
 his o
 his p
 his pe
 his people
 his pl
 his pla
 his place
 his r
 his s
 his se
 his serv
 his servant
 his servants
 his so
 his son
 his sons
 his t
 his w
 his wa
 his wi
 his wo
 his wor
 ho
 hol
 holy
 holy 
 holy p
 holy place
 hon
 hono
 honour
 honour 
 hop
 hope
 hope 
 hor
 horn
 horse
 hou
 hous
 house
 house 
 house o
 house of 
 house of th
 house of the
 house of the 
 house,
 house, 
 house.
 houses
 how
 how 
 hu
 hun
 hundred
 hundred 
 hundred a
 hundred and 
 if
 if 
 if a
 if t
 if th
 if the
 if y
 if you
 im
 imag
 image
 in
 in 
 in J
 in Je
 in Jer
 in Jerusalem
 in a
 in a 
 in al
 in all
 in all 
 in an
 in e
 in f
 in fl
 in h
 in he
 in hea
 in hi
 in him
 in his 
 in his h
 in i
 in it
 in m
 in mi
 in min
 in mind
 in my
 in my 
 in n
 in o
 in p
 in s
 in t
 in th
 in the
 in the 
 in the b
 in the d
 in the da
 in the day
 in the e
 in the f
 in the fi
 in the h
 in the ho
 in the hou
 in the house
 in the l
 in the la
 in the lan
 in the land
 in the land 
 in the land o
 in the land of 
 in the m
 in the p
 in the s
 in the t
 in the w
 in the wa
 in the waste
 in the waste 
 in their 
 in thi
 in this
 in this 
 in w
 in wh
 in y
 in you
 in your
 in your 
 inc
 incre
 increas
 increase
 ins
 int
 into
 into 
 into t
 into th
 into the
 into the 
 into the h
 is
 is 
 is a
 is a 
 is b
 is c
 is d
 is f
 is g
 is go
 is h
 is i
 is in
 is in 
 is l
 is li
 is m
 is my 
 is n
 is no
 is no 
 is not
 is not 
 is o
 is on
 is p
 is r
 is s
 is t
 is th
 is the
 is the 
 is to
 is to 
 is to b
 is to be
 is to be 
 is u
 is un
 is w
 is wh
 is y
 is you
 is your
 is your 
 it
 it 
 it a
 it b
 it be
 it c
 it h
 it ha
 it i
 it in
 it is
 it is 
 it is t
 it o
 it t
 it to
 it to 
 it w
 it wa
 it was
 it was 
 it wi
 it will
 it will 
 it will b
 it will be
 it will be 
 it,
 it, 
 it.
 it;
 its
 its 
 j
 jo
 joy
 joy 
 ju
 judg
 judge
 k
 ke
 keep
 keep 
 keep t
 keep th
 keep the
 kept
 kept 
 ki
 kin
 king
 king 
 king o
 king of 
 king's
 king's 
 king,
 king, 
 kingdom
 kingdom 
 kings
 kings 
 kn
 kno
 know
 knowledge
 knowledge 
 knowledge o
 knowledge of
 knowledge of 
 knowledge of t
 knowledge of th
 knowledge of the
 l
 la
 lan
 land
 land 
 land o
 land of 
 land w
 land wh
 land,
 land, 
 land.
 las
 last
 law
 law 
 le
 lea
 let
 let 
 let h
 let hi
 let him
 let him 
 let m
 let t
 let th
 let the
 let the 
 let them
 let them 
 let u
 let us
 let us 
 let y
 let you
 let your
 let your 
 li
 lif
 life
 life 
 life,
 life, 
 lift
 lifte
 lifted
 lifted 
 lifted up
 lifted up 
 lig
 light
 light 
 lik
 like
 like 
 like a
 like a 
 like t
 like th
 like the
 like the 
 lin
 line
 litt
 little
 little 
 liv
 living
 living 
 living i
 living in
 living in 
 living in t
 living in th
 lo
 long
 long 
 longe
 longer
 longer 
 loo
 look
 looking
 looking 
 loos
 loose
 loose 
 lord
 loud
 loud 
 lov
 love
 love 
 low
 ma
 mad
 made
 made 
 made a
 made a 
 made an
 made an 
 made c
 made h
 made hi
 made s
 made t
 made th
 made the
 made the 
 made w
 mak
 make
 make 
 make a
 make a 
 make c
 make h
 make t
 make th
 make the
 make the 
 make y
 make yo
 make you
 makes
 making
 making 
 mal
 male
 male 
 man
 man 
 man a
 man h
 man i
 man is
 man is 
 man o
 man of
 man of 
 man t
 man w
 man wh
 man who
 man who 
 man's
 man's 
 man,
 man, 
 mar
 mark
 marke
 mas
 may
 may 
 may b
 may be
 may be 
 may g
 may h
 may have
 may have 
 may n
 may no
 may not
 may not 
 may not be
 may not be 
 me
 me 
 me a
 me an
 me i
 me in
 me t
 me to
 me to 
 me w
 me,
 me, 
 me, a
 me, an
 me, and
 me, and 
 me.
 me;
 me; 
 mea
 meal
 meal 
 measur
 measure
 mee
 meet
 meeting
 meeting 
 mem
 memor
 memory
 men
 men 
 men o
 men of
 men of 
 men w
 men,
 men, 
 mer
 merc
 mercy
 mercy 
 mi
 might
 might 
 min
 mind
 mind 
 mo
 mon
 money
 month
 mor
 more
 more 
 more t
 morning
 mot
 moth
 mothe
 mother
 mother 
 mou
 mount
 mountain
 mountains
 mouth
 mouth 
 mov
 move
 moved
 mu
 much
 much 
 mus
 my
 my 
 my b
 my c
 my d
 my e
 my f
 my fa
 my h
 my ha
 my hand
 my he
 my hea
 my ho
 my l
 my lo
 my m
 my p
 my pe
 my people
 my s
 my so
 my w
 my wo
 mys
 myself
 n
 na
 nam
 name
 name 
 name o
 name of 
 named
 named 
 nat
 nati
 nation
 nations
 nations 
 ne
 near
 near 
 nee
 need
 need 
 need o
 need of
 need of 
 nei
 neigh
 neighbour
 never
 never 
 new
 new 
 news
 news 
 ni
 nigh
 night
 no
 no 
 no f
 no fe
 no fea
 no fear
 no k
 no knowledge
 no knowledge 
 no l
 no lo
 no longer
 no longer 
 no m
 no o
 no one
 no one 
 no p
 no s
 no w
 not
 not 
 not a
 not ab
 not able
 not b
 not be
 not be 
 not c
 not co
 not com
 not come
 not come 
 not g
 not gi
 not giv
 not give
 not give 
 not go
 not go 
 not h
 not ha
 not k
 not ke
 not l
 not le
 not let
 not let 
 not m
 not ma
 not o
 not p
 not pu
 not put
 not put 
 not s
 not se
 not see
 not t
 not ta
 not tak
 not take
 not take 
 not th
 not the
 not to
 not to 
 nothing
 nothing 
 now
 now 
 now, 
 nu
 number
 number 
 number o
 number of 
 oa
 oath
 oath 
 of A
 of Am
 of As
 of B
 of Ba
 of Babylon
 of Be
 of C
 of D
 of Da
 of David
 of E
 of Eg
 of Egypt
 of G
 of Go
 of God
 of God 
 of God,
 of God, 
 of God.
 of H
 of Ha
 of I
 of Is
 of Israel
 of Israel 
 of Israel w
 of Israel,
 of Israel, 
 of Israel.
 of J
 of Ja
 of Je
 of Jer
 of Jeru
 of Jerusalem
 of Jo
 of Ju
 of Jud
 of Juda
 of Judah
 of Judah 
 of Judah,
 of Judah, 
 of K
 of M
 of Ma
 of Mo
 of N
 of P
 of S
 of Sh
 of Z
 of a
 of a 
 of al
 of all
 of all 
 of all t
 of all th
 of all the
 of all the 
 of an
 of ar
 of arm
 of armies
 of b
 of c
 of d
 of de
 of e
 of ev
 of f
 of fo
 of g
 of go
 of gr
 of h
 of he
 of hea
 of heav
 of heaven
 of hi
 of him
 of his
 of his 
 of i
 of it
 of it 
 of l
 of li
 of m
 of ma
 of man
 of me
 of men
 of my
 of my 
 of o
 of ou
 of our
 of our 
 of p
 of pe
 of pr
 of s
 of si
 of t
 of th
 of the
 of the 
 of the L
 of the Lord
 of the Lord 
 of the Lord c
 of the Lord w
 of the Lord,
 of the Lord, 
 of the Lord.
 of the a
 of the b
 of the c
 of the ch
 of the chi
 of the child
 of the children
 of the children 
 of the children of 
 of the d
 of the e
 of the ea
 of the ear
 of the earth
 of the f
 of the fi
 of the g
 of the h
 of the ho
 of the hou
 of the house
 of the k
 of the ki
 of the kin
 of the king
 of the l
 of the la
 of the lan
 of the land
 of the land 
 of the m
 of the n
 of the o
 of the p
 of the pe
 of the people
 of the pr
 of the r
 of the s
 of the se
 of the so
 of the t
 of the to
 of the tow
 of the town
 of the w
 of the wa
 of the wo
 of their
 of their 
 of them
 of them 
 of thi
 of this
 of this 
 of tho
 of those 
 of those w
 of those wh
 of those who
 of w
 of wa
 of war
 of wh
 of what
 of what 
 of wo
 of y
 of you
 of your
 of your 
 off
 off 
 offe
 offer
 offering
 offering 
 offerings
 offerings 
 oi
 oil
 oil 
 ol
 old
 old 
 on
 on 
 on a
 on e
 on h
 on hi
 on him
 on his 
 on i
 on it
 on m
 on t
 on th
 on the
 on the 
 on the e
 on the ea
 on the earth
 on the f
 on the s
 on the t
 on the w
 on their 
 on them
 on w
 on yo
 on you
 on your
 on your 
 one
 one 
 one a
 one o
 one of
 one of 
 one of t
 one of th
 one of the
 one of the 
 one w
 ones
 onl
 only
 only 
 op
 ope
 open
 open 
 or
 or 
 or a
 or t
 or th
 ord
 order
 order 
 other
 other 
 others
 ou
 our
 our 
 our God
 our f
 out
 out 
 out a
 out f
 out fr
 out from 
 out i
 out o
 out of 
 out of t
 out of th
 out of the
 out of the 
 out t
 out th
 out to
 out to 
 out,
 out, 
 outs
 ove
 over
 over 
 over t
 over th
 over the
 over the 
 overc
 overcom
 overcome
 overcome 
 overt
 ox
 oxen
 p
 pa
 pai
 pain
 par
 part
 part 
 part o
 part of 
 parts
 pas
 past
 pay
 payment
 pe
 pea
 peac
 peace
 peace 
 people
 people 
 people a
 people o
 people of
 people of 
 people w
 people,
 people, 
 people.
 peoples
 per
 pi
 pil
 pill
 pillar
 pl
 pla
 plac
 place
 place 
 place o
 place of 
 place w
 place,
 place, 
 place.
 places
 places 
 plan
 plant
 ple
 plea
 pleas
 pleasure
 pleasure 
 po
 poo
 poor
 poor 
 pos
 pow
 power
 power 
 power o
 power of 
 pr
 pra
 prais
 praise
 praise 
 praise t
 praise to
 praise to 
 pray
 praye
 prayer
 prayer 
 pre
 pri
 pric
 price
 pride
 pride 
 priest
 priest 
 priests
 priests 
 pris
 prison
 prisone
 prisoner
 pro
 prop
 proper
 prophe
 prophet
 prophet 
 prophets
 pu
 punish
 punishment
 punishment 
 pur
 purp
 purpos
 purpose
 purpose 
 put
 put 
 put a
 put a 
 put an
 put h
 put hi
 put him
 put him 
 put i
 put in
 put in 
 put it
 put it 
 put m
 put o
 put on
 put on 
 put t
 put th
 put the
 put the 
 put them
 put them 
 put to
 put to 
 put to de
 put to death
 put to death 
 put u
 put up
 put up 
 put y
 put you
 putt
 putting 
 qu
 que
 question
 qui
 quick
 quickly
 quickly 
 quiet
 r
 re
 rea
 read
 ready
 ready 
 reason
 rec
 reco
 record
 rel
 requ
 request
 request 
 res
 resp
 rest
 rest 
 rest o
 resti
 resting
 reward
 ri
 rig
 right
 right 
 righteous
 righteousness
 righteousness 
 river
 ro
 rob
 robe
 rod
 roo
 rou
 round
 round 
 ru
 rul
 rule
 ruler
 ruler 
 rulers
 rulers 
 sa
 saf
 safe
 safe 
 sai
 said
 said 
 said i
 said in
 said in 
 said t
 said to 
 said to M
 said to Mo
 said to Moses
 said to h
 said to hi
 said to him
 said to him,
 said to him, 
 said to m
 said to me
 said to th
 said to the
 said to the 
 said to them
 said to them,
 said to them, 
 said,
 said, 
 said, I
 said, I 
 said, T
 said, Th
 said, W
 said, Wh
 said:
 said: 
 sal
 salvation
 salvation 
 same
 same 
 saw
 saw 
 saw t
 saw th
 saw that
 saw that 
 say
 say 
 say t
 say th
 say to 
 say to you
 say to you, 
 say,
 say, 
 saying
 saying 
 saying,
 saying, 
 sc
 se
 sea
 sear
 search
 seat
 seat 
 seated
 sec
 second
 secret
 secret 
 see
 see 
 see t
 see th
 see that
 see that 
 see the
 see the 
 see,
 see, 
 seed
 seed 
 seem
 seen
 seen 
 sen
 send
 send 
 sens
 sense
 sent
 sent 
 sent f
 sent fo
 sent for
 sent for 
 sent t
 ser
 serv
 servant
 servant 
 servants
 servants 
 seve
 seven
 seven 
 sevent
 sh
 sha
 shak
 shaki
 sham
 shame
 shame 
 she
 she 
 she w
 shee
 sheep
 sheep 
 shi
 shu
 shut
 si
 sid
 side
 side 
 side o
 side of 
 sig
 sign
 sil
 silver
 silver 
 sin
 sin 
 sinn
 sinne
 sinner
 sins
 six
 six 
 sl
 sm
 sma
 small
 small 
 so
 so 
 so t
 so th
 so that
 so that 
 so that I
 so that I 
 so that h
 so that t
 so that th
 so that the
 so that they
 so that they 
 so that they m
 so that y
 some
 some 
 some o
 some of 
 son
 son 
 son o
 son of 
 son of A
 son of J
 son,
 son, 
 song
 sons
 sons 
 sons a
 sons o
 sons of
 sons of 
 sor
 sorr
 sorrow
 sort
 sou
 soul
 soul 
 sound
 sp
 spi
 spirit
 spirit 
 st
 sta
 sti
 still
 still 
 sto
 ston
 stone
 stones
 stor
 store
 str
 stra
 strai
 straight
 strang
 strange
 strange 
 stre
 strength
 strength 
 stretch
 stretche
 stretched
 stretched 
 stretched o
 stro
 strong
 strong 
 su
 suc
 such
 such 
 sun
 sw
 swo
 swor
 sword
 sword 
 ta
 tak
 take
 take 
 take a
 take away
 take away 
 take h
 take i
 take t
 take th
 take the
 take the 
 take y
 take you
 taken
 taken 
 taken a
 taken away
 takes
 taking
 taking 
 tal
 talk
 talking
 te
 tea
 teach
 teaching
 teaching 
 ten
 ten 
 tent
 tents
 tents 
 tha
 than
 than 
 than t
 than th
 that
 that 
 that I
 that I 
 that I m
 that d
 that da
 that day
 that h
 that he
 that he 
 that i
 that it
 that it 
 that t
 that th
 that the
 that the 
 that they
 that they 
 that they m
 that w
 that we
 that wh
 that y
 that you
 the A
 the C
 the E
 the G
 the God
 the God 
 the God o
 the God of 
 the God of Is
 the God of Israel
 the H
 the Ho
 the J
 the Je
 the Jew
 the Jews
 the L
 the Le
 the Levit
 the Levite
 the Levites
 the Lo
 the Lord
 the Lord 
 the Lord a
 the Lord c
 the Lord ca
 the Lord came 
 the Lord h
 the Lord ha
 the Lord had 
 the Lord i
 the Lord is
 the Lord is 
 the Lord o
 the Lord of 
 the Lord s
 the Lord sa
 the Lord said
 the Lord said 
 the Lord t
 the Lord w
 the Lord wi
 the Lord will
 the Lord will 
 the Lord y
 the Lord you
 the Lord your 
 the Lord your God
 the Lord your God 
 the Lord's
 the Lord's 
 the Lord,
 the Lord, 
 the Lord, a
 the Lord, an
 the Lord, and 
 the Lord, t
 the Lord, th
 the Lord, the
 the Lord, the 
 the Lord.
 the Lord:
 the Lord: 
 the Lord;
 the Lord; 
 the P
 the Ph
 the Philistine
 the Philistines
 the R
 the S
 the So
 the T
 the Te
 the a
 the al
 the altar
 the an
 the ang
 the ange
 the angel
 the ar
 the ark
 the ark 
 the arm
 the b
 the ba
 the be
 the bes
 the best 
 the bl
 the bo
 the br
 the bu
 the c
 the ca
 the capt
 the captain
 the ch
 the chi
 the chief
 the chief 
 the child
 the children
 the children 
 the children o
 the children of 
 the children of I
 the children of Is
 the children of Israel
 the children of Israel 
 the children of Israel,
 the co
 the cr
 the cu
 the d
 the da
 the dau
 the daughter
 the day
 the day 
 the day o
 the days
 the days 
 the de
 the dea
 the dead
 the des
 the di
 the dis
 the do
 the door
 the e
 the ea
 the ear
 the earth
 the earth 
 the earth,
 the earth, 
 the earth.
 the east
 the en
 the end
 the ev
 the evi
 the evil
 the evil 
 the eye
 the eyes
 the eyes 
 the eyes of 
 the f
 the fa
 the fam
 the fami
 the famil
 the fat
 the father
 the father 
 the father of 
 the fe
 the fea
 the fi
 the fie
 the field
 the fig
 the fir
 the fire
 the first
 the first 
 the fl
 the fle
 the flesh
 the fo
 the fou
 the fr
 the g
 the go
 the good
 the good 
 the gr
 the gra
 the gre
 the great
 the great 
 the h
 the ha
 the han
 the hand
 the hands
 the hands 
 the hands o
 the hands of 
 the he
 the hea
 the head
 the hear
 the hi
 the high
 the high 
 the ho
 the hol
 the holy
 the holy 
 the hou
 the house
 the house 
 the house o
 the house of 
 the house of th
 the house of the
 the house of the 
 the house of the L
 the i
 the k
 the ki
 the kin
 the king
 the king 
 the king o
 the king of 
 the king's
 the king's 
 the king,
 the kingdom
 the kingdom 
 the kings
 the l
 the la
 the lan
 the land
 the land 
 the land o
 the land of 
 the land of E
 the land of Egypt
 the land w
 the law
 the law 
 the le
 the li
 the lo
 the m
 the ma
 the man
 the man 
 the man w
 the me
 the men
 the men 
 the men o
 the men of 
 the mi
 the mo
 the mor
 the morning
 the mou
 the mount
 the mountain
 the n
 the na
 the name
 the name 
 the name of 
 the nat
 the nation
 the nations
 the nations 
 the ne
 the no
 the o
 the of
 the off
 the offe
 the offering
 the or
 the ord
 the order
 the other
 the other 
 the p
 the pa
 the pe
 the people
 the people 
 the people o
 the people of
 the people of 
 the people w
 the people,
 the people, 
 the pl
 the pla
 the place
 the place 
 the po
 the poo
 the poor
 the pow
 the power
 the power 
 the pr
 the pri
 the priest
 the priest 
 the priests
 the priests 
 the pro
 the prop
 the prophe
 the prophet
 the prophets
 the pu
 the r
 the re
 the res
 the rest
 the rest 
 the rest o
 the rest of 
 the ri
 the right
 the right 
 the ro
 the ru
 the rule
 the ruler
 the s
 the sa
 the same
 the same 
 the se
 the sea
 the sec
 the ser
 the serv
 the servant
 the seven
 the sh
 the si
 the sin
 the so
 the son
 the son 
 the son of 
 the son of A
 the son of J
 the sons
 the sons 
 the sons of 
 the sou
 the sp
 the st
 the sto
 the str
 the stre
 the su
 the sw
 the sword
 the t
 the te
 the ten
 the tent
 the th
 the thi
 the thin
 the thing
 the things
 the things 
 the thir
 the ti
 the tim
 the time
 the time 
 the to
 the tow
 the town
 the town 
 the towns
 the tr
 the tri
 the trib
 the tribe
 the tw
 the two
 the two 
 the u
 the un
 the up
 the upr
 the upright
 the v
 the va
 the val
 the vo
 the voice
 the voice 
 the w
 the wa
 the wall
 the was
 the wast
 the waste
 the waste 
 the wat
 the water
 the way
 the way 
 the we
 the wi
 the win
 the wo
 the wom
 the wor
 the word
 the word 
 the word o
 the word of 
 the word of t
 the word of th
 the word of the
 the word of the 
 the word of the L
 the word of the Lord
 the words
 the words 
 the words of 
 the work
 the work 
 the work o
 the work of 
 the world
 the wr
 the y
 the yo
 the you
 the young
 their
 their 
 their b
 their c
 their d
 their e
 their f
 their fa
 their fat
 their father
 their g
 their h
 their ha
 their he
 their hea
 their l
 their p
 their r
 their s
 their t
 their w
 them
 them 
 them a
 them b
 them f
 them i
 them in
 them in 
 them o
 them t
 them th
 them to
 them to 
 them w
 them,
 them, 
 them, a
 them, an
 them, and
 them, and 
 them.
 them:
 them;
 them; 
 themselves
 themselves 
 then
 then 
 then t
 then, 
 there
 there 
 there i
 there is 
 there is n
 there is no
 there is no 
 there w
 there wa
 there was
 there was 
 there wi
 there will 
 there,
 there, 
 these
 these 
 these t
 these th
 these thi
 these things
 these things 
 these w
 these wo
 they
 they 
 they a
 they ar
 they are
 they are 
 they c
 they ca
 they came
 they came 
 they g
 they ga
 they gave
 they gave 
 they h
 they ha
 they had
 they had 
 they have
 they have 
 they m
 they ma
 they made
 they made 
 they may 
 they p
 they pu
 they put 
 they s
 they sa
 they sai
 they said
 they t
 they to
 they took
 they took 
 they w
 they we
 they went
 they went 
 they were
 they were 
 they wi
 they will
 they will 
 they will be
 they will be 
 thi
 thin
 thing
 thing 
 things
 things 
 things w
 things wh
 things whi
 things which
 things which 
 thir
 thirt
 thirty
 this
 this 
 this c
 this ca
 this cause
 this d
 this da
 this day
 this i
 this is
 this is 
 this p
 this t
 this w
 this,
 this, 
 tho
 those
 those 
 those w
 those wh
 those who
 those who 
 those who w
 those who we
 those who were 
 thou
 though
 though 
 thought
 thought 
 thousand
 thousand 
 thr
 thre
 three
 three 
 thro
 through
 through 
 through a
 through t
 through th
 through the
 through the 
 ti
 til
 till
 till 
 till th
 till the
 till the 
 tim
 time
 time 
 time,
 time, 
 times
 times 
 to
 to 
 to A
 to B
 to D
 to G
 to Go
 to God
 to J
 to Je
 to Jer
 to Jeru
 to M
 to Mo
 to Mose
 to Moses
 to Moses,
 to S
 to a
 to a 
 to al
 to all
 to all 
 to all th
 to an
 to an 
 to b
 to be
 to be 
 to be p
 to be t
 to c
 to co
 to com
 to come
 to come 
 to d
 to de
 to dea
 to death
 to death 
 to death.
 to des
 to destr
 to destruction
 to do
 to do 
 to g
 to ge
 to get
 to get 
 to gi
 to give
 to give 
 to go
 to go 
 to h
 to ha
 to have
 to have 
 to he
 to her
 to hi
 to him
 to him 
 to him,
 to him, 
 to his
 to his 
 to k
 to keep
 to keep 
 to l
 to m
 to ma
 to make
 to make 
 to me
 to me 
 to me,
 to me, 
 to my
 to my 
 to o
 to p
 to pu
 to put
 to put 
 to s
 to sa
 to say
 to say 
 to se
 to see
 to see 
 to t
 to ta
 to tak
 to take
 to take 
 to th
 to the
 to the 
 to the L
 to the Lord
 to the Lord 
 to the Lord,
 to the Lord, 
 to the c
 to the ch
 to the chi
 to the child
 to the e
 to the ea
 to the h
 to the k
 to the kin
 to the king
 to the m
 to the p
 to the s
 to the t
 to the w
 to the wo
 to their 
 to them
 to them 
 to them,
 to them, 
 to thi
 to this
 to this 
 to tho
 to those
 to those 
 to those w
 to those wh
 to u
 to us
 to w
 to wh
 to who
 to y
 to yo
 to you
 to you 
 to you,
 to you, 
 to you.
 to your
 to your 
 together
 together 
 ton
 too
 took
 took 
 took a
 took h
 took hi
 took t
 took th
 took the
 took the 
 tow
 town
 town 
 town,
 town, 
 towns
 towns 
 tr
 tra
 tre
 tree
 tri
 trib
 tribe
 tro
 trou
 troubl
 trouble
 trouble 
 troubled
 tru
 true
 true 
 truly
 tu
 tur
 turn
 turne
 turned
 turned 
 turned a
 turned away
 turned t
 turned to
 turned to 
 turning
 turning 
 tw
 twe
 twel
 twelve
 twent
 twenty
 two
 two 
 u
 un
 unc
 uncl
 uncle
 unclean
 unclean 
 und
 unde
 under
 under 
 under t
 under th
 under the
 under the 
 up
 up 
 up a
 up an
 up and
 up and 
 up f
 up i
 up in
 up o
 up t
 up th
 up the
 up the 
 up to
 up to 
 up to t
 up to th
 up to the
 up to the 
 up,
 up, 
 upr
 upri
 upright
 upright 
 us
 us 
 us,
 us, 
 use
 use 
 v
 va
 val
 valley
 ve
 ver
 very
 very 
 ves
 vessel
 vessels
 vi
 vin
 vine
 viol
 violen
 violent
 vo
 voi
 voice
 voice 
 voice o
 voice of 
 wa
 wai
 wait
 waiting
 waiting 
 wal
 wall
 war
 war 
 was
 was 
 was a
 was a 
 was c
 was f
 was g
 was i
 was in
 was in 
 was l
 was m
 was n
 was no
 was not
 was not 
 was o
 was p
 was s
 was t
 was th
 was the
 was the 
 was w
 wast
 waste
 waste 
 wat
 watch
 water
 water 
 waters
 waters 
 way
 way 
 way o
 way of
 way of 
 way,
 way, 
 ways
 ways 
 we
 we 
 we a
 we ar
 we are
 we are 
 we h
 we ha
 we have
 we have 
 we w
 we wi
 we will
 we will 
 wea
 wealth
 wealth 
 wee
 weep
 weeping
 weigh
 weight
 wel
 well
 well 
 wen
 went
 went 
 went a
 went away
 went b
 went d
 went down
 went down 
 went i
 went in
 went in 
 went o
 went on
 went on 
 went ou
 went out
 went out 
 went t
 went to
 went to 
 went u
 went up
 went up 
 wer
 were
 were 
 were a
 were f
 were i
 were in
 were in 
 were l
 were n
 were no
 were o
 were p
 were s
 were t
 were th
 were the
 were w
 wh
 wha
 what
 what 
 what h
 what i
 what is 
 what t
 what th
 what the
 what the 
 what the L
 whe
 when
 when 
 when I
 when I 
 when h
 when he
 when he 
 when t
 when th
 when the
 when the 
 when they
 when they 
 when y
 when you
 where
 where 
 where t
 where th
 where the
 whi
 which
 which 
 which I
 which I 
 which a
 which ar
 which are
 which are 
 which h
 which ha
 which he
 which he 
 which i
 which is
 which is 
 which t
 which th
 which the
 which the 
 which the L
 which the Lord
 which the Lord 
 which w
 which wa
 which was
 which was 
 which we
 which y
 which you
 whil
 while
 while 
 who
 who 
 who a
 who ar
 who are 
 who c
 who g
 who h
 who ha
 who had 
 who has
 who have 
 who i
 who is 
 who m
 who ma
 who s
 who t
 who w
 who wa
 who was
 who was 
 who we
 who were 
 whom
 whom 
 whom t
 whom th
 whom the
 whos
 whose 
 why
 why 
 wi
 wid
 wide
 wife
 wife 
 wil
 will
 will 
 will b
 will be
 will be 
 will be a
 will be c
 will be f
 will be g
 will be l
 will be m
 will be o
 will be s
 will be t
 will be th
 will be the
 will be w
 will c
 will co
 will com
 will come
 will come 
 will come t
 will come to
 will come to 
 will g
 will get
 will get 
 will give
 will give 
 will give t
 will give you
 will give you 
 will go
 will go 
 will h
 will ha
 will have
 will have 
 will k
 will keep 
 will m
 will ma
 will make
 will make 
 will n
 will no
 will not
 will not 
 will not b
 will not be
 will not be 
 will not g
 will p
 will pu
 will put 
 will s
 will sa
 will say
 will se
 will see
 will send
 will send 
 will t
 will ta
 will take
 will take 
 will y
 will you
 win
 wind
 wine
 wis
 wisdom
 wisdom 
 wise
 wise 
 wit
 with
 with 
 with a
 with a 
 with all 
 with c
 with f
 with h
 with hi
 with him
 with him 
 with his
 with his 
 with m
 with me
 with s
 with t
 with th
 with the
 with the 
 with their
 with their 
 with them
 with w
 with y
 with you
 without
 without 
 witness
 witness 
 wo
 wom
 woman
 woman 
 women
 won
 wond
 wonder
 woo
 wood
 wor
 word
 word 
 word o
 word of
 word of 
 word of t
 word of th
 word of the
 word of the 
 word of the L
 word of the Lord
 words
 words 
 words o
 words of 
 words of t
 words of th
 work
 work 
 work o
 work of 
 works
 world
 wors
 worship
 worship 
 wou
 would
 would 
 would n
 would no
 would not
 wr
 wra
 wrath
 wrath 
 wro
 wrong
 y
 ye
 yea
 year
 year 
 years
 years 
 years o
 yo
 you
 you 
 you a
 you an
 you and 
 you ar
 you are
 you are 
 you are t
 you b
 you c
 you d
 you do
 you f
 you g
 you go
 you h
 you ha
 you have
 you have 
 you i
 you in
 you in 
 you m
 you ma
 you may 
 you n
 you no
 you o
 you p
 you s
 you sa
 you se
 you t
 you th
 you the
 you to
 you to 
 you w
 you wh
 you wi
 you will
 you will 
 you will be
 you will be 
 you,
 you, 
 you, O
 you, O 
 you, a
 you, an
 you, and
 you, and 
 you.
 you:
 you: 
 you;
 you; 
 you?
 young
 young 
 your
 your 
 your G
 your God
 your God 
 your b
 your br
 your c
 your d
 your e
 your eye
 your eyes
 your f
 your fa
 your fat
 your father
 your g
 your h
 your ha
 your hand
 your he
 your hea
 your hear
 your heart
 your ho
 your l
 your li
 your m
 your n
 your o
 your p
 your r
 your s
 your se
 your serv
 your servant
 your so
 your t
 your w
 your wo
 your wor
 yours
 yoursel
 yourselves
 yourselves 
!
! 
'
' 
's
's 
's b
's h
's ho
's house
's p
's s
's w
(
)
, A
, B
, Be
, C
, D
, G
, Gi
, Go
, Go 
, H
, Ha
, He
, I
, I 
, I a
, I am
, I am 
, I h
, I ha
, I have 
, I w
, I wi
, I will
, I will 
, If 
, J
, L
, Le
, Let
, Let 
, M
, Ma
, N
, No
, O
, O 
, O L
, O Lord
, O Lord, 
, P
, S
, Se
, See
, T
, Th
, The
, The 
, Thi
, This 
, W
, Wh
, What
, What 
, Y
, You
, a 
, al
, all 
, an
, and
, and 
, and I
, and I 
, and I w
, and I wi
, and I will 
, and a
, and a 
, and al
, and all 
, and all t
, and all th
, and all the
, and all the 
, and b
, and be
, and c
, and d
, and f
, and g
, and ga
, and gave
, and gave 
, and gi
, and giv
, and give
, and h
, and ha
, and hav
, and have 
, and he
, and he 
, and he w
, and hi
, and his
, and his 
, and i
, and in
, and in 
, and it
, and l
, and le
, and let
, and let 
, and m
, and ma
, and mak
, and n
, and no
, and o
, and p
, and pu
, and put
, and put 
, and s
, and sa
, and sai
, and said
, and se
, and t
, and ta
, and th
, and the
, and the 
, and their 
, and there
, and there 
, and they
, and they 
, and they w
, and to
, and to 
, and w
, and we
, and wh
, and wi
, and wil
, and will
, and will 
, and y
, and you
, and you 
, and your
, and your 
, ar
, are 
, as
, as 
, as t
, as th
, as the
, at
, b
, be
, bec
, beca
, because
, because 
, because o
, because of 
, because t
, because th
, bu
, but
, but 
, but t
, but th
, but the
, by 
, by t
, c
, ca
, cam
, came
, came 
, co
, d
, do
, e
, ev
, eve
, even
, even 
, ever
, every
, f
, fo
, for
, for 
, for t
, for th
, for the
, for the 
, fr
, from 
, g
, gi
, giv
, give
, give 
, go
, h
, ha
, hav
, having 
, he
, he 
, he s
, he w
, hi
, his 
, i
, if
, if 
, in
, in 
, in t
, in th
, in the
, in the 
, is
, is 
, it
, it 
, k
, ki
, kin
, king
, king 
, king o
, king of 
, l
, le
, let
, let 
, li
, like
, like 
, m
, ma
, mak
, my
, my 
, n
, no
, not
, not 
, o
, of
, of 
, on
, on 
, on t
, on th
, one
, one 
, or
, or 
, p
, pu
, put
, s
, sa
, sai
, said
, said,
, say
, saying
, saying,
, saying, 
, se
, sh
, so
, so 
, so th
, so that
, so that 
, so that t
, so that th
, so that the
, t
, ta
, tak
, th
, tha
, that
, that 
, the
, the 
, the G
, the God
, the God 
, the God of 
, the c
, the f
, the p
, the s
, the so
, the son
, the son 
, the son of 
, the son of A
, the son of J
, then
, then 
, they
, they 
, they w
, ti
, till 
, to
, to 
, to t
, to th
, to the
, to the 
, tw
, w
, wa
, was
, was 
, we
, we 
, wer
, were
, were 
, wh
, whe
, when
, when 
, whi
, which
, which 
, who
, who 
, who h
, who ha
, who w
, whos
, whose 
, wi
, wil
, will
, will 
, wit
, with
, with 
, with t
, with th
, with the
, y
, yo
, you
, you 
, your
, your 
-
-h
-p
-w
. 
. A
. And
. And 
. And h
. And t
. And th
. And the
. S
. So
. So 
. T
. Th
. The
:
: 
: I
: I 
: a
: an
: and
: and 
: and h
: and t
: and th
: and the
: and the 
: b
: bu
: but
: but 
: f
: fo
: for
: for 
: for t
: for th
: for the
: h
: he
: he 
: i
: s
: so
: so 
: t
: th
: the
: the 
: w
;
; 
; I
; I 
; I w
; a
; an
; and
; and 
; and I
; and I 
; and a
; and h
; and he
; and he 
; and i
; and t
; and th
; and the
; and the 
; and they
; and they 
; and w
; b
; be
; bec
; because
; because 
; bu
; but
; but 
; but t
; f
; fo
; for
; for 
; for t
; for th
; for the
; h
; he
; he 
; i
; l
; le
; let
; let 
; o
; s
; so
; so 
; so t
; so th
; t
; th
; the
; the 
; they
; they 
; w
; wh
; y
; you
?
? 
? A
? And
? And 
? a
? w
A
A 
Aaron
Aaron 
Ab
Abi
Abr
Abra
Abraham
Ah
Aha
Al
All
All 
All th
Am
Amm
An
And
And 
And A
And D
And Da
And David
And I
And I 
And I w
And I will 
And J
And Je
And M
And S
And a
And al
And all 
And all t
And all th
And f
And h
And he
And he 
And he s
And he sa
And he sai
And he said
And he said 
And he said t
And he said to 
And he said, 
And he w
And i
And if
And if 
And in
And in 
And it
And it 
And l
And n
And o
And on
And s
And t
And th
And the
And the 
And the L
And the Lord
And the Lord 
And the Lord s
And the Lord sa
And the Lord said
And the Lord said 
And the s
And they
And they 
And they w
And w
And wh
And whe
And when
And when 
And when th
And when the
And when the 
And y
And you
And you 
Ar
Ara
As
As 
At
B
Ba
Baa
Bab
Babylon
Be
Be 
Bec
Beca
Because
Because 
Ben
Benjami
Benjamin
Bet
Beth
Bu
But
But 
But h
But i
But if
But if 
But t
But th
But the
But the 
But w
By 
C
Ca
Can
Ch
Christ
Christ 
Co
Com
Come
Come 
D
Da
David
David 
Do
Do 
Do no
Do not
Do not 
E
Eg
Egypt
Egypt 
Egypt,
Egypt, 
El
Eli
Ep
Eph
Ephr
Ephra
Ephrai
Ephraim
Es
Ev
Eve
F
Fa
Fat
Father
Fo
For
For 
For t
For th
For the
For the 
For thi
For this
For this 
G
Ga
Ge
Gi
Giv
Give
Give 
Go
Go 
God
God 
God a
God h
God ha
God has
God i
God is
God is 
God w
God,
God, 
H
Ha
Hav
Have
Have 
He
He 
He w
He wh
He who
He who 
Hi
Ho
How
How 
I
I 
I a
I am
I am 
I am t
I am th
I am the
I am the 
I am the L
I am the Lord
I d
I g
I gi
I give
I give 
I h
I ha
I have
I have 
I have g
I have give
I have given 
I have s
I m
I ma
I may
I may 
I s
I sa
I said
I saw
I saw 
I say
I say 
I say t
I say to 
I say to you
I se
I t
I to
I w
I wa
I was
I was 
I wi
I will
I will 
I will b
I will be
I will be 
I will g
I will give
I will give 
I will m
I will ma
I will make
I will make 
I will n
I will no
I will not
I will not 
I will s
I will se
I will send
I will send 
If
If 
In
In 
In t
In th
In the
In the 
Is
Is 
Isa
Israel
Israel 
Israel w
Israel.
It
It 
It is
It is 
J
Ja
Jac
Jacob
Jacob 
Je
Jeh
Jeho
Jer
Jeru
Jerus
Jerusalem
Jerusalem 
Jes
Jesu
Jesus
Jesus 
Jesus s
Jesus sa
Jesus sai
Jesus said
Jesus,
Jo
Joa
Joh
Jor
Jos
Jose
Joseph
Josh
Joshua
Ju
Jud
Juda
Judah
Judah 
Judah,
Judah, 
K
Ke
Ki
Kin
King
King 
L
La
Le
Let
Let 
Let t
Let th
Let the
Lo
Lor
Lord
Lord 
Lord h
Lord ha
Lord,
Lord, 
Lord, a
Lord, t
Lord, th
Lord, the
Lord, w
M
Ma
Mak
Make
Make 
Man
Me
Mi
Mo
Moa
Moab
Mos
Mose
Moses
Moses 
My
My 
N
Na
Ne
No
Now
Now 
Now t
Now th
Now the
Now the 
O
O 
O L
O Lord
O Lord, 
Of
Of 
On
One
P
Pa
Pau
Paul
Pe
Pet
Ph
Pha
Phar
Pharaoh
Phi
Phil
Phili
Pu
R
Ra
Re
S
Sa
Sam
Saul
Saul 
Say
Se
See
See, 
See, I
See, I 
Sh
Sha
She
Si
So
So 
So t
So th
So that
So that 
So the
So the 
Solomon
Solomon 
Son
Son 
Son of 
Sp
Spi
T
Ta
Tak
Take
Take 
Te
Ten
Th
The
The 
The L
The Lord
The Lord 
The s
The w
Then
Then 
Then J
Then h
Then he
Then he 
Then t
Then th
Then the
Then the 
There
There 
Thes
These
These 
These a
These are 
These are t
They
They 
Thi
This
This 
This i
This is 
This is w
To
To 
Tr
Tru
Truly
U
W
We
We 
Wh
What
What 
Whe
When
When 
Who
Who 
Why
Why 
Wi
Y
Yo
You
You 
Your
Your 
Z
Ze
Zi
Zio
Zion
a 
a a
a an
a and 
a b
a c
a ca
a d
a de
a f
a g
a gr
a gre
a great
a great 
a h
a ho
a l
a li
a lo
a m
a ma
a me
a n
a p
a pr
a r
a re
a s
a se
a si
a so
a st
a str
a t
a th
a w
a wa
a wi
a wo
a,
a, 
a, a
a, t
a, th
a, the
a, the 
a.
aa
aal
aan
ab
ab 
ab,
ab, 
aba
abb
abba
abl
able
able 
able t
able to
able to 
able to g
abo
abou
about
about 
aby
ac
acc
ace
ace 
ace a
ace b
ace i
ace in
ace in 
ace o
ace of
ace of 
ace of t
ace of th
ace of the
ace of the 
ace t
ace w
ace,
ace, 
ace.
aces
aces 
ach
ache
achi
achin
aching
aching 
ack
ack 
ack a
ack f
ack t
ack to
ack to 
ack,
ack, 
aco
act
acts
ad
ad 
ad a
ad a 
ad an
ad and
ad and 
ad b
ad be
ad c
ad co
ad com
ad come
ad come 
ad d
ad f
ad g
ad gi
ad giv
ad given
ad given 
ad go
ad i
ad m
ad ma
ad made
ad n
ad no
ad no 
ad o
ad s
ad sa
ad sai
ad said
ad t
ad ta
ad th
ad the
ad the 
ad w
ad,
ad, 
ad.
ada
add
ade
ade 
ade a
ade an
ade an 
ade c
ade h
ade hi
ade s
ade t
ade th
ade the
ade w
ads
ads 
ady
ady 
ae
aea
ael
ael 
ael a
ael w
ael,
ael, 
ael, a
ael.
af
afe
aft
afte
after
after 
ag
aga
age
age 
ages
ages 
agr
ah
ah 
ah a
ah an
ah and
ah and 
ah t
ah th
ah the
ah the 
ah w
ah,
ah, 
ah, a
ah, an
ah, and
ah, and 
ah, t
ah, th
ah, the
ah, the 
ah, the s
ah, the son
ah, the son of 
ah.
ah;
aha
aham
ai
ai 
aia
aiah
aid
aid 
aid i
aid in
aid in 
aid t
aid to 
aid to h
aid to hi
aid to him
aid to him,
aid to him, 
aid to m
aid to th
aid to the
aid,
aid, 
aid, I
aid, I 
aid:
aid: 
aig
aim
ain
ain 
ain a
ain o
ain of
ain of 
ain t
ain th
ain that
ain that 
ain,
ain, 
ain.
ains
ains 
ains o
air
air 
ais
ait
aith
aith 
aith i
aith in
aith in 
aiting
aiting 
ak
ake
ake 
ake a
ake a 
ake an
ake away
ake away 
ake c
ake f
ake h
ake hi
ake him
ake i
ake it
ake it 
ake m
ake n
ake no
ake o
ake p
ake s
ake t
ake th
ake the
ake the 
ake them
ake them 
ake u
ake w
ake y
ake yo
ake you
ake you 
ake your
ake your 
aken
aken 
aken a
aker
akes
akes 
akes a
aki
aking
aking 
al
al 
al o
al of
al,
al, 
ale
ale 
alem
alem 
alem,
alem, 
ali
alk
alking
alking 
all
all 
all I
all h
all hi
all his
all his 
all m
all o
all of
all of 
all t
all th
all the
all the 
all the p
all the pe
all the people
all the people 
all the t
all the w
all thi
all thin
all thing
all tho
all those
all those 
all w
all y
all you
all your 
all,
all, 
alle
alley
alli
alling
alm
als
alse
alse 
alt
alta
alth
alv
alva
alvation
alvation 
am
am 
am a
am t
am th
am the
am the 
am w
am,
am, 
ama
amar
amb
ame
ame 
ame a
ame b
ame f
ame i
ame in
ame o
ame of
ame of 
ame on
ame on 
ame out
ame t
ame th
ame to
ame to 
ame to h
ame to hi
ame to t
ame to th
ame to the
ame to the 
ame w
ame wa
ame,
ame, 
ame.
amed
amed 
ames
ami
amin
amo
amon
among
an 
an a
an an
an and 
an e
an en
an f
an h
an ha
an i
an in
an is
an is 
an o
an of
an of 
an off
an offe
an offer
an offering
an s
an t
an th
an the
an the 
an to
an to 
an w
an wh
an who
an who 
an wi
an's
an's 
an,
an, 
an, a
an, an
an, and
an, and 
an, t
an, th
an, the
an.
an;
ana
anaan
anc
and A
and B
and E
and I
and I 
and I w
and I wi
and I will 
and J
and Je
and Jo
and M
and S
and a
and a 
and al
and all
and all 
and all t
and all th
and all the
and all the 
and an
and b
and be
and be 
and c
and ca
and came
and co
and d
and do
and do 
and e
and ev
and eve
and ever
and every
and f
and fo
and for
and for 
and fr
and fro
and from 
and g
and ga
and gave
and gave 
and gi
and giv
and give
and give 
and go
and h
and ha
and had 
and hav
and have 
and he
and he 
and he w
and he wi
and he will 
and hi
and his
and his 
and ho
and i
and in
and in 
and in t
and in th
and in the
and in the 
and is
and is 
and it
and it 
and its
and k
and ke
and l
and le
and m
and ma
and mad
and made
and made 
and mak
and make
and make 
and my
and my 
and n
and no
and not
and not 
and o
and of
and of 
and of E
and of Egypt
and of t
and of th
and of the
and of the 
and on
and on 
and on t
and on th
and on the
and on the 
and p
and pu
and put
and put 
and put t
and r
and s
and sa
and sai
and said
and said 
and said,
and said, 
and say
and se
and sh
and she
and so
and st
and t
and ta
and tak
and take
and take 
and th
and tha
and that
and that 
and the
and the 
and the L
and the b
and the c
and the ch
and the f
and the h
and the m
and the p
and the s
and the t
and the w
and their
and there
and there 
and they
and they 
and they w
and they wi
and they will 
and thi
and tho
and those 
and those w
and those wh
and to
and to 
and to t
and to th
and too
and took
and took 
and tw
and w
and wa
and was
and was 
and we
and went
and went 
and wh
and whe
and when
and when 
and whi
and which
and which 
and wi
and wil
and will
and will 
and wit
and with
and with 
and y
and yo
and you
and you 
and your
and your 
and,
and, 
and, a
and.
ande
ands
ands 
ands o
ands of
ands of 
ands of t
ands of th
ands,
ands, 
ang
ange
ange 
angel
anging
anging 
ani
ano
anoth
ans
answer
ant
ant 
ant,
ant, 
ants
ants 
any
any 
any m
any ma
ao
ap
aph
app
apt
ar
ar 
ar a
ar an
ar and
ar and 
ar b
ar o
ar of
ar of 
ar of t
ar of th
ar of the
ar of the 
ar t
ar th
ar the
ar to
ar to 
ar to m
ar to t
ar to th
ar to the
ar to the 
ar w
ar,
ar, 
ar, a
ar.
ar;
ara
arc
arch
ard
ard 
arde
arden
are
are 
are a
are c
are f
are g
are i
are in
are in 
are l
are m
are n
are no
are not
are not 
are o
are of
are of 
are s
are t
are th
are the
are the 
are to
are to 
are w
are y
are you
are you 
ari
aria
arin
aring
aring 
ark
ark 
ark o
arke
arl
arly
arly 
arm
arme
armi
aro
aron
aron 
arr
arri
ars
ars 
ars o
ars of 
ars,
ars, 
art
art 
art i
art o
art of 
art of t
art of th
art of the
art,
art, 
arth
arts
arts 
as
as 
as a
as a 
as an
as b
as be
as bee
as c
as co
as com
as come
as come 
as d
as do
as done
as f
as fa
as fo
as for
as g
as gi
as giv
as give
as given
as given 
as go
as h
as he
as he 
as i
as in
as in 
as it
as k
as l
as li
as m
as ma
as made
as made 
as n
as no
as no 
as not
as not 
as o
as on
as p
as pu
as put
as put 
as r
as s
as sa
as sai
as said
as se
as t
as ta
as tak
as taken
as taken 
as th
as the
as the 
as the L
as the Lord
as the Lord 
as to
as to 
as w
as wi
as y
as you
as,
as, 
ase
ase 
ased
ased 
ash
asi
asin
asing
asing 
ason
ason 
ass
ass 
asse
ast
ast 
ast,
ast, 
aste
aste 
aster
asts
asts 
asu
at 
at I
at I 
at a
at al
at all
at all 
at an
at d
at da
at day
at day 
at f
at h
at he
at he 
at hi
at his 
at i
at is
at is 
at is t
at it
at it 
at m
at n
at number
at o
at of
at of 
at p
at s
at t
at th
at the
at the 
at the L
at the Lord
at they
at they 
at w
at wa
at we
at wh
at y
at you
at you 
at,
at, 
atch
ate
ate 
ated
ated 
ater
ater 
aters
aters 
ath
ath 
ath a
ath b
ath i
ath o
ath of
ath of 
ath t
ath w
ath wi
ath,
ath, 
ath, a
ath.
ath;
atha
athan
athe
ather
ather 
ather o
ather of 
ather's
ather's 
ather,
ather, 
athers
athers 
athers,
ati
ation
ation 
ations
ations 
ats
att
atta
atte
atten
au
aug
augh
aught
aughter
aughter 
aughter o
aughters
aul
aul 
aus
ause
ause 
ause t
ause th
ause the
ausing 
aut
av
ave
ave 
ave a
ave a 
ave b
ave be
ave c
ave co
ave com
ave d
ave f
ave g
ave gi
ave go
ave h
ave hi
ave him
ave him 
ave i
ave k
ave know
ave knowledge
ave knowledge 
ave l
ave m
ave me
ave n
ave no
ave no 
ave no f
ave not
ave not 
ave o
ave p
ave s
ave sa
ave se
ave t
ave ta
ave th
ave the
ave the 
ave them
ave them 
ave to
ave to 
ave w
ave y
ave you
ave you 
aven
aven 
aven,
aven, 
avi
avin
aving
aving 
aviour
aviour 
aw
aw 
aw a
aw t
aw th
aw that
aw that 
aw the
awa
away
away 
away t
ay
ay 
ay a
ay an
ay and
ay and 
ay b
ay be
ay be 
ay f
ay fr
ay from
ay from 
ay from th
ay from the
ay g
ay h
ay ha
ay have
ay have 
ay i
ay in
ay n
ay no
ay not
ay not 
ay o
ay of
ay of 
ay of t
ay of th
ay of the
ay of the 
ay s
ay t
ay th
ay the
ay the 
ay to
ay to 
ay to t
ay to th
ay to the
ay to you
ay to you, 
ay w
ay wh
ay,
ay, 
ay, a
ay, an
ay, and
ay, and 
ay.
ay;
aye
ayer
ayer 
aying
aying 
aying,
aying, 
aym
ayment
ays
ays 
ays a
ays o
ays of 
ays t
ays th
ays the
ays the 
ays the L
ays,
ays, 
az
aza
b 
b,
b, 
ba
bac
back
back 
back t
back to
back to 
ban
band
band 
bas
base
bat
bath
bb
bba
be
be 
be a
be a 
be b
be c
be cu
be cut
be d
be f
be h
be i
be in
be in 
be l
be m
be ma
be mad
be made
be made 
be o
be of
be of 
be on
be p
be r
be s
be t
be th
be the
be the 
be w
be wi
be wit
be with
be y
bea
beast
beasts
bec
beca
because
because 
because h
because he
because he 
because o
because of 
because of t
because of th
because of the
because of the 
because t
because th
because the
bed
bee
bei
being
being 
ben
ber
ber 
bes
bes 
bet
betw
between
between 
bi
bir
birth
birth 
bit
bits
bits 
bitte
bl
ble
ble 
ble f
ble fo
ble for 
ble t
ble to
ble to 
ble to g
bled
bles
bli
blo
bloo
blood
blood 
blow
bo
boa
bod
body
body 
bon
bou
bour
bout
bout 
bout t
bout th
bout the
br
bra
bre
brea
bread
bread 
bro
broken
broken 
broth
bs
bu
buil
build
bur
burn
burni
burning
burning 
but
but 
but h
but he
but he 
but i
but t
but th
but the
but the 
but w
but y
but you
by
by 
by a
by h
by m
by t
by th
by the
by the 
by w
by y
ca
cam
came
came 
came a
came b
came i
came in
came o
came t
came to
came to 
came to h
came to hi
cap
car
care
cat
cau
caus
cause
cause 
cause h
cause he
cause he 
cause o
cause of 
cause of t
cause of th
cause of the
cause of the 
cause t
cause th
cause the
cause the 
cause they 
cause y
cause you
cause you 
cc
cco
ccou
ccount
ce
ce 
ce a
ce b
ce be
ce f
ce i
ce in
ce in 
ce o
ce of
ce of 
ce of t
ce of th
ce of the
ce of the 
ce t
ce to
ce to 
ce w
ce wh
ce wi
ce,
ce, 
ce, a
ce, an
ce, and
ce, and 
ce.
ce;
ced
cer
cert
certain
certain 
certain t
certain th
ces
ces 
ch
ch 
ch I
ch I 
ch a
ch ar
ch are
ch are 
ch h
ch ha
ch he
ch he 
ch i
ch is
ch is 
ch o
ch t
ch th
ch the
ch the 
ch the L
ch w
ch wa
ch was
ch was 
ch we
ch y
ch you
ch you 
ch,
ch, 
cha
chan
chang
change
che
ched
ched 
ched o
ched out
chi
chie
chief
chief 
chiefs
chiefs 
chil
child
children
children 
chin
ching
ching 
ci
cip
cipl
ciple
ciples
ciples 
circ
cis
cisi
cision
cision 
ck
ck 
ck a
ck f
ck from 
ck o
ck t
ck to
ck to 
ck,
ck, 
ckl
cks
cks 
cl
cle
clea
clean
clean 
clo
cloth
clou
cloud
co
com
come
come 
come a
come b
come f
come i
come in
come o
come on
come ou
come t
come to
come to 
come u
come w
come,
come, 
comes
coming
coming 
comp
compl
con
cond
cont
contr
contro
cor
cord
corde
corded
cou
coun
count
count 
countr
country
country 
cove
cover
covere
covered
covered 
cr
cre
crea
creas
crease
cret
cri
cro
cross
cru
crus
crush
crushe
crushed
cry
cry 
ct
ct 
cti
ction
ction 
ction o
ction of
ction of 
cts
cu
cur
curs
curse
cut
cut 
cut o
cutt
cutting
cutting 
cy
cy 
d A
d Ab
d B
d D
d Da
d David
d David 
d E
d G
d Go
d God
d God 
d H
d I
d I 
d I s
d I sa
d I w
d I wi
d I will 
d J
d Je
d Jes
d Jesus
d Jesus 
d Jo
d M
d Mo
d Mos
d Moses
d P
d S
d Sa
d Sh
d Z
d a
d a 
d ab
d abo
d abou
d about
d about 
d af
d after
d after 
d ag
d aga
d again
d against 
d al
d all
d all 
d all t
d all th
d all the
d all the 
d an
d and
d and 
d and t
d and th
d and the
d and the 
d ar
d are
d are 
d as
d as 
d at
d at 
d at t
d at th
d at the
d at the 
d aw
d awa
d away
d away 
d b
d be
d be 
d bec
d beca
d bee
d been
d been 
d bef
d before
d before 
d by
d by 
d by t
d by th
d by the
d by the 
d c
d ca
d came
d came 
d came t
d came to
d came to 
d co
d com
d come
d come 
d cr
d d
d da
d de
d di
d do
d do 
d e
d ev
d eve
d ever
d every
d f
d fa
d fi
d fo
d for
d for 
d for t
d for th
d for the
d for the 
d fr
d fro
d from 
d from t
d from th
d from the
d from the 
d g
d ga
d gave
d gave 
d ge
d get
d gi
d giv
d give
d give 
d given
d given 
d go
d go 
d gr
d h
d ha
d had
d had 
d has
d hav
d have
d have 
d he
d he 
d he g
d he s
d he sa
d he sai
d he said
d he said 
d he said t
d he said to 
d he said,
d he said, 
d he t
d he to
d he took 
d he w
d he wa
d he was
d he was 
d he wi
d he will 
d her
d hi
d his
d his 
d his s
d ho
d i
d if
d if 
d in
d in 
d in a
d in h
d in t
d in th
d in the
d in the 
d is
d is 
d is t
d it
d it 
d it w
d it wi
d its
d k
d ke
d keep
d l
d le
d let
d let 
d li
d m
d ma
d mad
d made
d made 
d mak
d make
d make 
d me
d men
d mo
d my
d my 
d n
d ne
d new
d news
d news 
d no
d no 
d not
d not 
d not g
d now
d o
d of
d of 
d of E
d of Egypt
d of I
d of Is
d of Israel
d of a
d of h
d of t
d of th
d of the
d of the 
d of the L
d of the Lord
d of the Lord 
d off
d offe
d offer
d offering
d on
d on 
d on t
d on th
d on the
d on the 
d one
d one 
d or
d or 
d ou
d our
d our 
d out
d out 
d over
d p
d pu
d put
d put 
d put i
d put t
d put th
d put the
d r
d s
d sa
d sai
d said
d said 
d said t
d said to 
d said to h
d said to hi
d said to him
d said,
d said, 
d say
d se
d see
d sen
d sent
d sent 
d sh
d she
d she 
d so
d so 
d st
d t
d ta
d tak
d take
d take 
d taken
d th
d tha
d that
d that 
d the
d the 
d the L
d the Lo
d the Lord
d the Lord 
d the Lord s
d the Lord sa
d the a
d the b
d the c
d the ch
d the chi
d the child
d the children
d the children 
d the d
d the f
d the g
d the h
d the k
d the ki
d the kin
d the king
d the king 
d the l
d the m
d the o
d the p
d the pe
d the people
d the pr
d the r
d the s
d the so
d the t
d the w
d the wo
d their
d their 
d there
d there 
d there w
d they
d they 
d they s
d they sa
d they w
d they we
d they wi
d they will 
d thi
d this
d this 
d tho
d those 
d those w
d those wh
d to
d to 
d to M
d to Mo
d to Moses
d to h
d to hi
d to him
d to him,
d to him, 
d to his
d to his 
d to m
d to me
d to me,
d to me, 
d to t
d to th
d to the
d to the 
d to them
d to them,
d to them, 
d to you
d too
d took
d took 
d tw
d u
d un
d up
d up 
d w
d wa
d was
d was 
d we
d we 
d went
d went 
d wh
d what
d whe
d when
d when 
d when h
d when he
d when he 
d when t
d when th
d when the
d when the 
d whi
d which
d which 
d who
d who 
d wi
d wil
d will
d will 
d will b
d will be
d will be 
d wit
d with
d with 
d with t
d with th
d with the
d wo
d wor
d y
d yo
d you
d you 
d you a
d you w
d you wi
d your
d your 
d your God
d your God 
d's
d's 
d,
d, 
d, G
d, I
d, I 
d, T
d, Th
d, The
d, W
d, Wh
d, a
d, an
d, and
d, and 
d, and h
d, and t
d, and th
d, and the
d, and the 
d, b
d, bu
d, but 
d, f
d, h
d, i
d, o
d, s
d, t
d, th
d, the
d, the 
d, the G
d, the God
d, the God of 
d, w
d, wh
d, who
d, who 
d-
d.
d. 
d:
d: 
d: a
d;
d; 
d; a
d; an
d; and
d; and 
d?
d? 
da
dah
dah 
dah a
dah,
dah, 
dan
dar
dau
day
day 
day o
day of
day of 
day w
day,
day, 
day.
dd
de
de 
de a
de a 
de an
de an 
de c
de f
de h
de hi
de i
de m
de o
de of
de of 
de s
de t
de th
de the
de the 
de w
de,
de, 
de.
dea
dec
ded
ded 
ded i
ded in
dee
del
den
der
der 
der t
der th
der the
der the 
deri
dering
ders
ders 
ders t
ders to
ders to 
des
dest
dg
dge
dge 
dge o
dge of
dge of 
dge of t
dge of th
dge of the
dge of the 
di
did
did 
din
ding
ding 
dis
disc
discipl
disciple
disciples
dise
disease
dit
dl
dle
do
do 
do t
do th
do the
doe
doer
does
doing
doing 
dom
dom 
dom o
dom of 
don
done
done 
done t
door
dow
down
down 
dr
dre
dri
drin
drink
dry
ds
ds 
ds a
ds an
ds and 
ds o
ds of
ds of 
ds of t
ds of th
ds of the
ds of the 
ds t
ds w
ds,
ds, 
ds, a
ds, an
ds, and 
ds.
ds;
du
dus
dust
dy
dy 
e A
e C
e Ch
e E
e G
e Go
e God
e God 
e God o
e H
e Ho
e I
e I 
e Is
e Israel
e J
e Je
e Jew
e Jews
e L
e Le
e Levi
e Levit
e Levite
e Levites
e Lo
e Lor
e Lord
e Lord 
e Lord a
e Lord o
e Lord of 
e Lord,
e Lord, 
e Lord, a
e Lord, an
e Lord, and 
e Lord.
e Lord:
e Lord;
e M
e P
e Ph
e Phil
e Phili
e Philisti
e Philistine
e Philistines
e R
e S
e Sa
e So
e T
e Te
e a
e a 
e a c
e a f
e a l
e a m
e a p
e a s
e ab
e abo
e abou
e about
e about 
e ag
e again
e against 
e al
e all
e all 
e all t
e all th
e alt
e altar
e am
e amo
e among
e among 
e an
e an 
e an a
e an o
e and
e and 
e and t
e and th
e and the
e and the 
e ang
e ange
e angel
e ano
e another
e answer
e ar
e are
e are 
e are t
e are th
e are the
e are the 
e arm
e army
e as
e as 
e at
e at 
e att
e aw
e awa
e away
e away 
e b
e ba
e back
e back 
e back t
e be
e be 
e bea
e bec
e beca
e bee
e been
e been 
e bef
e before
e before 
e bes
e best
e bi
e bir
e bl
e blo
e bo
e bod
e br
e bro
e broken
e bu
e bur
e burn
e burne
e burned
e burned 
e by
e by 
e c
e ca
e cam
e came
e came 
e came t
e came to
e came to 
e capt
e captain
e car
e care
e care 
e ce
e cer
e cert
e certain
e certain 
e ch
e chi
e chief
e chief 
e child
e children
e children 
e children o
e children of 
e children of I
e children of Is
e children of Israel
e children of Israel,
e cl
e cle
e clea
e clear
e clear 
e clo
e co
e com
e come
e come 
e cou
e coun
e count
e countr
e cove
e cover
e cr
e cru
e cu
e cut
e cut 
e d
e da
e dau
e daughter
e day
e day 
e day o
e day of 
e days
e days 
e de
e dea
e dead
e des
e desi
e di
e did
e did 
e dis
e do
e done
e done 
e door
e dow
e down
e down 
e dr
e e
e ea
e ear
e ear 
e ear t
e ear to
e ear to 
e ear to th
e earth
e earth 
e earth,
e earth, 
e earth.
e eas
e east
e en
e end
e end 
e ev
e eve
e evi
e evil
e evil 
e eye
e eyes
e eyes 
e eyes o
e f
e fa
e fac
e fai
e faith
e fal
e false
e fam
e fami
e famil
e fat
e father
e father 
e fe
e fea
e fear
e fi
e fie
e field
e fig
e fight
e fir
e fire
e first
e first 
e fl
e fle
e flesh
e flo
e fo
e foo
e food
e food 
e for
e for 
e for h
e for t
e for th
e for the
e for the 
e for you
e fou
e four
e fr
e fre
e fro
e from
e from 
e from t
e from th
e from the
e from the 
e fu
e ful
e full
e full 
e full o
e full of 
e g
e ga
e gave
e gave 
e gave t
e gave th
e gi
e giv
e give
e given
e given 
e given t
e gl
e gla
e glad
e glor
e glory
e glory 
e go
e gone
e gone 
e good
e good 
e got
e gr
e gra
e gre
e great
e great 
e h
e ha
e had
e had 
e han
e hand
e hands
e hands 
e hands o
e hands of 
e has
e hav
e have
e have 
e he
e he 
e he w
e hea
e head
e hear
e heart
e heav
e heave
e heaven
e her
e her 
e hi
e high
e high 
e hill
e him
e him 
e him a
e his
e his 
e ho
e hol
e holy
e holy 
e hor
e hou
e house
e house 
e house o
e house of 
e house of th
e house of the
e house of the 
e hu
e i
e in
e in 
e in a
e in h
e in t
e in th
e in the
e in the 
e int
e into
e into 
e into t
e into th
e into the
e into the 
e is
e is 
e is a
e is a 
e is n
e is no
e is no 
e is t
e it
e it 
e j
e jo
e ju
e judg
e judge
e k
e ke
e kept
e kept 
e ki
e kin
e king
e king 
e king o
e king of 
e king,
e king, 
e kingdom
e kingdom 
e kings
e kings 
e kn
e kno
e know
e knowledge
e knowledge 
e knowledge of
e knowledge of 
e l
e la
e lan
e land
e land 
e land o
e land of 
e land of E
e land w
e land,
e land, 
e law
e law 
e le
e li
e lif
e life
e lift
e light
e lik
e like
e like 
e liv
e living
e living 
e living i
e living in
e living in 
e lo
e low
e m
e ma
e mad
e made
e made 
e made a
e made t
e mak
e make
e man
e man 
e man w
e man wh
e may
e may 
e me
e me 
e mea
e men
e men 
e men o
e men of 
e mi
e mo
e mon
e mor
e mou
e mount
e mountain
e my
e my 
e n
e na
e name
e name 
e nat
e nation
e nations
e nations 
e ne
e near
e near 
e new
e ni
e no
e no 
e no f
e not
e not 
e not t
e nu
e number
e o
e of
e of 
e of G
e of Go
e of God
e of J
e of a
e of h
e of hi
e of his
e of his 
e of i
e of it
e of m
e of my
e of my 
e of s
e of t
e of th
e of the
e of the 
e of the L
e of the Lord
e of the Lord 
e of the s
e of them
e of w
e of y
e of you
e of your
e of your 
e off
e offe
e offer
e offering
e ol
e on
e on 
e on h
e on t
e on th
e on the
e on the 
e one
e one 
e op
e ope
e open
e open 
e or
e ord
e order
e other
e other 
e ou
e out
e out 
e out o
e out of 
e ove
e over
e p
e pa
e pe
e people
e people 
e people o
e people of
e people of 
e people w
e people,
e people, 
e pl
e pla
e plac
e place
e place 
e po
e poo
e poor
e pow
e power
e power 
e pr
e pra
e prais
e praise
e praise 
e pri
e priest
e priest 
e priests
e priests 
e pro
e prop
e prophe
e prophet
e prophets
e pu
e pur
e purp
e purpos
e put
e put 
e put t
e put to
e put to 
e put to de
e put to death
e qu
e r
e re
e rea
e read
e ready
e ready 
e res
e resp
e rest
e rest 
e rest o
e ri
e right
e right 
e ro
e ru
e rul
e rule
e ruler
e s
e sa
e sai
e said
e said 
e said t
e said to 
e said to h
e said to th
e said to the
e said to them
e said,
e said, 
e same
e same 
e saw
e saw 
e say
e se
e sea
e seat
e sec
e see
e seen
e seen 
e sen
e sent
e sent 
e ser
e serv
e servant
e servants
e servants 
e seve
e seven
e sh
e sha
e she
e sheep
e si
e side
e sin
e so
e son
e son 
e son o
e son of 
e sons
e sons 
e sons o
e sons of 
e sou
e sound
e sp
e spi
e st
e sto
e str
e stre
e stro
e strong
e strong 
e su
e sw
e swo
e swor
e sword
e t
e ta
e tak
e take
e taken
e taken 
e te
e ten
e tent
e th
e tha
e than
e than 
e that
e that 
e the
e the 
e the L
e the Lord
e the Lord 
e the c
e the f
e the h
e the l
e the p
e the s
e the t
e the w
e the wo
e their
e their 
e them
e them 
e there
e there 
e they
e they 
e thi
e thin
e thing
e things
e things 
e things w
e things wh
e things whi
e things which
e things which 
e thir
e this
e this 
e tho
e thou
e thr
e ti
e tim
e time
e time 
e to
e to 
e to a
e to an
e to b
e to be
e to be 
e to d
e to do
e to g
e to give
e to give 
e to go
e to h
e to hi
e to him
e to his 
e to m
e to ma
e to make
e to make 
e to me
e to s
e to t
e to th
e to the
e to the 
e to the L
e to y
e to yo
e to you
e together
e together 
e too
e took
e took 
e tow
e town
e town 
e towns
e towns 
e tr
e tri
e trib
e tribe
e tru
e true
e tu
e tur
e turn
e turne
e turned
e turned 
e tw
e two
e two 
e u
e un
e unc
e uncl
e uncle
e unclean
e und
e unde
e under
e up
e up 
e up t
e upr
e upri
e upright
e upright 
e us
e us 
e use
e v
e va
e val
e valley
e ve
e vi
e vo
e voi
e voice
e voice 
e w
e wa
e wal
e wall
e war
e was
e was 
e was a
e was a 
e was n
e was no
e was t
e wast
e waste
e waste 
e wat
e water
e waters
e way
e way 
e we
e we 
e went
e went 
e were
e were 
e wh
e whe
e when
e when 
e whi
e which
e which 
e who
e who 
e who a
e who are 
e who h
e who ha
e who i
e who is 
e who w
e who we
e who were 
e wi
e wil
e will
e will 
e will b
e will be
e will be 
e will g
e will n
e will no
e win
e wis
e wise
e wit
e with
e with 
e with h
e with hi
e with t
e with th
e with you
e without
e without 
e wo
e wom
e woman
e wor
e word
e word 
e word o
e word of 
e word of t
e word of th
e word of the
e word of the 
e words
e words 
e words o
e words of 
e words of t
e words of th
e work
e work 
e work o
e work of 
e world
e wors
e worship
e wou
e wr
e y
e ye
e yea
e year
e yo
e you
e you 
e you a
e you h
e you t
e young
e young 
e your
e your 
e,
e, 
e, I
e, I 
e, I w
e, a
e, an
e, and
e, and 
e, and h
e, and t
e, and th
e, and the
e, and the 
e, b
e, be
e, bu
e, but
e, but 
e, f
e, fo
e, h
e, he
e, he 
e, i
e, o
e, s
e, sa
e, say
e, so
e, so 
e, so th
e, t
e, th
e, the
e, the 
e, w
e, wh
e-
e.
e. 
e:
e: 
e: a
e: an
e: and
e: and 
e;
e; 
e; a
e; an
e; and
e; and 
e; t
e; th
e; the
e?
e? 
ea
ea 
ea,
ea, 
eac
eace
eace 
each
eaching
eaching 
ead
ead 
ead o
ead,
ead, 
ead.
eads
eady
eady 
eal
eal 
eal o
eal of
ealt
ealth
ealth 
eam
ean
ean 
ear
ear 
ear a
ear o
ear of
ear of 
ear of t
ear of th
ear of the
ear t
ear th
ear to
ear to 
ear to m
ear to t
ear to th
ear to the
ear to the 
ear to y
ear to you
ear,
ear, 
ear.
earch
eari
earin
earing
earing 
earl
early
ears
ears 
ears o
ears,
ears, 
eart
earth
earth 
earth,
earth, 
earth.
eas
ease
ease 
eased
easi
easing
easing 
eason
east
east 
easts
easts 
easur
easure
easure 
eat
eat 
eat a
eat n
eat o
eat w
eate
eated
eated 
eath
eath 
eath o
eath w
eath,
eath, 
eath.
eav
eave
eaven
eaven 
eaven,
eaven, 
eb
eba
ebu
ec
eca
ecam
ecame
ecame 
ecause
ecause 
ecause h
ecause he
ecause he 
ecause o
ecause of 
ecause of t
ecause of th
ecause of the
ecause of the 
ecause t
ecause th
ecause the
ecause they 
ecause y
ecause you
ece
ech
eci
ecision
eco
ecom
ecome
ecome 
econ
econd
econd 
ecor
ecr
ecre
ect
ect 
ecti
ection
ection 
ed
ed 
ed a
ed an
ed and
ed and 
ed and t
ed away
ed b
ed by
ed by 
ed by t
ed by th
ed by the
ed by the 
ed f
ed fo
ed for
ed for 
ed fr
ed from 
ed i
ed in
ed in 
ed in t
ed in th
ed in the
ed in the 
ed m
ed o
ed of
ed of 
ed off
ed offe
ed offer
ed on
ed on 
ed ou
ed out
ed out 
ed t
ed to
ed to 
ed u
ed up
ed up 
ed w
ed wi
ed wit
ed with
ed with 
ed,
ed, 
ed, a
ed, an
ed, and
ed, and 
ed.
ed;
ed; 
eda
ede
edg
edge
edge 
edge o
edge of
edge of 
edge of t
edge of th
edge of the
edge of the 
ee
ee 
ee f
ee fr
ee from 
ee h
ee t
ee th
ee tha
ee that
ee that 
ee the
ee the 
ee,
ee, 
ee, I
ee, I 
eed
eed 
eed o
eed of
eed of 
eel
eem
eeme
een
een 
een a
een m
een ma
een t
een th
een the
eep
eep 
eep i
eep t
eep th
eep the
eep,
eepe
eeper
eeping
eeping 
ees
ees 
eet
eet 
eeting
eeting 
ef
efo
efor
efore
efore 
efore h
efore hi
efore him
efore m
efore t
efore th
efore the
efore the 
efore the L
efore the Lord
efore y
efore you
eg
eh
eha
eho
ei
eig
eigh
eight
eight 
ein
eing
eing 
eir
eir 
eir b
eir d
eir t
eir w
ek
eki
ekia
ekiah
el
el 
el a
el an
el and 
el o
el s
el t
el w
el,
el, 
el, a
el, an
el, and
el, and 
el, t
el, th
el, the
el.
el;
ela
elat
elati
elation
eld
ele
elec
elf
elf 
elf,
elf, 
eli
ell
ell 
elp
els
els 
elve
ely
ely 
em
em 
em a
em an
em and
em and 
em b
em f
em i
em in
em in 
em o
em t
em th
em to
em to 
em w
em,
em, 
em, a
em, an
em, and
em, and 
em.
em:
em: 
em;
em; 
ema
eme
emen
ement
ement 
ement w
emi
emia
emiah
emo
emp
ems
en 
en I
en I 
en J
en a
en a 
en an
en and
en and 
en awa
en away
en b
en by 
en c
en d
en f
en fo
en fr
en from 
en g
en h
en he
en he 
en hi
en i
en in
en in 
en it
en it 
en l
en m
en ma
en me
en o
en of
en of 
en of I
en of Is
en of Israel
en of Israel 
en of Israel,
en of Israel, 
en of t
en of th
en of the
en p
en s
en t
en th
en the
en the 
en they
en they 
en to
en to 
en to t
en to th
en to the
en u
en up
en up 
en w
en we
en wh
en who
en who 
en wi
en y
en yo
en you
en you 
en,
en, 
en, a
en, an
en, and 
en, t
en.
en;
en; 
end
end 
end o
end of
end of 
end t
end to
end to 
ends
ends 
ene
ener
eng
ength
ength 
eni
enin
ening
enj
eno
enou
ens
ense
ent
ent 
ent a
ent away
ent b
ent d
ent do
ent down
ent down 
ent f
ent fo
ent for
ent for 
ent i
ent in
ent in 
ent m
ent o
ent of
ent of 
ent on
ent on 
ent ou
ent out
ent out 
ent t
ent th
ent to
ent to 
ent u
ent up
ent up 
ent w
ent wi
ent wit
ent with
ent with 
ent,
ent, 
enth
enth 
enti
entio
ention
ents
ents 
ents o
enty
enty 
eo
eon
eop
eople
eople 
eople w
eoples
eou
eous
ep
ep 
ep,
ep, 
epe
eper
eph
epi
eps
eps 
ept
ept 
equ
eque
equest
er 
er a
er an
er and
er and 
er b
er be
er c
er d
er f
er fo
er for
er for 
er g
er go
er h
er ha
er he
er hi
er him
er i
er in
er in 
er is
er is 
er l
er m
er o
er of
er of 
er of t
er of th
er of the
er of the 
er p
er s
er sa
er t
er th
er tha
er than 
er the
er the 
er them
er to
er to 
er to t
er to th
er to the
er w
er wa
er was
er wh
er wi
er y
er yo
er you
er's
er's 
er,
er, 
er, a
er, an
er, and
er, and 
er, t
er, th
er, the
er, w
er.
er:
er: 
er;
er; 
er; a
era
erat
eration
erc
erco
ercy
ercy 
ere
ere 
ere a
ere b
ere c
ere f
ere h
ere i
ere in
ere in 
ere is
ere is 
ere l
ere m
ere n
ere no
ere not
ere not 
ere o
ere p
ere s
ere t
ere th
ere the
ere the 
ere w
ere wa
ere was
ere was 
ere we
ere wi
ere wil
ere will
ere,
ere, 
ere.
ered
ered 
erf
eri
ering
ering 
ering o
ering t
ering,
ering, 
erings
erings 
erit
ern
erna
ero
ers
ers 
ers a
ers an
ers and 
ers i
ers o
ers of 
ers of t
ers of th
ers of the
ers of the 
ers t
ers to
ers to 
ers w
ers,
ers, 
ers, a
ers, an
ers, and 
ers, t
ers.
ers;
ers; 
ert
erta
ertain
ertain 
ertain t
ertak
erty
eru
erus
erv
erva
ervant
ervants
ervants 
ery
ery 
ery o
ery s
es 
es a
es an
es and
es and 
es and t
es and th
es and the
es and the 
es ar
es are
es are 
es b
es be
es c
es f
es fo
es for
es for 
es fr
es h
es ha
es i
es in
es in 
es in t
es m
es n
es no
es not
es not 
es o
es of
es of 
es of t
es of th
es of the
es of the 
es on
es on 
es s
es sa
es t
es th
es the
es to
es to 
es u
es w
es we
es were
es were 
es wh
es wi
es will
es will 
es,
es, 
es, a
es, an
es, and
es, and 
es, t
es, th
es, the
es, the 
es, w
es.
es:
es: 
es;
es; 
ese
ese 
esh
esh 
esi
esig
esir
esire
esire 
esp
espo
ess
ess 
ess,
ess, 
esse
essel
essels
essi
essing
essing 
est
est 
est o
est of
est of 
est of t
est of th
est of the
est of the 
est t
est w
est,
est, 
esti
estin
esting
estion
estr
estruction
estruction 
ests
ests 
esu
esus
esus 
esus s
esus sa
esus,
esus, 
et
et 
et a
et h
et hi
et him
et him 
et i
et it
et it 
et m
et me
et n
et no
et o
et t
et th
et the
et the 
et them
et them 
et u
et us
et us 
et w
et y
et you
et your
et your 
et,
et, 
etch
etche
etched
etched 
ete
eter
eth
ethe
ether
ether 
eti
eting
eting 
ets
ets 
ett
ette
etter
etter 
etw
etween
etween 
ev
eve
even
even 
even t
even th
event
ever
ever 
ever.
every
evi
evil
evil 
evit
evite
evites
ew
ew 
ewa
ewar
eward
ews
ews 
ews o
ews of
ews of 
ex
ey
ey 
ey a
ey c
ey ca
ey came
ey came 
ey d
ey g
ey ga
ey gave
ey gave 
ey h
ey ha
ey have
ey have 
ey m
ey ma
ey p
ey s
ey sa
ey t
ey to
ey took
ey took 
ey w
ey we
ey went
ey went 
ey were
ey were 
ey wi
ey will
ey will 
ey will be
ey will be 
eye
ez
eze
f A
f As
f B
f Ba
f Babylon
f Be
f C
f D
f Da
f David
f E
f G
f Go
f God
f God 
f God,
f God, 
f God.
f H
f Ha
f I
f Is
f Israel
f Israel 
f J
f Ja
f Je
f Jer
f Jeru
f Jerusalem
f Jo
f Ju
f Jud
f Juda
f Judah
f Judah,
f Judah, 
f K
f M
f Ma
f Mo
f N
f P
f S
f Sh
f Z
f a
f a 
f a m
f a ma
f a man
f al
f all
f all 
f all t
f all th
f all the
f all the 
f an
f any
f ar
f b
f c
f d
f de
f e
f ev
f f
f fo
f fr
f g
f go
f gr
f h
f he
f hea
f heav
f heaven
f hi
f him
f his
f his 
f i
f it
f it 
f l
f li
f m
f ma
f man
f me
f men
f my
f my 
f n
f o
f on
f ou
f our
f our 
f p
f pe
f pr
f pri
f r
f s
f si
f t
f th
f the
f the 
f the L
f the Lord
f the Lord 
f the Lord c
f the Lord w
f the a
f the b
f the c
f the ch
f the chi
f the child
f the children
f the children 
f the children of 
f the d
f the e
f the ea
f the ear
f the earth
f the f
f the fi
f the g
f the h
f the ho
f the hou
f the house
f the house 
f the k
f the ki
f the kin
f the king
f the l
f the la
f the lan
f the land
f the land 
f the m
f the n
f the o
f the p
f the pe
f the people
f the pr
f the r
f the s
f the se
f the so
f the son
f the t
f the to
f the tow
f the town
f the w
f the wa
f the wo
f their
f their 
f them
f them 
f thi
f this
f this 
f tho
f those 
f those w
f those wh
f those who
f u
f w
f wa
f war
f we
f wh
f what
f what 
f wi
f wo
f y
f you
f you 
f your
f your 
f,
f, 
f.
fa
fac
face
fai
faith
fal
fall
falli
fam
far
far 
fat
fath
father
fathers
fathers 
fe
fe 
fe,
fe, 
fe.
fea
fear
feast
fect
fer
feri
ff
ff 
ffe
ffect
ffer
ffering
ffering 
fferings
fferings 
fi
fie
field
fift
fig
fir
fire
fire 
first
first 
five
five 
fl
fla
fle
flesh
fli
flo
flow
fo
foo
food
food,
food, 
for
for 
for I
for I 
for a
for al
for all
for all 
for h
for he
for he 
for hi
for his
for his 
for i
for it
for s
for t
for th
for the
for the 
for the L
for the Lord
for the p
for their
for their 
for they
for they 
for thi
for w
for y
for you
for your
for your 
forc
force
fore
fore 
fore h
fore t
fore th
fore the
fore the 
fort
fou
four
four 
fr
fre
fri
fro
from
from 
from t
from th
from the
fru
fruit
fruit 
fs
fs 
ft
fte
fted
fted 
fter
fter 
fter h
fter hi
fter t
fter th
fter the
fter the 
fu
ful
full
full 
full o
full of 
g 
g a
g a 
g an
g and
g and 
g and t
g b
g be
g c
g d
g do
g down
g down 
g f
g fo
g for
g for 
g for t
g fr
g fro
g from 
g g
g h
g ha
g hi
g his
g his 
g i
g in
g in 
g in t
g in th
g in the
g in the 
g is
g is 
g it
g it 
g l
g li
g m
g ma
g n
g o
g of
g of 
g of t
g of th
g of the
g of the 
g on
g on 
g on t
g on th
g on the
g on the 
g ove
g over
g over 
g p
g s
g t
g th
g the
g the 
g their 
g to
g to 
g to t
g to th
g to the
g to the 
g w
g wa
g wh
g whi
g which 
g wi
g wil
g will
g will 
g wit
g with
g with 
g y
g you
g you 
g your
g's
g's 
g,
g, 
g, a
g, an
g, and
g, and 
g, s
g, t
g-
g.
g:
g: 
g;
g; 
ga
gai
gain
gain 
gains
gainst
gainst 
gainst h
gainst hi
gainst him
gainst t
gainst th
gainst the
gainst the 
gainst you
gar
gard
garde
garden
gave
gave 
gave h
gave hi
gave him
gave him 
gave t
gave th
gave the
gave them
gave them 
gd
gdo
ge
ge 
ge o
ge of
ge of 
ge of t
ge of th
ge of the
ge of the 
ge t
ge,
ge, 
ge.
ged
ged 
gel
gen
gene
genera
generat
generation
ger
ger 
ges
ges 
get
get 
get t
geth
gh
gh 
gh a
gh p
gh t
gh th
gh the
gh the 
ght
ght 
ght a
ght b
ght be
ght be 
ght f
ght h
ght i
ght in
ght in 
ght o
ght of
ght of 
ght t
ght to
ght to 
ght w
ght,
ght, 
ght.
ghte
ghter
ghter 
ghters
ghti
ghtin
ghts
gi
gin
ging
ging 
giv
give
give 
give a
give e
give h
give hi
give him
give m
give me
give me 
give t
give th
give the
give them
give them 
give u
give y
give you
give you 
given
given 
given t
given th
given the
given u
giving
giving 
gl
gla
glo
glor
glory
gn
go
go 
go a
go d
go i
go in
go in 
go t
go to
go to 
goa
goat
god
goe
goes
going
going 
gon
gone
gone 
got
got 
gr
gra
grac
grace
grace 
gre
grea
great
great 
gree
gri
gs
gs 
gs a
gs o
gs of
gs of 
gs t
gs to
gs w
gs wh
gs whi
gs which
gs which 
gs,
gs, 
gs.
gt
gth
gu
gue
gui
gus
gust
gy
h I
h I 
h a
h a 
h al
h all
h all 
h all t
h all th
h all the
h an
h and
h and 
h and t
h ar
h are
h are 
h b
h be
h c
h ca
h d
h da
h day
h f
h fo
h for
h for 
h g
h h
h ha
h had
h had 
h has
h he
h he 
h hi
h him
h him 
h his
h his 
h i
h in
h in 
h in t
h in th
h in the
h in the 
h is
h is 
h it
h m
h ma
h me
h mo
h o
h of
h of 
h of t
h of th
h of the
h of the 
h on
h p
h s
h sa
h sai
h said
h t
h th
h the
h the 
h the L
h the Lord
h the Lord 
h the p
h the s
h their
h their 
h them
h they
h they 
h to
h to 
h w
h wa
h was
h was 
h we
h were
h were 
h wh
h wi
h wil
h will
h will 
h wit
h with
h with 
h y
h you
h you 
h your
h your 
h,
h, 
h, a
h, an
h, and
h, and 
h, and t
h, b
h, s
h, t
h, th
h, the
h, the 
h, the s
h, the so
h, the son
h, the son of 
h, w
h, wh
h.
h. 
h:
h: 
h;
h; 
h; a
h; and
h; and 
h?
had
had 
had a
had b
had be
had s
had sa
had t
had th
had the
hai
hair
hak
haki
haking
hal
ham
hame
hame 
han
han 
han t
han th
han the
hand
hand 
hang
hange
hanging
hanging 
hap
har
hara
hard
hard 
has
has 
has b
has be
has t
hat
hat 
hat I
hat I 
hat I m
hat a
hat d
hat da
hat day
hat day 
hat h
hat he
hat he 
hat he w
hat i
hat is
hat is 
hat is t
hat it
hat it 
hat s
hat t
hat th
hat the
hat the 
hat the L
hat the Lord
hat the Lord 
hat the Lord h
hat the Lord ha
hat they
hat they 
hat they m
hat w
hat we
hat we 
hat wh
hat y
hat you
hate
hav
have
have 
have a
have h
have m
have t
have th
have the
have the 
havi
having 
haz
hb
hbo
he A
he C
he E
he G
he God
he God 
he God o
he God of 
he God of Is
he God of Israel
he H
he Ho
he J
he Je
he Jew
he Jews
he L
he Le
he Levit
he Levite
he Levites
he Lo
he Lord
he Lord 
he Lord a
he Lord c
he Lord ca
he Lord came 
he Lord g
he Lord h
he Lord ha
he Lord had 
he Lord i
he Lord is
he Lord is 
he Lord o
he Lord of 
he Lord s
he Lord sa
he Lord said
he Lord said 
he Lord t
he Lord w
he Lord wi
he Lord will
he Lord will 
he Lord y
he Lord you
he Lord your 
he Lord your God
he Lord your God 
he Lord's
he Lord's 
he Lord,
he Lord, 
he Lord, t
he Lord, th
he Lord, the
he Lord, the 
he M
he P
he Ph
he Philistine
he Philistines
he R
he S
he So
he T
he Te
he a
he al
he altar
he an
he ang
he ange
he angel
he ar
he ark
he ark 
he arm
he b
he ba
he be
he bes
he best
he best 
he bl
he bo
he br
he bu
he c
he ca
he cam
he came
he came 
he capt
he captain
he ch
he chi
he chief
he chief 
he child
he children
he children 
he children o
he children of 
he children of I
he children of Is
he children of Israel
he children of Israel 
he children of Israel,
he co
he cr
he cu
he d
he da
he dau
he daughter
he day
he day 
he day o
he day of 
he days
he days 
he de
he dea
he dead
he des
he di
he did
he dis
he do
he door
he e
he ea
he ear
he earth
he earth 
he earth,
he earth, 
he east
he en
he end
he ev
he evi
he evil
he evil 
he eye
he eyes
he eyes 
he eyes of 
he f
he fa
he fam
he fami
he famil
he fat
he father
he father 
he father of 
he fe
he fea
he fi
he fie
he field
he fig
he fir
he fire
he first
he first 
he fl
he fle
he flesh
he fo
he fou
he fr
he g
he ga
he gave
he gave 
he gave t
he gl
he go
he good
he good 
he gr
he gra
he gre
he great
he great 
he h
he ha
he had
he had 
he han
he hand
he hands
he hands 
he hands o
he hands of 
he has
he he
he hea
he head
he hear
he heart
he heav
he heave
he heaven
he hi
he high
he high 
he ho
he hol
he holy
he holy 
he hou
he house
he house 
he house o
he house of 
he house of th
he house of the
he house of the 
he i
he is
he is 
he k
he ki
he kin
he king
he king 
he king o
he king of 
he king's
he king's 
he king,
he kingdom
he kingdom 
he kings
he l
he la
he lan
he land
he land 
he land o
he land of 
he land of E
he land of Egypt
he land w
he law
he law 
he le
he li
he lo
he m
he ma
he mad
he made
he made 
he man
he man 
he man w
he me
he men
he men 
he men o
he men of 
he mi
he mo
he mor
he morning
he mou
he mount
he mountain
he n
he na
he name
he name 
he name of 
he nat
he nation
he nations
he nations 
he ne
he ni
he no
he o
he of
he off
he offe
he offer
he offering
he or
he ord
he order
he other
he other 
he p
he pa
he pe
he people
he people 
he people o
he people of
he people of 
he people w
he people,
he people, 
he pl
he pla
he place
he place 
he po
he poo
he poor
he pow
he power
he power 
he pr
he pri
he priest
he priest 
he priests
he priests 
he pro
he prop
he prophe
he prophet
he prophets
he pu
he put
he put 
he r
he re
he res
he rest
he rest 
he rest o
he rest of 
he rest of th
he ri
he right
he right 
he ro
he ru
he rule
he ruler
he s
he sa
he sai
he said
he said 
he said t
he said to 
he said to th
he said to the
he said to them
he said,
he said, 
he same
he same 
he se
he sea
he sec
he sen
he sent
he sent 
he ser
he serv
he servant
he seven
he sh
he si
he sin
he so
he son
he son 
he son of 
he son of A
he son of J
he sons
he sons 
he sons of 
he sou
he sp
he st
he sto
he str
he stre
he su
he sw
he sword
he t
he te
he ten
he tent
he th
he thi
he thin
he thing
he things
he things 
he thir
he ti
he tim
he time
he time 
he to
he took
he took 
he tow
he town
he town 
he towns
he towns 
he tr
he tri
he trib
he tribe
he tw
he two
he two 
he u
he un
he up
he upr
he upright
he v
he va
he val
he valley
he vi
he vo
he voice
he voice 
he voice o
he voice of 
he w
he wa
he wal
he wall
he was
he was 
he wast
he waste
he waste 
he wat
he water
he way
he way 
he we
he went
he went 
he wh
he who
he who 
he wi
he wil
he will
he will 
he will b
he will be
he will be 
he win
he wo
he wom
he wor
he word
he word 
he word o
he word of 
he word of t
he word of th
he word of the
he word of the 
he word of the L
he word of the Lord
he word of the Lord 
he words
he words 
he words of 
he work
he work 
he work o
he work of 
he world
he wr
he y
he yo
he you
he young
hea
head
head 
heads
hear
heari
hearing
hearing 
heart
heav
heave
hed
hed 
hed o
hed ou
hed out
hee
hei
heir
heir 
heir b
heir c
heir d
heir e
heir f
heir fa
heir g
heir h
heir ha
heir he
heir hea
heir l
heir p
heir r
heir s
heir t
heir w
hel
help
hem
hem 
hem a
hem an
hem b
hem f
hem i
hem in
hem in 
hem o
hem t
hem th
hem to
hem to 
hem w
hem,
hem, 
hem, a
hem, an
hem, and
hem, and 
hem.
hem:
hem;
hem; 
hems
hen
hen 
hen I
hen I 
hen J
hen a
hen h
hen he
hen he 
hen i
hen t
hen th
hen the
hen the 
hen they
hen they 
hen w
hen y
hen you
hen you 
hen, 
her
her 
her a
her an
her and
her and 
her b
her f
her h
her i
her in
her o
her of
her of 
her s
her t
her to
her w
her's
her's 
her,
her, 
her, a
her, an
her, and
her, and 
her.
her;
here
here 
here a
here i
here is
here is 
here is n
here is no
here is no 
here t
here th
here the
here w
here wa
here was
here was 
here we
here wi
here wil
here will 
here,
here, 
heri
herit
herita
hers
hers 
hers,
hers, 
hes
hese
hese 
hese a
hese are
hese are 
hese are t
hese are th
hese are the
hese are the 
hese t
hese th
hese thi
hese things
hese things 
hese w
hese wo
het
het 
hey
hey 
hey a
hey ar
hey are
hey are 
hey c
hey ca
hey came
hey came 
hey d
hey g
hey ga
hey gave
hey gave 
hey h
hey ha
hey had
hey had 
hey have
hey have 
hey m
hey ma
hey made
hey made 
hey may 
hey p
hey pu
hey put 
hey s
hey sa
hey sai
hey said
hey said 
hey t
hey to
hey took
hey took 
hey w
hey we
hey went
hey went 
hey were
hey were 
hey wi
hey will
hey will 
hey will be
hey will be 
hic
hich
hich 
hich I
hich I 
hich a
hich ar
hich are
hich are 
hich h
hich ha
hich he
hich he 
hich i
hich is
hich is 
hich t
hich th
hich the
hich the 
hich the L
hich the Lord
hich the Lord 
hich w
hich wa
hich was
hich was 
hich we
hich y
hich you
hie
hief
hief 
hig
high
high 
hil
hild
hildren
hildren 
hile
hile 
hili
hill
him
him 
him a
him an
him and
him and 
him b
him,
him, 
him, a
him, an
him, and
him, and 
him.
him;
him; 
hims
hin
hing
hing 
hing a
hing i
hing o
hing t
hing th
hing to
hing to 
hing w
hing,
hing, 
hings
hings 
hings w
hings wh
hings whi
hings which
hings which 
hings,
hip
hip 
hir
hirt
hirty
his
his 
his a
his b
his bo
his br
his bro
his c
his ca
his cause
his d
his da
his day
his de
his e
his f
his fa
his fat
his g
his h
his ha
his hand
his he
his hea
his ho
his hou
his house
his i
his is
his is 
his is t
his is th
his is the
his is the 
his is w
his l
his la
his li
his m
his mo
his n
his o
his p
his pe
his people
his pl
his pla
his place
his place 
his r
his re
his s
his se
his ser
his serv
his servant
his si
his so
his son
his t
his w
his wa
his way
his wi
his wo
his wor
his word
his,
his, 
hit
hite
hm
hme
hmen
hment
hn
ho
ho 
ho a
ho ar
ho are 
ho c
ho g
ho h
ho ha
ho had 
ho has
ho hav
ho have 
ho i
ho is 
ho m
ho ma
ho s
ho t
ho w
ho wa
ho was
ho was 
ho we
ho were 
hoe
hol
hole
holy
holy 
hom
hom 
hom t
hom th
hom the
hon
hono
honour
honour 
hop
hor
hori
horn
hors
horse
hos
hose
hose 
hose w
hose wh
hose who
hose who 
hose who w
hose who we
hose who were 
hou
hough
hough 
hous
house
house 
house o
house of 
house of th
house of the
house of the 
house of the L
house,
house, 
house.
houses
hout
hout 
how
how 
hr
hra
hrai
hre
hree
hree 
hri
hrist
hrist 
hro
hrou
hrough
hrough 
hrough a
hrough t
hrough th
hrough the
hrough the 
hs
ht
ht 
ht a
hte
hter
hti
hu
hua
hun
hund
hur
hus
hut
hy
hy 
i 
i,
i, 
ia
ia,
ia, 
iah
iah 
iah,
iah, 
iah, t
iah, th
iah, the 
iah, the s
iah, the son
iah, the son of 
ian
ib
ibe
ibes
ibl
ible
ible 
ible f
ic
ice
ice 
ice o
ice of 
ich
ich 
ich a
ich h
ich ha
ich he
ich he 
ich i
ich t
ich th
ich the
ich the 
ich w
ick
ickl
ickly
ickly 
id
id 
id a
id i
id in
id in 
id n
id no
id not
id not 
id s
id t
id th
id to
id to 
id to M
id to h
id to hi
id to him
id to m
id to me
id to th
id to the
id to the 
id to them
id w
id,
id, 
id, I
id, I 
id, T
id, Th
id, W
id, Wh
id.
id:
id: 
idd
ide
ide 
ide o
ide of 
ide t
ide,
ide, 
ie
ief
ief 
iefs
iefs 
iel
ield
ien
ies
ies 
ies o
ies of 
ies,
ies, 
iest
iest 
iet
if
if 
if t
if th
ife
ife 
ife,
ife, 
ife.
ift
ifte
ifted
ifted 
ig
igh
igh 
igh p
ight
ight 
ight a
ight b
ight be
ight be 
ight f
ight h
ight ha
ight i
ight in
ight o
ight t
ight to
ight to 
ight w
ight,
ight, 
ight.
ighte
ighteous
ighteousness
ighteousness 
ighti
ighting
ign
ign 
ij
ija
ijah
ik
ike
ike 
ike a
ike a 
ike t
ike th
ike the
ike the 
il
il 
il a
il o
il w
il,
il, 
ild
ild 
ildi
ile
ile 
ili
ilies
ilis
ill
ill 
ill b
ill be
ill be 
ill be a
ill be f
ill be l
ill be m
ill be t
ill be th
ill be the
ill be w
ill c
ill co
ill com
ill come
ill d
ill do
ill g
ill give
ill give 
ill give t
ill go
ill go 
ill h
ill ha
ill hav
ill have
ill have 
ill k
ill ke
ill keep
ill keep 
ill l
ill m
ill ma
ill mak
ill make
ill make 
ill n
ill no
ill not
ill not 
ill not b
ill not be
ill not g
ill p
ill s
ill sa
ill say
ill se
ill see
ill t
ill ta
ill th
ill the
ill the 
ill y
ill you
ill you 
illa
ilv
ilver
ilver 
ily
ily 
ily o
im
im 
im a
im an
im and
im and 
im b
im i
im in
im in 
im o
im t
im th
im the
im to
im to 
im w
im wh
im who
im who 
im,
im, 
im, a
im, an
im, and
im, and 
im.
im;
im; 
ima
imag
image
ime
ime 
ime,
ime, 
imes
imes 
ims
imself
imself 
in 
in J
in Je
in Jer
in Jerusalem
in a
in a 
in al
in all
in all 
in an
in and
in and 
in answer
in b
in c
in d
in e
in f
in fl
in fr
in fro
in g
in h
in he
in hea
in hi
in him
in his 
in i
in it
in m
in me
in mi
in min
in my
in my 
in n
in o
in of
in of 
in of t
in of th
in p
in s
in t
in th
in that
in that 
in the
in the 
in the b
in the d
in the da
in the day
in the e
in the f
in the h
in the ho
in the hou
in the house
in the m
in the p
in the s
in the t
in the w
in the wa
in the waste
in the waste 
in their 
in thi
in this
in this 
in to
in to 
in w
in wh
in whi
in which
in which 
in y
in you
in your
in your 
in,
in, 
in, a
in, an
in, and
in, and 
in.
in;
inc
ind
ind 
ine
ine 
ined
ined 
ines
ines 
ing
ing 
ing a
ing a 
ing ag
ing again
ing against 
ing an
ing and
ing and 
ing b
ing be
ing c
ing d
ing do
ing down
ing down 
ing f
ing fo
ing for
ing for 
ing for t
ing fr
ing fro
ing from 
ing g
ing h
ing hi
ing him
ing him 
ing his
ing his 
ing i
ing in
ing in 
ing in t
ing in th
ing in the
ing in the 
ing it
ing it 
ing l
ing m
ing ma
ing me
ing n
ing o
ing of
ing of 
ing of J
ing of t
ing of th
ing of the
ing of the 
ing on
ing on 
ing on t
ing on th
ing on the
ing ou
ing out
ing out 
ing ove
ing over
ing over 
ing p
ing s
ing t
ing th
ing the
ing the 
ing them
ing them 
ing thi
ing to
ing to 
ing to t
ing to th
ing to the
ing to the 
ing u
ing up
ing up 
ing w
ing wa
ing wh
ing whi
ing which 
ing wi
ing wit
ing with
ing with 
ing y
ing you
ing you 
ing's
ing's 
ing,
ing, 
ing, a
ing, an
ing, and
ing, and 
ing, s
ing, t
ing-
ing.
ing:
ing: 
ing;
ing; 
ingdom
ings
ings 
ings a
ings o
ings of
ings of 
ings t
ings w
ings wh
ings whi
ings which
ings which 
ings,
ings, 
ings.
ini
ining
ining 
ink
inn
inne
inner
ins
ins 
ins o
ins of 
inst
int
into
into 
io
iol
iolen
iolent
ion
ion 
ion a
ion i
ion o
ion of
ion of 
ion of t
ion of th
ion of the
ion of the 
ion t
ion to
ion to 
ion to t
ion w
ion,
ion, 
ion, a
ion.
ions
ions 
ions w
ions,
ions, 
iou
ip
ip 
ipl
ipp
ips
ir
ir 
ir b
ir c
ir d
ir e
ir f
ir fa
ir g
ir h
ir ha
ir he
ir hea
ir l
ir p
ir r
ir s
ir t
ir w
irc
ird
ird 
ire
ire 
ire t
ire to 
iri
irit
irs
irst
irst 
irt
irth
irth 
irty
is
is 
is a
is a 
is an
is b
is be
is bo
is br
is bro
is brother
is c
is ca
is cause
is co
is d
is da
is day
is de
is dea
is di
is e
is f
is fa
is fat
is fo
is g
is go
is gr
is h
is ha
is han
is hand
is he
is hea
is ho
is hou
is house
is i
is in
is in 
is is
is is 
is is t
is is th
is is the
is is the 
is l
is la
is li
is lif
is m
is ma
is mo
is my
is my 
is n
is na
is name
is ne
is no
is not
is not 
is o
is of
is on
is p
is pe
is pl
is pla
is place
is r
is re
is rea
is ri
is right
is s
is se
is ser
is serv
is servant
is servants
is si
is so
is son
is sons
is st
is t
is th
is the
is the 
is to
is to 
is to b
is to be
is to be 
is tr
is u
is un
is w
is wa
is way
is wh
is wi
is wo
is wor
is word
is y
is yo
is you
is your
is your 
is,
is, 
isc
isci
isd
isdom
isdom 
ise
ise 
ise t
ise to
ise to 
isg
ish
ish 
ishm
ishment
ishment 
isi
ision
ision 
isions
iso
ison
isone
ist
ist 
iste
isti
istin
it
it 
it a
it an
it and 
it b
it be
it c
it ca
it f
it h
it ha
it i
it in
it in 
it is
it is 
it is t
it m
it o
it of
it of 
it s
it t
it to
it to 
it w
it wa
it was
it was 
it wi
it will
it will 
it will b
it will be
it will be 
it,
it, 
it, a
it, an
it, and
it, and 
it.
it;
it; 
ita
ite
ite 
ite,
ites
ites 
ites,
ites, 
ith
ith 
ith a
ith a 
ith al
ith all 
ith c
ith f
ith h
ith hi
ith him
ith him 
ith his
ith his 
ith i
ith in
ith in 
ith m
ith me
ith s
ith t
ith th
ith the
ith the 
ith their
ith their 
ith w
ith y
ith you
itho
ithout
ithout 
iti
iting
iting 
itio
ition
ition 
itn
itness
its
its 
its o
itt
itte
itter
itter 
ittle
ittle 
ity
ity 
iv
ive
ive 
ive a
ive e
ive ear
ive ear 
ive ear t
ive ear to
ive ear to 
ive h
ive hi
ive him
ive him 
ive m
ive me
ive me 
ive p
ive t
ive th
ive the
ive the 
ive them
ive them 
ive u
ive w
ive y
ive yo
ive you
ive you 
iven
iven 
iven t
iven th
iven the
iven to
iven to 
iven u
iver
ives
ives 
ivi
ivin
iving
iving 
iving i
iving in
iving in 
iving in t
iving in th
iving t
iving th
ix
ix 
ixed
ixed 
j
ja
jah
jam
jami
jamin
jo
joy
joy 
ju
jud
judg
judge
k
k 
k a
k an
k and 
k f
k fr
k from 
k h
k hi
k i
k o
k of
k of 
k of t
k of th
k of the
k of the 
k on
k on 
k t
k th
k the
k the 
k to
k to 
k w
k wi
k,
k, 
k, a
k, an
k, and
k, and 
k.
k;
ke
ke 
ke a
ke a 
ke an
ke an 
ke away
ke away 
ke c
ke f
ke h
ke hi
ke him
ke i
ke it
ke it 
ke m
ke me
ke n
ke no
ke o
ke p
ke s
ke t
ke th
ke the
ke the 
ke them
ke them 
ke u
ke w
ke y
ke yo
ke you
ke you 
ke your
ke your 
ked
ked 
keep
keep 
keepe
keeper
ken
ken 
ken a
ker
kers
kes
kes 
kes a
ki
kia
kiah
kin
king
king 
king a
king f
king fo
king for
king for 
king i
king in
king in 
king o
king of
king of 
king of J
king s
king t
king th
king the
king w
king,
king, 
kings
kings 
kings o
kl
kly
kly 
kn
kno
know
knowledg
knowledge
knowledge 
knowledge o
knowledge of
knowledge of 
ks
ks 
ks o
l 
l I
l a
l an
l and 
l b
l be
l be 
l be a
l be c
l be f
l be g
l be m
l be o
l be s
l be t
l be th
l be the
l be w
l c
l co
l com
l come
l come 
l come t
l come to
l come to 
l d
l do
l f
l fo
l for
l for 
l g
l ge
l get
l get 
l gi
l giv
l give
l give 
l give t
l give y
l give you
l give you 
l go
l go 
l h
l ha
l hav
l have
l have 
l he
l he 
l hi
l his
l his 
l i
l in
l in 
l k
l ke
l keep
l keep 
l l
l m
l ma
l mak
l make
l make 
l me
l n
l no
l not
l not 
l o
l of
l of 
l of t
l of th
l of the
l of the 
l on
l p
l pu
l put
l put 
l s
l sa
l sai
l said
l say
l se
l see
l sen
l send
l send 
l t
l ta
l tak
l take
l take 
l th
l the
l the 
l the e
l the l
l the m
l the p
l the pe
l the people
l the people 
l the t
l the w
l these
l these 
l thi
l thin
l thing
l things
l tho
l those
l those 
l to
l to 
l w
l wa
l was
l was 
l we
l wh
l who
l who 
l wi
l y
l yo
l you
l you 
l your 
l,
l, 
l, a
l, an
l, and
l, and 
l, t
l, th
l, the
l, the 
l, w
l-
l.
l:
l: 
l;
l; 
la
lac
lace
lace 
lace i
lace o
lace of 
lace w
lace,
lace, 
lace.
laces
laces 
lad
lad 
lah
lam
lamb
lan
land
land 
land o
land of 
land w
land wh
land,
land, 
land.
lands
lant
lar
las
last
lat
late
lati
lation
law
law 
ld
ld 
ld a
ld an
ld and 
ld n
ld no
ld not
ld w
ld,
ld, 
ld.
lde
ldi
lding
lding 
ldr
le
le 
le a
le an
le and
le and 
le c
le f
le fo
le for
le for 
le h
le i
le o
le of
le of 
le of t
le of th
le of the
le of the 
le s
le t
le th
le the
le to
le to 
le to g
le w
le we
le wh
le,
le, 
le, a
le, an
le, and
le, and 
le.
le;
lea
lean
lean 
lear
lear 
leas
lec
led
led 
ledg
ledge
ledge 
ledge o
ledge of
ledge of 
ledge of t
ledge of th
ledge of the
lee
lem
lem 
lem,
lem, 
len
lent
ler
ler 
ler o
lers
lers 
les
les 
les,
les, 
lesh
lesh 
less
lessing
let
let 
let h
let hi
let him
let him 
let t
let th
let the
let the 
lete
ley
lf
lf 
lf,
lf, 
li
lia
lie
lies
lies 
lif
lift
lifte
lifted
lifted 
lig
light
light 
lik
like
like 
like a
like t
like th
lim
lin
line
ling
ling 
lip
lis
lish
lish 
list
lit
litt
liv
living
lk
lki
ll
ll 
ll I
ll a
ll b
ll be
ll be 
ll be a
ll be c
ll be f
ll be g
ll be l
ll be m
ll be o
ll be s
ll be t
ll be th
ll be the
ll be w
ll c
ll co
ll com
ll come
ll come 
ll come t
ll come to
ll come to 
ll d
ll do
ll g
ll ge
ll get
ll get 
ll gi
ll giv
ll give
ll give 
ll give t
ll give you
ll give you 
ll go
ll go 
ll h
ll ha
ll hav
ll have
ll have 
ll he
ll he 
ll hi
ll his
ll his 
ll i
ll k
ll ke
ll keep
ll keep 
ll l
ll m
ll ma
ll mak
ll make
ll make 
ll n
ll no
ll not
ll not 
ll not b
ll not be
ll not be 
ll not g
ll o
ll of
ll of 
ll of t
ll of th
ll of the
ll p
ll pu
ll put 
ll s
ll sa
ll say
ll se
ll see
ll sen
ll send
ll send 
ll t
ll ta
ll take
ll take 
ll th
ll the
ll the 
ll the e
ll the l
ll the m
ll the p
ll the pe
ll the people
ll the people 
ll the t
ll the w
ll these
ll these 
ll thi
ll thin
ll thing
ll tho
ll those
ll those 
ll those w
ll w
ll y
ll you
ll you 
ll your 
ll,
ll, 
ll.
lla
llar
lle
lled
lled 
lli
lling
lling 
lls
lm
lo
loc
lock
lom
lomo
lon
long
long 
longe
loo
lood
lood 
look
looking
looking 
loos
loose
lor
lory
lory 
lot
loth
lothi
lothing
lou
loud
loud 
lov
love
low
low 
lowing
lp
ls
ls 
ls o
ls of 
ls,
ls, 
lse
lse 
lt
lta
lth
lth 
lu
lue
lv
lva
lve
lves
lves 
ly
ly 
ly a
ly b
ly i
ly o
ly of
ly of 
ly p
ly pl
ly place
ly t
ly th
ly to
ly to 
ly,
ly, 
ly.
m 
m G
m I
m I 
m a
m a 
m al
m all
m all 
m an
m and
m and 
m b
m be
m c
m co
m d
m f
m fo
m for
m for 
m fr
m g
m go
m h
m ha
m he
m hi
m him
m his
m his 
m i
m in
m in 
m in t
m in th
m in the
m in the 
m m
m me
m n
m no
m o
m of
m of 
m on
m on 
m ou
m p
m s
m sa
m t
m th
m the
m the 
m the L
m the Lord
m the d
m the f
m the h
m the t
m to
m to 
m to d
m to de
m u
m w
m wa
m was
m we
m wh
m who
m who 
m wi
m wit
m with
m with 
m y
m yo
m you
m you 
m your
m your 
m,
m, 
m, I
m, T
m, W
m, a
m, an
m, and
m, and 
m, and t
m, b
m, s
m, t
m, th
m, the
m, the 
m, w
m.
m. 
m:
m: 
m;
m; 
m; a
m; and
m; and 
ma
mad
mag
mage
mak
make
making
making 
mal
male
male 
mall
mall 
man
man 
man a
man h
man ha
man i
man is
man is 
man o
man of
man of 
man t
man w
man wh
man who
man who 
man wi
man's
man's 
man,
man, 
mar
mark
marke
mas
may
mb
mbe
mber
mber 
mber o
mber of 
me
me 
me a
me a 
me ab
me abo
me about
me an
me and
me and 
me b
me ba
me back
me back 
me back t
me be
me d
me do
me down
me down 
me f
me fo
me for
me fr
me from
me from 
me h
me i
me in
me in 
me into 
me into t
me into th
me k
me ki
me kin
me n
me ne
me near
me o
me of
me of 
me of t
me of th
me of the
me of the 
me on
me on 
me ou
me out
me out 
me out o
me out of 
me s
me t
me th
me the
me the 
me to
me to 
me to a
me to h
me to hi
me to m
me to me
me to t
me to th
me to the
me to the 
me to y
me to you
me together
me together 
me u
me up
me up 
me w
me wa
me wh
me wi
me wit
me with
me with 
me,
me, 
me, a
me, an
me, and
me, and 
me, s
me.
me:
me: 
me;
me; 
mea
meal
measur
measure
med
med 
mee
mel
mem
men
men 
men a
men o
men of
men of 
men w
men wh
men who
men,
men, 
men.
ment
ment 
ment o
ment w
ments
ments 
mer
merc
mes
mes 
mes o
mes t
mes to
mes to 
mi
mia
miah
mie
mies
might
mil
mili
min
mind
ming
ming 
mit
mm
mmo
mmon
mo
mon
mon 
mone
mong
mong 
mong t
mong th
mong the
mong the 
mor
more
more 
more t
mos
mot
moth
mothe
mother
mother 
mou
mount
mov
move
moved
mp
mpl
mple
ms
ms 
mse
msel
mu
muc
much
much 
mus
my
my 
my b
my c
my d
my f
my fa
my h
my ha
my he
my l
my m
my o
my p
my pe
my s
my w
my wo
n A
n E
n G
n I
n I 
n Is
n Israel
n J
n Je
n Jer
n Jeru
n Jerusalem
n M
n S
n a
n a 
n ac
n ag
n aga
n again
n al
n all
n all 
n all t
n all th
n all the
n all the 
n an
n and
n and 
n and t
n and th
n and the
n and the 
n answer
n ar
n as
n as 
n at
n aw
n awa
n away
n b
n be
n by
n by 
n by t
n by th
n by the
n c
n ca
n cam
n came
n co
n com
n d
n da
n do
n e
n ea
n en
n end
n end 
n ev
n eve
n ever
n every
n every 
n f
n fl
n fli
n fo
n for
n for 
n fr
n fro
n from 
n from t
n from th
n from the
n from the 
n g
n gi
n giv
n give
n go
n h
n ha
n has
n he
n he 
n he s
n he w
n hea
n her
n her 
n hi
n him
n him 
n his
n his 
n his h
n i
n in
n in 
n in t
n in th
n in the
n in the 
n int
n into
n into 
n is
n is 
n it
n it 
n its
n l
n li
n m
n ma
n mad
n made
n made 
n me
n me 
n mi
n min
n mind
n my
n my 
n n
n o
n oa
n oath
n of
n of 
n of A
n of G
n of I
n of Is
n of Israel
n of Israel 
n of Israel,
n of Israel, 
n of J
n of S
n of m
n of ma
n of man
n of t
n of th
n of the
n of the 
n of w
n off
n offe
n offer
n offering
n offering 
n on
n on 
n on t
n on th
n on the
n on the 
n one
n one 
n or
n ord
n order
n ou
n p
n pl
n pla
n pr
n pu
n put
n r
n s
n sa
n sai
n said
n se
n sh
n so
n t
n ta
n tak
n th
n tha
n that
n that 
n that d
n the
n the 
n the L
n the Lo
n the Lord
n the Lord 
n the a
n the b
n the c
n the d
n the da
n the day
n the day 
n the e
n the ea
n the ear
n the earth
n the f
n the fi
n the h
n the he
n the ho
n the hou
n the house
n the house 
n the k
n the ki
n the king
n the l
n the la
n the lan
n the land
n the land 
n the land o
n the land of 
n the m
n the mo
n the n
n the o
n the p
n the r
n the s
n the se
n the t
n the to
n the w
n the wa
n the was
n the waste
n the waste 
n the wo
n their
n their 
n them
n them 
n they
n they 
n thi
n this
n this 
n tho
n to
n to 
n to h
n to t
n to th
n to the
n to the 
n to you
n u
n un
n up
n up 
n us
n w
n wa
n was
n was 
n we
n wh
n whi
n which
n which 
n who
n who 
n wi
n wil
n will
n will 
n will be
n will be 
n wit
n with
n with 
n y
n yo
n you
n you 
n your
n your 
n your h
n's
n's 
n,
n, 
n, a
n, an
n, and
n, and 
n, and t
n, and th
n, and the
n, b
n, f
n, h
n, s
n, t
n, th
n, the
n, the 
n, w
n, wh
n-
n.
n. 
n:
n: 
n;
n; 
n; a
n; an
n; and
n; and 
n?
na
naa
naan
nah
nam
name
name 
named
named 
nat
nati
nation
nations
nations 
nc
nce
nch
ncl
ncle
ncr
ncre
ncreas
ncrease
nd A
nd Ab
nd B
nd D
nd Da
nd David
nd David 
nd E
nd G
nd H
nd I
nd I 
nd I s
nd I w
nd I wi
nd I will 
nd J
nd Je
nd Jes
nd Jo
nd M
nd Mo
nd P
nd S
nd Sa
nd Sh
nd Z
nd a
nd a 
nd ab
nd af
nd after
nd after 
nd al
nd all
nd all 
nd all t
nd all th
nd all the
nd all the 
nd an
nd and
nd and 
nd at
nd at 
nd b
nd be
nd be 
nd bec
nd by
nd by 
nd c
nd ca
nd came
nd came 
nd co
nd com
nd d
nd de
nd do
nd do 
nd e
nd ev
nd eve
nd ever
nd every
nd f
nd fo
nd for
nd for 
nd for t
nd for th
nd fr
nd fro
nd from 
nd g
nd ga
nd gave
nd gave 
nd ge
nd gi
nd giv
nd give
nd give 
nd go
nd h
nd ha
nd had 
nd has
nd hav
nd have 
nd he
nd he 
nd he g
nd he s
nd he sa
nd he sai
nd he said
nd he said 
nd he said t
nd he said to 
nd he said,
nd he said, 
nd he t
nd he to
nd he took 
nd he w
nd he wa
nd he was
nd he was 
nd he wi
nd he will 
nd her
nd hi
nd his
nd his 
nd his s
nd ho
nd i
nd if
nd if 
nd in
nd in 
nd in t
nd in th
nd in the
nd in the 
nd is
nd is 
nd it
nd it 
nd it w
nd it wi
nd its
nd k
nd ke
nd l
nd le
nd let
nd let 
nd m
nd ma
nd mad
nd made
nd made 
nd mak
nd make
nd make 
nd me
nd my
nd my 
nd n
nd no
nd not
nd not 
nd now
nd o
nd of
nd of 
nd of E
nd of Egypt
nd of t
nd of th
nd of the
nd of the 
nd on
nd on 
nd on t
nd on th
nd on the
nd on the 
nd ou
nd p
nd pu
nd put
nd put 
nd put i
nd put t
nd put th
nd put the
nd r
nd s
nd sa
nd sai
nd said
nd said 
nd said t
nd said to 
nd said,
nd said, 
nd say
nd se
nd sen
nd sh
nd she
nd she 
nd so
nd so 
nd st
nd t
nd ta
nd tak
nd take
nd take 
nd th
nd tha
nd that
nd that 
nd the
nd the 
nd the L
nd the Lo
nd the Lord
nd the Lord 
nd the Lord s
nd the Lord sa
nd the Lord said
nd the Lord said 
nd the a
nd the b
nd the c
nd the ch
nd the chi
nd the child
nd the children
nd the children 
nd the d
nd the f
nd the h
nd the k
nd the ki
nd the kin
nd the king
nd the king 
nd the l
nd the m
nd the o
nd the p
nd the pe
nd the people
nd the pr
nd the r
nd the s
nd the so
nd the t
nd the w
nd the wo
nd their
nd their 
nd there
nd there 
nd there w
nd they
nd they 
nd they s
nd they sa
nd they said
nd they w
nd they we
nd they wi
nd they will 
nd thi
nd this
nd this 
nd tho
nd those 
nd those w
nd those wh
nd to
nd to 
nd to t
nd to th
nd to the
nd to the 
nd too
nd took
nd took 
nd tw
nd u
nd w
nd wa
nd was
nd was 
nd we
nd went
nd went 
nd wh
nd whe
nd when
nd when 
nd when h
nd when he
nd when he 
nd when t
nd when th
nd when the
nd when the 
nd whi
nd which
nd which 
nd who
nd wi
nd wil
nd will
nd will 
nd wit
nd with
nd with 
nd wo
nd y
nd yo
nd you
nd you 
nd you a
nd your
nd your 
nd,
nd, 
nd, a
nd, an
nd, and
nd, and 
nd.
nd:
nd;
nd; 
nde
nded
nder
nder 
nder t
nder th
nder the
nder the 
ndi
ndin
nding
nding 
ndr
ndre
ndred
ndred 
nds
nds 
nds o
nds of
nds of 
nds of t
nds of th
nds of the
nds of the 
nds,
nds, 
ne
ne 
ne a
ne an
ne f
ne h
ne i
ne in
ne in 
ne m
ne o
ne of
ne of 
ne of t
ne of th
ne of the
ne of the 
ne s
ne t
ne to
ne to 
ne w
ne wh
ne who
ne,
ne, 
ne.
nea
nec
ned
ned 
ned a
ned o
ned of
ned t
ned to
ned to 
nee
nei
ner
ner 
ners
ners 
nes
nes 
ness
ness 
ness,
ness, 
nev
neve
never
never 
new
new 
news
news 
news o
news of
news of 
ney
ney 
ng
ng 
ng a
ng a 
ng ag
ng again
ng against 
ng an
ng and
ng and 
ng b
ng be
ng c
ng d
ng do
ng down
ng down 
ng e
ng f
ng fo
ng for
ng for 
ng for t
ng fr
ng g
ng h
ng ha
ng hi
ng him
ng him 
ng his
ng his 
ng i
ng in
ng in 
ng in t
ng in th
ng in the
ng in the 
ng is
ng is 
ng it
ng it 
ng l
ng li
ng m
ng ma
ng me
ng men
ng n
ng o
ng of
ng of 
ng of t
ng of th
ng of the
ng of the 
ng on
ng on 
ng on t
ng on th
ng on the
ng on the 
ng ou
ng out
ng out 
ng ove
ng over
ng over 
ng p
ng s
ng t
ng th
ng the
ng the 
ng their 
ng them
ng them 
ng thi
ng to
ng to 
ng to t
ng to th
ng to the
ng to the 
ng u
ng up
ng up 
ng w
ng wa
ng wh
ng whi
ng which 
ng wi
ng wil
ng will
ng will 
ng wit
ng with
ng with 
ng y
ng you
ng you 
ng your
ng,
ng, 
ng, a
ng, an
ng, and
ng, and 
ng, s
ng, t
ng-
ng.
ng:
ng: 
ng;
ng; 
ngdo
nge
nge 
nged
ngel
ngel 
nger
nger 
ngi
ngin
nging
nging 
ngr
ngry
ngs
ngs 
ngs a
ngs o
ngs of
ngs of 
ngs t
ngs to
ngs w
ngs wh
ngs whi
ngs which
ngs which 
ngs,
ngs, 
ngs.
ngt
ngu
ni
nia
nigh
night
nin
ning
ning 
ning a
ning t
nis
nish
nishment
nishment 
nit
nite
nj
nja
nk
nl
nly
nly 
nn
nne
nner
no
no 
no w
not
not 
not a
not b
not be
not be 
not c
not co
not com
not come
not come 
not g
not go
not go 
not h
not ha
not l
not le
not m
not ma
not o
not p
not s
not se
not see
not t
not th
not the
not to
not to 
noth
nother
nother 
nothi
nothing
nothing 
nou
nough
nour
now
now 
now, 
nowledg
nowledge
nowledge 
ns
ns 
ns a
ns an
ns and 
ns o
ns of
ns of 
ns of t
ns of th
ns of the
ns of the 
ns w
ns wi
ns,
ns, 
ns, a
ns, an
ns, and
ns, and 
ns.
ns;
nse
nsi
nst
nst 
nst m
nst t
nst th
nsw
nswer
nswer 
nt
nt 
nt a
nt an
nt away
nt b
nt d
nt do
nt down
nt down 
nt f
nt fo
nt for
nt for 
nt h
nt i
nt in
nt in 
nt m
nt o
nt of
nt of 
nt of m
nt of t
nt of th
nt of the
nt of the 
nt on
nt on 
nt ou
nt out
nt out 
nt t
nt th
nt to
nt to 
nt u
nt up
nt up 
nt w
nt wi
nt wit
nt with
nt with 
nt,
nt, 
nt.
nta
ntain
ntain 
nte
nth
nth 
nti
ntio
nto
nto 
nto t
nto th
nto the
nto the 
nto the h
ntr
ntro
ntry
ntry 
nts
nts 
nts a
nts o
nts of
nts of 
nts,
nts, 
nty
nty 
nu
num
number
ny
ny 
ny m
ny ma
nything
o A
o B
o D
o Da
o David
o E
o G
o Go
o God
o I
o J
o Je
o Jer
o Jo
o M
o Mo
o Mose
o Moses
o S
o a
o a 
o al
o all
o all 
o all t
o all th
o all the
o all the 
o an
o an 
o ar
o are 
o b
o ba
o back
o be
o be 
o be p
o be t
o c
o co
o com
o come
o come 
o d
o de
o dea
o death
o death 
o death.
o des
o destr
o do
o do 
o e
o ev
o f
o fa
o fe
o fea
o fear
o fo
o g
o ge
o get
o get 
o gi
o giv
o give
o give 
o go
o go 
o h
o ha
o had 
o has
o hav
o have
o have 
o he
o he 
o her
o hi
o him
o him 
o him w
o his
o his 
o i
o in
o in 
o is
o is 
o it
o k
o ke
o keep
o keep 
o kn
o kno
o know
o knowledge
o knowledge 
o l
o lo
o long
o longer
o longer 
o m
o ma
o mak
o make
o make 
o man
o me
o me 
o me,
o me, 
o mo
o my
o my 
o n
o no
o not
o not 
o not g
o o
o on
o on 
o one
o one 
o ou
o out
o out 
o p
o pu
o put
o put 
o r
o re
o res
o rest
o s
o sa
o say
o say 
o se
o see
o see 
o so
o t
o ta
o tak
o take
o take 
o th
o tha
o that
o that 
o that I
o that I 
o that h
o that he
o that t
o that th
o that the
o that the 
o that they
o that they 
o that they m
o that y
o the
o the 
o the L
o the Lord
o the Lord 
o the Lord,
o the Lord, 
o the c
o the ch
o the chi
o the child
o the children
o the children 
o the children of 
o the d
o the e
o the f
o the h
o the ho
o the hou
o the house
o the k
o the kin
o the king
o the l
o the la
o the m
o the p
o the s
o the t
o the w
o the wo
o the wor
o their 
o them
o them 
o them,
o them, 
o they
o they 
o thi
o this
o this 
o tho
o those
o those 
o those w
o those wh
o to
o to 
o u
o us
o w
o wa
o was
o was 
o we
o were 
o wh
o who
o whom
o whom 
o wi
o wil
o will
o will 
o wit
o with
o with 
o y
o yo
o you
o you 
o you,
o you, 
o you.
o your
o your 
o,
o, 
o.
oa
oab
oab 
oat
oath
ob
ob 
obe
oc
ock
od
od 
od a
od an
od and 
od f
od fo
od for
od for 
od h
od ha
od has
od i
od in
od in 
od is
od is 
od o
od of
od of 
od s
od t
od th
od to
od to 
od w
od wh
od wi
od,
od, 
od, a
od, an
od, and
od, and 
od.
od:
od: 
od;
od; 
oda
ods
ods 
ody
ody 
oe
oer
oes
oes 
of B
of E
of I
of J
of Ja
of M
of Ma
of S
of a
of a 
of al
of all
of all 
of an
of ar
of b
of c
of d
of e
of ev
of f
of fo
of g
of go
of h
of he
of hi
of him
of his
of his 
of i
of it
of it 
of l
of li
of m
of ma
of me
of men
of o
of ou
of s
of si
of t
of th
of the
of the 
of the L
of the w
of the wo
of thi
of tho
of w
of wa
of wh
of y
off
off 
offe
offer
offering
offering 
offerings
offerings 
og
oge
ogether
ogether 
oh
oi
oic
oice
oice 
oice o
oice of 
oil
oil 
oin
oing
oing 
ok
ok 
ok a
ok h
ok hi
ok o
ok t
ok th
ok the
ok the 
oke
oken
oken 
oki
oking
oking 
ol
old
old 
old a
old,
ole
olen
oli
olis
olish
oll
olo
olom
oly
oly 
om
om 
om a
om an
om h
om he
om hi
om his
om his 
om i
om m
om me
om o
om of
om of 
om t
om th
om the
om the 
om the d
om the t
om w
om y
om you
om you 
om your 
om,
om, 
oma
oman
oman 
ome
ome 
ome a
ome b
ome ba
ome d
ome f
ome i
ome in
ome o
ome of
ome of 
ome on
ome on 
ome ou
ome out
ome t
ome to
ome to 
ome to t
ome u
ome up
ome w
ome,
ome, 
omen
omen 
omes
omi
omin
omo
omp
ompl
omplet
omplete
on 
on a
on an
on and
on and 
on b
on be
on e
on f
on h
on hi
on him
on his 
on i
on in
on in 
on it
on m
on o
on of
on of 
on of A
on of J
on of m
on of man
on of t
on of th
on of the
on of the 
on on
on t
on th
on the
on the 
on the e
on the ea
on the earth
on the f
on the s
on the t
on the w
on their 
on them
on to
on to 
on to t
on to th
on to the
on w
on wh
on wi
on with
on y
on yo
on you
on your
on your 
on,
on, 
on, a
on, an
on, and
on, and 
on, t
on, w
on.
on:
on: 
on;
on; 
ona
ond
ond 
onde
onder
one
one 
one a
one an
one f
one i
one in
one o
one of
one of 
one of t
one of th
one of the
one of the 
one s
one t
one to
one to 
one w
one wh
one who
one,
one, 
one.
oner
ones
ones 
oney
oney 
ong
ong 
ong a
ong t
ong th
ong the
ong the 
ong y
ong you
ong,
ong, 
onge
onger
onger 
oni
onl
only
only 
ono
onou
onour
onour 
ons
ons 
ons a
ons an
ons and 
ons o
ons of
ons of 
ons w
ons,
ons, 
ons.
onsi
ont
oo
ood
ood 
ood a
ood an
ood and 
ood f
ood o
ood t
ood w
ood,
ood, 
ood.
oods
oods 
ook
ook 
ook a
ook h
ook hi
ook o
ook t
ook th
ook the
ook the 
ooking
ooking 
ool
oolish
oolish 
oom
oor
oor 
oos
oose
oose 
oot
op
ope
ope 
open
oper
oph
ophe
ophet
ophet 
opi
opl
opp
or 
or I
or I 
or a
or a 
or al
or all
or all 
or an
or b
or d
or e
or ev
or eve
or ever
or f
or fo
or g
or h
or he
or he 
or hi
or him
or his
or his 
or i
or in
or it
or it 
or m
or me
or my
or my 
or o
or of
or of 
or s
or se
or t
or th
or the
or the 
or the L
or the Lord
or the Lord 
or the p
or the s
or the w
or their
or their 
or them
or they
or they 
or thi
or this
or this 
or this c
or this ca
or this cause
or u
or w
or wh
or y
or you
or you 
or your
or your 
or,
or, 
orc
orce
ord
ord 
ord a
ord an
ord and 
ord c
ord ca
ord came
ord came 
ord g
ord h
ord ha
ord had 
ord i
ord is
ord is 
ord o
ord of
ord of 
ord of a
ord of t
ord of th
ord of the
ord of the 
ord s
ord sa
ord sai
ord said
ord said 
ord t
ord th
ord w
ord wi
ord will
ord will 
ord y
ord you
ord your 
ord's
ord's 
ord,
ord, 
ord, a
ord, an
ord, and 
ord, t
ord, th
ord, the
ord, the 
ord, w
ord.
ord:
ord: 
ord;
ord; 
orda
orde
order
order 
orders
orders 
orders t
ords
ords 
ords o
ords of
ords of 
ords of t
ords of th
ore
ore 
ore h
ore hi
ore him
ore m
ore t
ore th
ore the
ore the 
ore the L
ore the Lord
ore y
ori
orit
ork
ork 
orke
orks
orks 
orl
orm
orn
orni
orning
orr
orro
orrow
orrow 
ors
orse
orship
orship 
ort
ort 
ort o
ort of
ort of 
orwa
ory
ory 
ory o
ory of
ory of 
os
ose
ose 
ose o
ose of
ose of 
ose w
ose wh
ose who
ose who 
oses
oses 
oses,
oses, 
osh
oshua
osi
oss
oss 
ost
ost 
ot
ot 
ot a
ot b
ot be
ot be 
ot c
ot co
ot f
ot g
ot gi
ot giv
ot give
ot go
ot h
ot ha
ot i
ot k
ot l
ot m
ot ma
ot o
ot on
ot p
ot pu
ot s
ot se
ot see
ot t
ot ta
ot tak
ot take
ot th
ot the
ot the 
ot to
ot to 
ot u
ot up
ot up 
ote
oth
othe
other
other 
other,
other, 
others
others 
others,
others, 
othi
othing
othing 
ou 
ou a
ou an
ou and 
ou ar
ou are
ou are 
ou are t
ou b
ou c
ou d
ou do
ou f
ou g
ou go
ou h
ou ha
ou have
ou have 
ou i
ou in
ou in 
ou m
ou ma
ou may
ou may 
ou n
ou no
ou o
ou p
ou s
ou sa
ou say
ou se
ou t
ou th
ou the
ou to
ou to 
ou w
ou we
ou wh
ou wi
ou wil
ou will
ou will 
ou will be
ou will be 
ou,
ou, 
ou, O
ou, O 
ou, a
ou, an
ou, and
ou, and 
ou.
ou:
ou: 
ou;
ou; 
ou?
oub
oubl
ouble
ouble 
oubled
oud
oud 
ough
ough 
ough a
ough t
ough th
ough the
ough the 
ought
ought 
oul
oul 
ould
ould 
ould n
ould no
ould not
oun
ound
ound 
oung
oung 
ount
ount 
ount o
ount of 
ountain
ountain 
ountains
ountr
ountry
ountry 
our
our 
our G
our God
our God 
our God,
our God, 
our a
our b
our br
our bro
our c
our d
our de
our e
our eye
our eyes
our f
our fa
our fat
our father
our fathers
our g
our h
our ha
our hand
our hands
our he
our hea
our hear
our heart
our ho
our l
our li
our m
our n
our o
our p
our pe
our r
our s
our se
our serv
our servant
our si
our so
our t
our to
our w
our wa
our wo
our wor
ours
ourse
oursel
ourselves
ourselves 
ous
ousa
ouse
ouse 
ouse o
ouse of 
ouse of th
ouse of the
ouse of the 
ouse of the L
ouse,
ouse, 
ouse.
ouses
ousness
ousness 
out
out 
out a
out an
out b
out f
out fr
out from 
out h
out i
out in
out o
out of
out of 
out of t
out of th
out of the
out of the 
out t
out th
out the
out the 
out to
out to 
out w
out,
out, 
outh
outh 
outs
ov
ove
ove 
oved
oved 
over
over 
over t
over th
over the
over the 
overt
ow
ow 
ow a
ow i
ow t
ow th
ow the
ow the 
ow w
ow,
ow, 
owe
ower
ower 
ower o
ower of 
owing
owing 
owl
owle
owled
own
own 
own a
own i
own o
own of
own of 
own on
own on 
own t
own to
own to 
own w
own,
own, 
owns
owns 
ows
ows 
ox
oxe
oy
oy 
p 
p a
p an
p and
p and 
p b
p f
p fro
p from 
p h
p hi
p his 
p i
p in
p in 
p m
p o
p of
p of 
p t
p th
p the
p the 
p their 
p to
p to 
p to t
p to th
p to the
p to the 
p w
p y
p you
p your
p,
p, 
p, a
p, and
p, and 
p.
pa
pai
pain
par
part
part 
part o
part of 
pas
past
pay
pe
pe 
pea
pec
pen
pen 
peo
people
people 
per
pers
pert
ph
pha
phe
phet
phr
phra
phrai
phraim
pi
pil
pill
pillar
pin
ping
ping 
pir
pirit
pirit 
pl
pla
plac
place
place 
place i
place o
place of 
place w
place,
place, 
place.
places
places 
plan
plant
ple
ple 
ple a
ple an
ple and
ple and 
ple o
ple of
ple of 
ple w
ple,
ple, 
ple.
plea
pleas
pleasure
ples
ples 
plet
po
pon
pons
poo
por
port
pos
pose
pose 
posi
posit
position
pow
power
pp
ppe
ppo
ppor
pport
pr
pra
pray
pre
pri
pric
price
prig
pright
pright 
prin
pring
pris
prison
prisone
prisoner
pro
ps
ps 
pt
pt 
pt t
pt,
pt, 
pta
pti
pu
pun
punish
put
qu
que
quest
questi
qui
quick
quiet
r G
r Go
r God
r God 
r God,
r God, 
r I
r I 
r J
r a
r a 
r a s
r ag
r again
r al
r all
r all 
r all t
r all th
r all the
r all the 
r an
r and
r and 
r and t
r ar
r as
r as 
r b
r be
r be 
r bo
r br
r bro
r brother
r by
r by 
r c
r ca
r ch
r chi
r child
r co
r d
r da
r de
r des
r e
r ea
r ear
r ev
r eve
r ever
r evil
r eye
r eyes
r eyes 
r f
r fa
r fac
r face
r fami
r famil
r fat
r father
r fathers
r fe
r fo
r foo
r food
r for
r for 
r fr
r fro
r from 
r g
r go
r gr
r h
r ha
r han
r hand
r hands
r he
r he 
r hea
r hear
r heart
r hearts
r her
r hi
r him
r him 
r his
r his 
r ho
r hou
r hous
r house
r hu
r i
r in
r in 
r in t
r in th
r in the
r in the 
r is
r is 
r it
r it 
r k
r l
r la
r lan
r land
r li
r lo
r m
r ma
r me
r mo
r my
r my 
r n
r na
r name
r ne
r o
r of
r of 
r of h
r of t
r of th
r of the
r of the 
r on
r on 
r or
r ou
r p
r pe
r people
r pl
r pla
r place
r pr
r pu
r r
r re
r s
r sa
r se
r see
r serv
r servant
r si
r sin
r so
r son
r st
r t
r te
r ten
r th
r tha
r than
r than 
r that
r that 
r the
r the 
r the L
r the Lord
r the Lord 
r the b
r the c
r the d
r the f
r the p
r the s
r the w
r their
r their 
r them
r they
r they 
r thi
r this
r this 
r tho
r to
r to 
r to h
r to hi
r to m
r to me
r to t
r to th
r to the
r to the 
r to y
r to you
r u
r us
r v
r w
r wa
r was
r was 
r way
r we
r wh
r whi
r which 
r who
r wi
r wil
r will
r will 
r wit
r with
r with 
r wo
r wor
r word
r y
r yo
r you
r you 
r you,
r you, 
r your
r your 
r's
r's 
r,
r, 
r, a
r, an
r, and
r, and 
r, and t
r, and th
r, b
r, s
r, t
r, th
r, the
r, the 
r, w
r, wh
r.
r. 
r:
r: 
r;
r; 
r; a
r; an
r; and
r; and 
r?
ra
rac
race
race 
rae
rael
rael,
rael, 
rah
rai
raim
rain
rain 
rais
raise
raise 
raise t
raise to
raise to 
ram
ran
rang
range
range 
ras
rass
rat
rath
rath 
rati
ration
ray
raye
rayer
rayer 
rc
rce
rch
rch 
rd
rd 
rd a
rd an
rd and 
rd c
rd ca
rd came
rd came 
rd f
rd g
rd h
rd ha
rd had 
rd has
rd i
rd is
rd is 
rd o
rd of
rd of 
rd of a
rd of t
rd of th
rd of the
rd of the 
rd of the L
rd s
rd sa
rd sai
rd said
rd said 
rd t
rd th
rd to
rd w
rd wi
rd will
rd will 
rd y
rd yo
rd you
rd your
rd your 
rd's
rd's 
rd,
rd, 
rd, a
rd, an
rd, and 
rd, t
rd, th
rd, the
rd, the 
rd, w
rd.
rd:
rd: 
rd;
rd; 
rda
rde
rded
rded 
rden
rder
rder 
rders
rds
rds 
rds o
rds of
rds of 
rds of t
rds of th
rds of the
rds of the 
rds,
rds, 
re 
re a
re a 
re al
re all
re all 
re an
re b
re be
re c
re d
re f
re fo
re for
re for 
re g
re h
re he
re hi
re him
re i
re in
re in 
re in t
re in th
re in the
re in the 
re is
re is 
re is n
re is no
re l
re li
re liv
re m
re ma
re n
re no
re not
re not 
re o
re of
re of 
re of t
re of th
re of the
re on
re p
re r
re s
re se
re st
re t
re th
re tha
re the
re the 
re the L
re the Lord
re they
re they 
re to
re to 
re to b
re to be
re to be 
re u
re w
re wa
re was
re was 
re we
re were
re wi
re wil
re will
re will 
re will be 
re wit
re with
re with 
re y
re yo
re you
re you 
re,
re, 
re, a
re, an
re, and
re, and 
re.
re;
re; 
rea
read
read 
ready
ready 
ream
reas
rease
reason
reat
reat 
reat n
reat number
reate
rec
rect
rection
red
red 
red a
red an
red and 
red b
red w
ree
ree 
ree f
ree fr
ree from 
reem
rees
rel
rem
ren
ren 
ren o
ren of 
requ
reque
res
resp
rest
rest 
rest o
rest of 
rest of th
resti
resting
ret
ret 
retch
retche
retched
retched 
rew
rewar
reward
rf
rg
rgi
ri
ria
riah
rib
ribe
ribe 
ribe o
ribe of 
ribes
ric
rice
rid
ride
ride 
rie
rief
rien
riend
ries
riest
riest 
riests
riests 
rig
right
right 
righte
righteous
righteousness
righteousness 
rin
ring
ring 
ring a
ring o
ring of
ring of 
ring t
ring th
ring the
ring to
ring to 
ring,
ring, 
rings
rings 
rink
ris
rise
riso
rison
rist
rit
rit 
rita
riti
riting
rity
rity 
riv
rive
river
rk
rk 
rk o
rk of 
rk of t
rk of th
rk of the
rk of the 
rk,
rk, 
rke
rked
rked 
rki
rkin
rks
rks 
rl
rly
rly 
rm
rme
rmed
rmi
rmy
rmy 
rn
rna
rne
rned
rned 
rned a
rned o
rned of
rned t
rned to
rned to 
rni
rning
rning 
rning t
ro
rob
robe
rod
roke
roken
roken 
rol
rom
rom 
rom a
rom h
rom he
rom hi
rom his
rom his 
rom m
rom me
rom t
rom th
rom the
rom the 
rom the d
rom the t
rom y
ron
ron 
ron,
rong
rong 
roo
room
rop
rope
roph
rophe
rophet
rophet 
ros
ross
rot
roth
rothe
rother
rother 
rothers
rou
roubl
rouble
rouble 
rough
rough 
rough a
round
round 
row
row 
rp
rpo
rr
rri
rro
rrow
rrow 
rs
rs 
rs a
rs an
rs and 
rs f
rs h
rs i
rs in
rs in 
rs o
rs of 
rs of t
rs of th
rs of the
rs of the 
rs t
rs to
rs to 
rs w
rs,
rs, 
rs, a
rs, an
rs, and 
rs, t
rs.
rs:
rs;
rs; 
rse
rse 
rsel
rself
rself 
rsh
rshi
rship
rship 
rst
rst 
rt
rt 
rt i
rt in
rt in 
rt o
rt of
rt of 
rt of t
rt of th
rt of the
rt of the 
rt,
rt, 
rta
rtain
rtain 
rtain t
rtain th
rtain that
rtain that 
rtak
rte
rted
rth
rth 
rth,
rth, 
rth.
rts
rts 
rts o
rts of 
rty
rty 
ru
ruc
rue
rue 
ruel
ruel 
rui
ruit
ruit 
rul
rule
ruler
rulers
rulers 
ruly
ruly 
ruly, 
rus
rush
rushe
rushed
rv
rva
rw
rwa
ry
ry 
ry a
ry f
ry m
ry ma
ry man
ry man 
ry o
ry of
ry of 
ry of th
ry of the
ry of the 
ry s
ry t
ry w
ry,
ry, 
ry.
rying
rying 
s C
s Ch
s Christ
s G
s I
s I 
s a
s a 
s a s
s ab
s ag
s again
s against 
s an
s an 
s and
s and 
s and a
s and h
s and s
s and t
s and th
s and the
s and the 
s and w
s ar
s are
s are 
s are t
s as
s as 
s at
s at 
s b
s ba
s be
s be 
s bec
s bee
s been
s been 
s bef
s before
s before 
s bo
s bod
s body
s br
s bro
s brother
s bu
s by
s by 
s c
s ca
s cam
s came
s came 
s cau
s caus
s cause
s cl
s clea
s co
s com
s come
s come 
s come t
s come to
s d
s da
s day
s de
s dea
s di
s dis
s do
s done
s done 
s e
s ev
s f
s fa
s far
s far 
s fat
s father
s fe
s fi
s fo
s foo
s for
s for 
s for t
s for th
s for the
s for the 
s fr
s fro
s from
s from 
s from t
s from th
s from the
s from the 
s fu
s ful
s full
s full 
s full of 
s g
s gi
s giv
s give
s given
s given 
s given t
s go
s go 
s gone
s good
s gr
s gre
s grea
s great
s h
s ha
s had
s had 
s han
s hand
s hav
s have 
s he
s he 
s hea
s hear
s heart
s hi
s his
s his 
s ho
s hou
s house
s house 
s i
s in
s in 
s in t
s in th
s in the
s in the 
s is
s is 
s is t
s is th
s is the
s is the 
s is w
s it
s it 
s k
s ki
s kin
s l
s la
s li
s lif
s life
s like
s like 
s liv
s living
s lo
s m
s ma
s mad
s made
s made 
s me
s mo
s my
s my 
s n
s na
s name
s ne
s no
s no 
s not
s not 
s not t
s o
s of
s of 
s of G
s of I
s of Is
s of Israel
s of J
s of a
s of g
s of h
s of hi
s of m
s of s
s of t
s of th
s of the
s of the 
s of the L
s of the Lord
s of the e
s of the ea
s of the ear
s of the earth
s of the f
s of the p
s of the s
s of w
s of y
s of you
s of your
s of your 
s ol
s old
s on
s on 
s on t
s on th
s on the
s on the 
s or
s ord
s order
s ou
s out
s out 
s over
s p
s pe
s people
s pl
s pla
s place
s place 
s po
s pr
s pu
s put
s put 
s r
s re
s rea
s ri
s right
s right 
s ro
s ru
s s
s sa
s sai
s said
s said 
s said t
s said to 
s said,
s said, 
s said:
s said: 
s se
s sea
s see
s sen
s sent
s sent 
s ser
s serv
s servant
s servants
s sh
s si
s so
s son
s sons
s st
s str
s t
s ta
s tak
s take
s taken
s taken 
s te
s th
s tha
s that
s that 
s the
s the 
s the L
s the Lord
s the Lord 
s the Lord.
s the f
s the s
s the w
s their
s there
s there 
s they
s they 
s thi
s to
s to 
s to b
s to be
s to be 
s to g
s to h
s to t
s to th
s to the
s to the 
s tr
s u
s un
s unc
s up
s v
s w
s wa
s was
s was 
s way
s we
s went
s went 
s were
s were 
s wh
s what
s what 
s what t
s what th
s what the
s whi
s which
s which 
s who
s who 
s wi
s wife
s wil
s will
s will 
s will be
s will be 
s wit
s with
s with 
s wo
s wor
s word
s work
s y
s yo
s you
s you 
s your
s your 
s'
s' 
s,
s, 
s, I
s, a
s, an
s, and
s, and 
s, and h
s, and t
s, and th
s, and the
s, and the 
s, b
s, bu
s, but
s, but 
s, f
s, h
s, he
s, i
s, o
s, s
s, sa
s, say
s, so
s, so 
s, so th
s, so that
s, so that 
s, t
s, th
s, the
s, the 
s, to
s, to 
s, w
s, wh
s, who
s, who 
s, wi
s.
s. 
s:
s: 
s: a
s: an
s: and
s: and 
s;
s; 
s; a
s; an
s; and
s; and 
s; t
s; th
s; the
s?
s? 
sa
saf
safe
safe 
sai
said
said 
said t
said to 
said to th
said to the
said to them
said to them,
sal
sale
salv
sam
same
same 
san
sand
sand 
saw
saw 
saw t
saw th
say
say 
say t
say to 
saying
saying 
saying,
saying, 
sb
sba
sban
sc
sci
sd
se
se 
se a
se an
se and 
se ar
se are
se are 
se are t
se are th
se are the
se are the 
se b
se d
se f
se fo
se for
se for 
se h
se he
se he 
se i
se in
se in 
se m
se o
se of
se of 
se of t
se of th
se of the
se of the 
se of the L
se s
se t
se th
se the
se the 
se they 
se thi
se thin
se thing
se things
se things 
se to
se to 
se w
se wh
se who
se who 
se wi
se wo
se wor
se word
se words
se y
se yo
se you
se you 
se,
se, 
se, a
se, an
se, and
se, and 
se.
se;
sea
sear
search
seas
seat
seated
sec
second
second 
secr
sed
sed 
see
see 
see t
see th
see the
see the 
see,
see, 
seem
seen
seen 
sees
sel
self
self 
self,
self, 
sels
selve
selves
selves 
sen
sens
sent
sent 
sent f
sent fo
sent for
sent for 
sent t
sep
seph
ser
serv
serva
servant
servant 
servant,
servant, 
servants
servants 
ses
ses 
ses a
ses an
ses and 
ses o
ses,
ses, 
seve
seven
seven 
sevent
sg
sh
sh 
sh,
sh, 
sha
shak
shaki
shaking
sham
shame
she
she 
she w
shed
shed 
shee
shi
shin
shing
shing 
ship
ship 
shm
shme
shment
shment 
sho
shu
shua
si
sib
sible
sible 
sible for 
sid
side
side 
side o
side of 
side t
sig
sign
sign 
signs
signs 
sil
sin
sin 
sing
sing 
sing t
sins
sion
sion 
sions
sions 
sir
sit
siti
sition
six
six 
sk
ski
sl
sm
sma
sn
sne
so
so 
so t
so th
so tha
so that
so that 
so that I
so that I 
so that h
so that t
so that th
so that the
so that y
som
some
some 
son
son 
son o
son of 
son,
son, 
sone
song
sons
sons 
sons a
sons o
sons of
sons of 
sor
sort
sou
sound
sp
spe
spec
spi
spir
spirit
spirit 
spo
spr
spri
sprin
spring
sr
sra
ss
ss 
ss a
ss o
ss of
ss of 
ss t
ss,
ss, 
ss.
sse
sses
ssi
ssin
ssing
ssing 
st
st 
st a
st f
st h
st hi
st him
st i
st m
st me
st o
st of
st of 
st of t
st of th
st of the
st of the 
st s
st t
st th
st the
st the 
st to
st to 
st w
st wi
st y
st you
st,
st, 
st, a
st, an
st, and
st, and 
st.
sta
star
ste
sted
sted 
ster
sti
stil
stin
stine
sting
sting 
sto
ston
stone
stones
stor
store
str
stra
strai
strang
strange
strange 
stre
stretch
stretche
stretched
stretched 
stretched o
stro
stru
struc
struct
structi
struction
struction 
struction o
sts
sts 
sts a
sts an
sts and 
sts,
sts, 
su
suc
such
such 
sun
sup
supp
suppo
support
sur
sure
sure 
sus
sus 
sus,
sus, 
sw
swe
swer
swo
t G
t Go
t God
t I
t I 
t I a
t I am
t I am 
t I m
t I w
t J
t Je
t Jes
t Jesus
t S
t a
t a 
t ab
t af
t after
t after 
t ag
t again
t against 
t al
t all
t all 
t all t
t all th
t all the
t all the 
t an
t an 
t an e
t and
t and 
t and t
t ar
t as
t as 
t awa
t away
t away 
t b
t ba
t back
t back 
t be
t be 
t bec
t bef
t before
t before 
t by
t by 
t c
t ca
t came
t came 
t co
t com
t come
t come 
t d
t da
t day
t day 
t de
t do
t down
t down 
t e
t ev
t eve
t f
t fo
t for
t for 
t for t
t for th
t for the
t for the 
t fr
t fro
t from 
t from t
t from th
t from the
t g
t gi
t giv
t give
t give 
t go
t go 
t h
t ha
t has
t hav
t have
t have 
t he
t he 
t he m
t he w
t her
t her 
t hi
t him
t him 
t him t
t his
t his 
t ho
t i
t if
t if 
t in
t in 
t in t
t in th
t in the
t in the 
t int
t into 
t into t
t into th
t into the
t into the 
t is
t is 
t is n
t is no
t is not
t is not 
t is t
t is th
t is the
t is the 
t it
t it 
t it i
t k
t ke
t keep
t keep 
t l
t le
t let
t let 
t li
t m
t ma
t mak
t make
t make 
t man
t may
t may 
t me
t me 
t my
t my 
t n
t no
t no 
t not
t not 
t number
t o
t of
t of 
t of a
t of h
t of hi
t of his 
t of m
t of me
t of t
t of th
t of the
t of the 
t of y
t of you
t of your
t of your 
t off
t off 
t on
t on 
t on t
t on th
t on the
t on the 
t one
t one 
t ou
t out
t out 
t ove
t over
t p
t pl
t pu
t put
t put 
t r
t re
t s
t sa
t se
t see
t sh
t si
t so
t st
t t
t ta
t tak
t take
t take 
t th
t tha
t that
t that 
t the
t the 
t the L
t the Lord
t the Lord 
t the Lord h
t the Lord ha
t the b
t the d
t the f
t the h
t the l
t the m
t the p
t the s
t the t
t the w
t their
t their 
t them
t them 
t there
t there 
t they
t they 
t they m
t they ma
t they w
t thi
t this
t this 
t tho
t thr
t ti
t tim
t time
t to
t to 
t to d
t to de
t to dea
t to death
t to death 
t to h
t to hi
t to m
t to t
t to th
t to the
t to the 
t to you
t u
t up
t up 
t up a
t up an
t up t
t us
t us 
t w
t wa
t was
t was 
t we
t we 
t wh
t whe
t when
t when 
t whi
t which 
t wi
t wil
t will
t will 
t will b
t will be
t will be 
t wit
t with
t with 
t with t
t with th
t with the
t wo
t y
t you
t you 
t you a
t you h
t your
t your 
t your h
t,
t, 
t, a
t, an
t, and
t, and 
t, and t
t, and th
t, and the
t, b
t, i
t, s
t, t
t, th
t, the
t, the 
t, w
t, wh
t-
t.
t:
t: 
t;
t; 
t; a
t; an
t; and
t; and 
t?
ta
tac
tack
tag
tage
tage 
tai
tain
tain 
tain o
tain of
tain of 
tain t
tain th
tain that
tain that 
tains
tains 
tak
take
take 
take a
take h
take t
take th
take the
take the 
take y
take you
taken
taken 
taken a
taken away
takes
takes 
taking
taking 
tal
talk
tar
tar 
tc
tch
tche
tched
tched 
tched o
te
te 
te l
te land
te o
te of
te of 
te,
te, 
te.
tea
ted
ted 
ted u
ted up
ted up 
tee
teen
tem
ten
ten 
tent
tenti
tentio
tention
tents
tents 
teo
teous
teousness
ter
ter 
ter a
ter h
ter hi
ter o
ter of
ter of 
ter t
ter th
ter tha
ter the
ter the 
ter w
ter,
ter, 
ters
ters 
tes
tes 
tes,
tes, 
test
th 
th a
th a 
th al
th all
th all 
th an
th and
th and 
th b
th c
th d
th da
th day
th f
th g
th h
th hi
th him
th him 
th his
th his 
th i
th in
th in 
th in t
th in th
th in the
th in the 
th is
th is 
th m
th me
th o
th of
th of 
th of t
th of th
th of the
th of the 
th p
th s
th t
th th
th the
th the 
th their
th their 
th them
th to
th to 
th w
th wa
th wi
th wil
th will
th will 
th y
th you
th you 
th,
th, 
th, a
th, an
th, and
th, and 
th, t
th, th
th.
th:
th: 
th;
th; 
tha
than
than 
than t
than th
than the
that
that 
that i
that w
that we
the S
the a
the al
the c
the cu
the h
the he
the hi
the ho
the hol
the holy
the holy 
the i
the m
the me
the mi
the n
the o
the of
the po
the s
the sa
the same
the same 
the se
the sh
the t
the th
the to
the u
the up
the v
the w
the wi
the y
the yo
the you
their
their 
them
then
then 
then t
then, 
ther
ther 
ther a
ther an
ther and 
ther i
ther o
ther of
ther of 
ther s
ther t
ther w
ther's
ther's 
ther,
ther, 
ther, a
ther.
there
there 
there i
there is 
there w
thers
thers 
thers,
thers, 
thes
they
they 
they c
they s
they t
they w
they we
they were
they were 
thi
thin
thing
thing 
thing t
thing w
thing,
thing, 
things
thir
third
this
this 
this i
this is
this is 
tho
thor
thori
thou
though
though 
thr
thre
three
three 
thro
ths
ti
til
till
till 
till t
till th
till the
till the 
tim
time
time 
time,
time, 
times
times 
tin
tine
tines
ting
ting 
ting a
ting i
ting o
ting t
ting th
ting the
ting,
tio
tion
tion 
tion o
tion of
tion of 
tion t
tion to
tion to 
tion w
tion,
tion, 
tion.
tions
tions 
tions,
tions, 
tl
tle
tle 
tly
tly 
tn
tne
tness
tness 
to 
to A
to B
to D
to Da
to E
to G
to Go
to God
to J
to Je
to Jer
to Jeru
to Jerusalem
to M
to Mo
to Mose
to Moses
to Moses,
to S
to a
to a 
to al
to all
to all 
to all t
to all th
to an
to an 
to b
to be
to c
to co
to d
to de
to dea
to death
to death 
to death.
to des
to destr
to destruction
to e
to g
to go
to h
to ha
to have
to have 
to he
to her
to hi
to him
to him 
to him,
to him, 
to his
to his 
to i
to it
to k
to keep
to l
to m
to ma
to me
to me 
to me,
to me, 
to my
to my 
to o
to p
to s
to sa
to se
to t
to ta
to th
to the
to the 
to the L
to the Lord
to the Lord 
to the Lord,
to the Lord, 
to the c
to the ch
to the chi
to the child
to the d
to the e
to the ea
to the ear
to the f
to the h
to the ho
to the hou
to the house
to the k
to the kin
to the king
to the l
to the la
to the m
to the p
to the s
to the t
to the w
to the wo
to the wor
to their 
to them
to them 
to them,
to them, 
to thi
to this
to this 
to tho
to those
to those 
to u
to us
to w
to wh
to who
to y
to yo
to you
to you 
to you,
to you, 
to you.
to your
to your 
together
together 
ton
tone
too
took
took 
took a
took h
took hi
took t
took th
took the
took the 
top
tor
tore
tow
town
town 
towns
towns 
tr
tra
trai
traight
tran
trang
trange
tre
tree
trees
tren
trength
trength 
tretch
tri
trib
tribe
tribe 
tribe o
tribe of 
tro
trol
tron
trong
trong 
trou
troubl
trouble
troubled
tru
truc
true
true 
try
try 
ts
ts 
ts a
ts an
ts and 
ts and t
ts b
ts f
ts h
ts i
ts in
ts in 
ts o
ts of
ts of 
ts of t
ts of th
ts of the
ts of the 
ts t
ts to
ts w
ts wi
ts,
ts, 
ts, a
ts, an
ts, and
ts, and 
ts.
ts;
tt
tta
tte
tten
tter
tter 
tti
tting
tting 
ttl
ttle
ttle 
tu
tur
turn
turne
turned
turned 
turned a
turned t
turned to
turned to 
turning
turning 
tw
twe
twent
two
two 
ty
ty 
ty o
u 
u a
u an
u and 
u b
u c
u d
u f
u g
u go
u h
u ha
u have
u have 
u i
u in
u in 
u m
u ma
u may
u may 
u o
u p
u s
u sa
u se
u t
u th
u the
u to
u to 
u w
u we
u wh
u wi
u wil
u will
u will 
u will be
u will be 
u,
u, 
u, a
u, an
u, and
u, and 
u.
u:
u: 
u;
u; 
u?
ua
ub
ubi
ubl
uc
uch
uch 
uch a
uct
ud
ud 
uda
udah
udah 
udah,
udah, 
udg
udge
ue
ue 
uel
uel 
ues
uest
uest 
ug
ugh
ugh 
ugh a
ugh t
ugh th
ugh the
ught
ught 
ughte
ui
uic
uick
uid
uil
uild
uilding
uilding 
uit
uit 
ul
ul 
ul,
ul, 
uld
ule
uler
uler 
uler o
ulers
ulers 
ull
ull 
ull o
ull of
ull of 
um
umb
umber
umber 
ume
ument
un
unc
uncl
uncle
und
unde
under
under 
under t
under th
under the
under the 
undr
undre
ung
ung 
uni
unish
unishment
unishment 
unt
unt 
unt o
unta
untr
up
up 
up a
up an
up and
up and 
up f
up i
up in
up o
up t
up th
up,
up, 
upp
uppo
upr
ur
ur 
ur G
ur God
ur God 
ur a
ur b
ur br
ur bro
ur c
ur e
ur eye
ur eyes
ur f
ur fa
ur fat
ur father
ur fathers
ur g
ur h
ur ha
ur hand
ur hands
ur he
ur hea
ur hear
ur heart
ur ho
ur l
ur li
ur m
ur n
ur p
ur pe
ur s
ur so
ur t
ur w
ur wa
ur,
ur, 
ure
ure 
urn
urne
urned
urned 
urned a
urned away
urned o
urned of
urned t
urned to
urned to 
urni
urning
urning 
urp
urpos
urs
urse
urt
us
us 
us a
us s
us sa
us sai
us said
us t
us w
us,
us, 
us.
usa
usal
usan
usband
use
use 
use a
use h
use he
use he 
use i
use o
use of
use of 
use of t
use of th
use of the
use of the 
use of the L
use t
use th
use the
use the 
use they 
use w
use y
use you
use you 
use,
use, 
use.
uses
ush
ushe
ushed
ushi
ushing
ushing 
usi
usin
using
using 
ust
ut
ut 
ut I
ut I 
ut a
ut a 
ut an
ut an 
ut b
ut d
ut f
ut fo
ut fr
ut from 
ut h
ut he
ut he 
ut hi
ut him
ut him 
ut his 
ut i
ut if
ut if 
ut in
ut in 
ut in t
ut in th
ut int
ut into 
ut it
ut it 
ut m
ut me
ut my
ut my 
ut n
ut no
ut o
ut of
ut of 
ut of t
ut of th
ut of the
ut of the 
ut off
ut off 
ut on
ut on 
ut ou
ut s
ut t
ut th
ut the
ut the 
ut their 
ut them
ut them 
ut they
ut they 
ut to
ut to 
ut to d
ut to de
ut to t
ut to th
ut to the
ut to the 
ut u
ut up
ut up 
ut w
ut wh
ut y
ut you
ut you 
ut your
ut your 
ut,
ut, 
uth
uth 
uts
uts 
utt
utting
utting 
va
val
van
vant
vat
vation
vation 
ve
ve 
ve a
ve a 
ve an
ve b
ve be
ve c
ve co
ve com
ve come
ve come 
ve d
ve do
ve e
ve ea
ve ear
ve ear 
ve ear t
ve ear to
ve ear to 
ve ear to th
ve f
ve fo
ve for
ve for 
ve g
ve gi
ve give
ve go
ve h
ve he
ve hi
ve him
ve him 
ve i
ve it
ve it 
ve k
ve know
ve knowledge
ve knowledge 
ve knowledge of
ve knowledge of 
ve l
ve m
ve ma
ve made
ve made 
ve me
ve me 
ve n
ve no
ve no 
ve no f
ve not
ve not 
ve o
ve or
ve ord
ve order
ve p
ve pr
ve pra
ve praise
ve praise 
ve pu
ve put 
ve s
ve sa
ve said
ve se
ve t
ve ta
ve th
ve the
ve the 
ve them
ve them 
ve to
ve to 
ve u
ve w
ve wo
ve wor
ve y
ve yo
ve you
ve you 
ved
ved 
ven
ven 
ven a
ven h
ven i
ven m
ven o
ven t
ven th
ven the
ven the 
ven to
ven to 
ven u
ven y
ven you
ven,
ven, 
vene
vent
ver
ver 
ver a
ver an
ver and 
ver b
ver i
ver t
ver th
ver the
ver the 
ver,
ver, 
ver.
vere
vered
vered 
vers
vert
very
very 
very m
very ma
very man
very man 
very o
very s
verything
verything 
ves
ves 
ves a
ves,
ves, 
vessel
vessels
vi
vid
vil
vil 
vil w
vin
vine
ving
ving 
ving a
ving i
ving in
ving in 
ving in t
ving in th
ving t
ving th
ving the
vio
viou
vis
visi
vision
vision 
vit
vite
vites
vo
voi
voice
w 
w a
w h
w i
w in
w m
w o
w of
w of 
w t
w th
w tha
w that
w that 
w the
w the 
w w
w wh
w,
w, 
w.
wa
wai
wait
wal
wall
war
ward
ward 
was
wash
wat
watch
water
water 
way
way 
way a
way f
way fr
way from
way from 
way from th
way from the
way i
way in
way o
way of
way of 
way t
way th
way the
way,
way, 
way.
ways
ways 
we
we 
wea
wealth
wealth 
wee
weep
weeping
weigh
weight
wel
well
well 
welve
wen
went
went 
went d
went t
wenty
wer
wer 
wer o
wer of 
wer t
wer,
wer, 
were
wh
wha
what
what 
what i
what t
what th
what the
what the 
whe
when
when 
where
where 
where t
where th
where the
whi
which
which 
which a
which ar
which are
which are 
which h
which he
which he 
which i
which is
which is 
which t
which th
which the
which the 
which the L
which the Lord
which the Lord 
who
who 
who a
who i
who is 
who w
who wa
who was
who was 
whom
whom 
whos
wi
wif
wife
wife 
wil
will
will 
will t
win
wind
wine
wing
wing 
wis
wise
wise 
wit
with
with 
with a 
with c
with h
with hi
with his
with his 
with m
with me
with s
with t
with th
with the
with the 
with their
with their 
with w
with y
witness
wl
wle
wn
wn 
wn a
wn i
wn o
wn of
wn of 
wn on
wn on 
wn t
wn to
wn to 
wn w
wn,
wn, 
wo
wo 
wom
woman
woman 
women
women 
woo
wood
wor
word
word 
word o
word of
word of 
word of t
word of th
word of the
word of the 
word of the L
word of the Lord
word of the Lord 
word,
word, 
words
words 
words o
words of 
words of t
words of th
work
work 
work o
work of 
worke
works
world
wou
wound
wr
wra
ws
ws 
ws o
ws of
ws of 
x
x 
xe
xed
xed 
xen
y G
y Go
y God
y I
y I 
y a
y a 
y al
y all
y all 
y an
y and
y and 
y ar
y are
y are 
y b
y be
y be 
y br
y c
y ca
y cam
y came
y came 
y co
y com
y come
y come 
y d
y da
y day
y de
y di
y do
y do 
y e
y f
y fa
y fo
y for
y for 
y fr
y fro
y from
y from 
y from th
y from the
y g
y ga
y gave
y gave 
y gi
y giv
y give
y give 
y go
y h
y ha
y had
y had 
y han
y hand
y hav
y have
y have 
y he
y hea
y hi
y him
y his
y his 
y ho
y i
y in
y in 
y in t
y in th
y in the
y in the 
y is
y is 
y k
y l
y li
y lo
y m
y ma
y mad
y made
y made 
y man
y man 
y may 
y me
y mo
y my
y my 
y n
y na
y name
y no
y not
y not 
y not b
y not be
y not be 
y o
y of
y of 
y of t
y of th
y of the
y of the 
y on
y on 
y one
y one 
y p
y pe
y people
y pl
y pla
y place
y pr
y pu
y put
y put 
y r
y s
y sa
y sai
y said
y said 
y se
y si
y so
y son
y sou
y t
y ta
y tak
y take
y th
y tha
y that
y that 
y the
y the 
y the L
y the Lord
y the s
y the w
y their 
y to
y to 
y to t
y to th
y to the
y to the 
y to you
y to you, 
y too
y took
y took 
y w
y wa
y we
y went
y went 
y were
y were 
y wh
y whe
y wi
y wil
y will
y will 
y will be
y will be 
y wit
y with
y with 
y wo
y wor
y word
y y
y ye
y year
y yo
y you
y your
y your 
y,
y, 
y, a
y, an
y, and
y, and 
y, s
y, t
y, th
y, the
y, w
y.
y:
y: 
y;
y; 
ye
yea
year
year 
yer
yer 
yes
yes 
yes o
yes of 
yi
yin
ying
ying 
ying,
ying, 
yl
ym
yme
ymen
yment
yo
yon
you
yp
yr
ys
ys 
ys a
ys o
ys of 
ys,
ys, 
yse
yself
yt
ythi
ything
ything 
z
za
zar
ze
zi
zz
