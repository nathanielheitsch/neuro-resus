 3.1
 3.1 
 <9
 <93
 Microso
 Microsoft
 Microsoft 
 Moti
 Motif
 Windows 
 Windows 3.
 Windows 3.1
 X
 X 
 X1
 X11
 X11R
 X11R5
 Xt
 a wi
 a win
 an X
 application 
 client
 enter
 for Wi
 for Win
 manager
 server 
 the X
 the wi
 the win
 the window
 to M
 widget
 win
 wind
 windo
 window
 window 
 windows
 windows 
 xp
()
);
, X
.eduM
.eduMessage-ID: <
.lc
.lcs.mi
.lcs.mit.
.lcs.mit.edu
/X
11R
11R5
1R
1R5
3.1 
: Wi
: X
: x
<9
<93
@at
@athen
@athena
@athena.
@athena.mit.edu
@athena.mit.eduM
@ex
@expo
@expo.lcs.mit.
@expo.lcs.mit.edu
Microso
Microsoft
Microsoft 
Moti
Motif
Motif 
Open
R5
R5 
Sender: news@
Sender: news@a
Sender: news@athena.mit.eduMessage-ID: <
WIN
Win
Wind
Windo
Window
Windows 
Windows 3
Windows 3.
Windows 3.1
X1
X11
X11R
X11R5
Xt
a win
a.m
a.mi
a.mit
a.mit.edu
a.mit.eduM
an X
anager 
application 
athen
athena
athena.
client
croso
crosoft
cs.m
cs.mi
d X
dget
dow 
dows 
dows a
e X
e X 
e win
e window
efault
ena.
ert@
expo
expo.lcs.mit.
expo.lcs.mit.edu
for Wi
for Win
g X
h X
he X
he wi
he win
he window
hena
icroso
icrosoft
icrosoft 
idget
indo
indow
indow 
indows 
indows 3
indows 3.
indows 3.1
indows a
ing X
it.eduM
lien
lient
manager
n Wi
n Win
n X
n3
na.m
ndow
ndow 
ndows 3
ndows 3.
ndows 3.1
ng X
o.l
oft 
op.
or Wi
or Win
osoft
osoft 
otif
otif 
ow ma
ows 3
po.
pplication 
r Wi
r Win
r Windo
r Window
r Windows
r Windows 
r win
r: news@
rosoft 
rt@
s 3.
s 3.1
s.mi
s.mit
s.mit.
s.mit.edu
s@a
s@at
server 
soft 
t X
t: e
t@e
the X
the wi
the win
the window
thena
thena.
tif 
to M
uMessage-ID: <
widget
wind
windo
window
window 
windows
windows 
windows.
wm
ws 3
ws 3.
ws 3.1
ws@
xpert
xpo
